# QuickSell Africa - Resend Email Setup Guide

## 🔑 Your Keys (Save These!)

```
RESEND_API_KEY=re_aD57URUu_65eCF3uDeiNsAYqVAas3H6cW
PAYSTACK_SECRET_KEY=sk_test_e52d0e5b7b6eaeefe9135821df5c043fdcac9391
PAYSTACK_PUBLIC_KEY=pk_test_07abb96718985968696bbbbc3bcd5f9f943c040d
```

---

## 📧 EDGE FUNCTION: send-email (Using Resend)

### Step 1: Create the Function

1. Go to Supabase Dashboard → Edge Functions → New Function
2. Name: `send-email`
3. Copy this code:

```typescript
// supabase/functions/send-email/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { to, subject, html, text, from } = await req.json()

    // Validate required fields
    if (!to || !subject || (!html && !text)) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const resendApiKey = Deno.env.get('RESEND_API_KEY')
    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ error: 'Resend API key not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Send email via Resend API
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${resendApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: from || 'QuickSell Africa <noreply@qafrica.com>',
        to: Array.isArray(to) ? to : [to],
        subject,
        html,
        text: text || '',
      }),
    })

    const data = await response.json()

    if (!response.ok) {
      console.error('Resend API error:', data)
      return new Response(
        JSON.stringify({ error: data.message || 'Failed to send email' }),
        { status: response.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Email sent successfully',
        id: data.id 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Email send error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
```

### Step 2: Add Secrets

Go to the function → Settings → Secrets, add:

```
RESEND_API_KEY=re_aD57URUu_65eCF3uDeiNsAYqVAas3H6cW
```

### Step 3: Deploy

Click "Deploy" button

---

## 💳 EDGE FUNCTION: paystack-webhook

### Step 1: Create the Function

1. Go to Supabase Dashboard → Edge Functions → New Function
2. Name: `paystack-webhook`
3. Copy this code:

```typescript
// supabase/functions/paystack-webhook/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.0'
import { crypto } from 'https://deno.land/std@0.168.0/crypto/mod.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Initialize Supabase client
const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Verify Paystack signature
    const signature = req.headers.get('x-paystack-signature')
    const secret = Deno.env.get('PAYSTACK_SECRET_KEY')
    
    if (!signature || !secret) {
      return new Response('Unauthorized', { status: 401 })
    }

    const body = await req.text()
    
    // Verify signature (HMAC SHA512)
    const encoder = new TextEncoder()
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-512' },
      false,
      ['sign']
    )
    
    const signatureBuffer = await crypto.subtle.sign('HMAC', key, encoder.encode(body))
    const computedSignature = Array.from(new Uint8Array(signatureBuffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('')
    
    if (signature !== computedSignature) {
      return new Response('Invalid signature', { status: 401 })
    }

    const event = JSON.parse(body)
    const { event: eventType, data } = event

    console.log('Paystack webhook received:', eventType)

    switch (eventType) {
      case 'charge.success':
        await handleChargeSuccess(data)
        break
      case 'transfer.success':
        await handleTransferSuccess(data)
        break
      case 'transfer.failed':
        await handleTransferFailed(data)
        break
      case 'subscription.create':
        await handleSubscriptionCreate(data)
        break
      case 'subscription.disable':
        await handleSubscriptionDisable(data)
        break
      default:
        console.log('Unhandled event type:', eventType)
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  } catch (error) {
    console.error('Webhook error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

async function handleChargeSuccess(data: any) {
  const { reference, metadata, amount, customer } = data
  
  // Determine payment type from metadata
  const paymentType = metadata?.type || 'order'
  
  if (paymentType === 'order') {
    // Update order payment status
    const { error } = await supabase
      .from('orders')
      .update({
        payment_status: 'paid',
        paid_at: new Date().toISOString(),
        payment_reference: reference,
        status: 'confirmed'
      })
      .eq('payment_reference', reference)
    
    if (error) {
      console.error('Error updating order:', error)
    }
  } else if (paymentType === 'subscription') {
    // Update subscription
    const { error } = await supabase
      .from('subscriptions')
      .update({
        payment_reference: reference,
        is_active: true
      })
      .eq('payment_reference', reference)
    
    if (error) {
      console.error('Error updating subscription:', error)
    }
  }
  
  // Send notification email
  if (metadata?.owner_id) {
    // Create notification
    await supabase.from('notifications').insert({
      user_id: metadata.owner_id,
      type: 'payment_received',
      title: 'Payment Received',
      message: `Payment of ₦${(amount / 100).toLocaleString()} has been received`,
      data: { order_id: metadata.order_id, reference }
    })

    // Send email notification
    await fetch(`${supabaseUrl}/functions/v1/send-email`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${supabaseServiceKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        to: metadata.customer_email || customer.email,
        subject: 'Payment Confirmation - QuickSell Africa',
        html: `
          <h2>Payment Confirmed!</h2>
          <p>Your payment of ₦${(amount / 100).toLocaleString()} has been received.</p>
          <p>Reference: ${reference}</p>
          <p>Thank you for shopping with us!</p>
        `
      })
    })
  }
}

async function handleTransferSuccess(data: any) {
  const { reference, recipient, amount } = data
  
  // Update withdrawal request
  const { error } = await supabase
    .from('withdrawal_requests')
    .update({
      status: 'paid',
      paid_at: new Date().toISOString()
    })
    .eq('id', reference)
  
  if (error) {
    console.error('Error updating withdrawal:', error)
  }
}

async function handleTransferFailed(data: any) {
  const { reference, reason } = data
  
  // Update withdrawal request
  const { error } = await supabase
    .from('withdrawal_requests')
    .update({
      status: 'rejected',
      admin_note: reason
    })
    .eq('id', reference)
  
  if (error) {
    console.error('Error updating withdrawal:', error)
  }
}

async function handleSubscriptionCreate(data: any) {
  console.log('Subscription created:', data)
}

async function handleSubscriptionDisable(data: any) {
  const { subscription_code } = data
  
  // Deactivate subscription
  const { error } = await supabase
    .from('subscriptions')
    .update({ is_active: false })
    .eq('payment_reference', subscription_code)
  
  if (error) {
    console.error('Error disabling subscription:', error)
  }
}
```

### Step 2: Add Secrets

```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
PAYSTACK_SECRET_KEY=sk_test_e52d0e5b7b6eaeefe9135821df5c043fdcac9391
```

### Step 3: Configure Paystack Webhook

1. Go to https://dashboard.paystack.com
2. Settings → API Keys & Webhooks
3. Add webhook URL:
   ```
   https://your-project.supabase.co/functions/v1/paystack-webhook
   ```
4. Select events: `charge.success`, `transfer.success`, `transfer.failed`

---

## 🛠️ FIXING RLS ISSUE FOR STORE CREATION

The RLS error happens because the policies don't allow the user to insert. Here's the **FIXED** SQL:

### Run This SQL in Supabase SQL Editor:

```sql
-- ============================================
-- FIX: Store Creation RLS Policies
-- ============================================

-- First, drop existing policies if they exist
DROP POLICY IF EXISTS "Stores are viewable by everyone" ON stores;
DROP POLICY IF EXISTS "Users can create own store" ON stores;
DROP POLICY IF EXISTS "Owners can update own store" ON stores;
DROP POLICY IF EXISTS "Admins can manage all stores" ON stores;

-- Enable RLS (if not already enabled)
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;

-- Policy 1: Anyone can view active, non-blocked stores
CREATE POLICY "Stores are viewable by everyone" 
  ON stores FOR SELECT 
  TO PUBLIC
  USING (is_active = TRUE AND is_blocked = FALSE);

-- Policy 2: Authenticated users can create stores (FIXED!)
CREATE POLICY "Users can create own store" 
  ON stores FOR INSERT 
  TO authenticated
  WITH CHECK (auth.uid() = owner_id);

-- Policy 3: Store owners can update their own stores
CREATE POLICY "Owners can update own store" 
  ON stores FOR UPDATE 
  TO authenticated
  USING (auth.uid() = owner_id);

-- Policy 4: Store owners can delete their own stores
CREATE POLICY "Owners can delete own store" 
  ON stores FOR DELETE 
  TO authenticated
  USING (auth.uid() = owner_id);

-- Policy 5: Admins can do everything
CREATE POLICY "Admins can manage all stores" 
  ON stores FOR ALL 
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- ============================================
-- FIX: Profiles RLS (for user creation)
-- ============================================

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Policy 1: Users can view their own profile
CREATE POLICY "Users can view own profile" 
  ON profiles FOR SELECT 
  TO authenticated
  USING (auth.uid() = id);

-- Policy 2: Users can insert their own profile (IMPORTANT!)
CREATE POLICY "Users can insert own profile" 
  ON profiles FOR INSERT 
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Policy 3: Users can update their own profile
CREATE POLICY "Users can update own profile" 
  ON profiles FOR UPDATE 
  TO authenticated
  USING (auth.uid() = id);

-- Policy 4: Admins can view all profiles
CREATE POLICY "Admins can view all profiles" 
  ON profiles FOR SELECT 
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- ============================================
-- FIX: Products RLS
-- ============================================

DROP POLICY IF EXISTS "Products are viewable by everyone" ON products;
DROP POLICY IF EXISTS "Store owners can manage own products" ON products;

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Products are viewable by everyone" 
  ON products FOR SELECT 
  TO PUBLIC
  USING (is_active = TRUE);

CREATE POLICY "Store owners can insert products" 
  ON products FOR INSERT 
  TO authenticated
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Store owners can update products" 
  ON products FOR UPDATE 
  TO authenticated
  USING (auth.uid() = owner_id);

CREATE POLICY "Store owners can delete products" 
  ON products FOR DELETE 
  TO authenticated
  USING (auth.uid() = owner_id);

-- ============================================
-- FIX: Wallets RLS
-- ============================================

DROP POLICY IF EXISTS "Users can view own wallet" ON wallets;
DROP POLICY IF EXISTS "Admins can view all wallets" ON wallets;

ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own wallet" 
  ON wallets FOR SELECT 
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own wallet" 
  ON wallets FOR INSERT 
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all wallets" 
  ON wallets FOR SELECT 
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- ============================================
-- CREATE WALLET FUNCTION
-- ============================================

CREATE OR REPLACE FUNCTION credit_wallet(
  p_user_id UUID,
  p_amount DECIMAL,
  p_description TEXT,
  p_reference TEXT
)
RETURNS JSONB AS $$
DECLARE
  v_wallet_id UUID;
  v_current_balance DECIMAL;
  v_new_balance DECIMAL;
BEGIN
  -- Get or create wallet
  SELECT id, balance INTO v_wallet_id, v_current_balance
  FROM wallets
  WHERE user_id = p_user_id;

  IF v_wallet_id IS NULL THEN
    INSERT INTO wallets (user_id, balance, total_earned)
    VALUES (p_user_id, p_amount, p_amount)
    RETURNING id, balance INTO v_wallet_id, v_new_balance;
  ELSE
    v_new_balance := v_current_balance + p_amount;
    
    UPDATE wallets
    SET 
      balance = v_new_balance,
      total_earned = total_earned + p_amount,
      updated_at = NOW()
    WHERE id = v_wallet_id;
  END IF;

  -- Create transaction record
  INSERT INTO wallet_transactions (
    wallet_id,
    user_id,
    type,
    amount,
    balance_after,
    description,
    reference,
    status
  ) VALUES (
    v_wallet_id,
    p_user_id,
    'credit',
    p_amount,
    v_new_balance,
    p_description,
    p_reference,
    'completed'
  );

  RETURN jsonb_build_object(
    'success', true,
    'wallet_id', v_wallet_id,
    'new_balance', v_new_balance
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- CREATE TRIGGER FOR NEW USER PROFILE
-- ============================================

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, email, full_name, role, email_verified)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    COALESCE(NEW.raw_user_meta_data->>'role', 'user'),
    FALSE
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- ============================================
-- CREATE TRIGGER FOR NEW USER WALLET
-- ============================================

CREATE OR REPLACE FUNCTION handle_new_profile()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO wallets (user_id, balance)
  VALUES (NEW.id, 0)
  ON CONFLICT (user_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger on profiles
DROP TRIGGER IF EXISTS on_profile_created ON profiles;
CREATE TRIGGER on_profile_created
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_profile();
```

---

## 📋 COMPLETE SETUP CHECKLIST

### Step 1: Create Tables (Run SQL from SUPABASE_SETUP.md)
- [ ] profiles
- [ ] stores
- [ ] products
- [ ] orders
- [ ] order_items
- [ ] wallets
- [ ] wallet_transactions
- [ ] withdrawal_requests
- [ ] subscriptions
- [ ] delivery_zones
- [ ] notifications
- [ ] import_catalog
- [ ] tax_settings
- [ ] business_expenses
- [ ] tax_reports
- [ ] reviews
- [ ] coupons
- [ ] customers
- [ ] customer_addresses
- [ ] customer_carts
- [ ] store_visits
- [ ] stock_alerts
- [ ] product_earnings
- [ ] admin_actions

### Step 2: Fix RLS (Run SQL above)
- [ ] Run the RLS fix SQL

### Step 3: Create Storage Buckets
- [ ] products
- [ ] store-logos
- [ ] store-banners
- [ ] receipts
- [ ] tax-reports
- [ ] avatars
- [ ] review-images

### Step 4: Create Edge Functions
- [ ] send-email (with Resend)
- [ ] paystack-webhook
- [ ] generate-tax-report
- [ ] process-escrow
- [ ] send-notification
- [ ] track-store-visit

### Step 5: Add Secrets to Functions
- [ ] RESEND_API_KEY
- [ ] PAYSTACK_SECRET_KEY
- [ ] SUPABASE_URL
- [ ] SUPABASE_SERVICE_ROLE_KEY

### Step 6: Configure Paystack
- [ ] Add webhook URL
- [ ] Add your domain to allowed origins

### Step 7: Update Environment Variables
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_PAYSTACK_PUBLIC_KEY=pk_test_07abb96718985968696bbbbc3bcd5f9f943c040d
VITE_APP_NAME=QAFRICA
VITE_APP_URL=https://your-domain.com
```

---

## 🧪 TEST EMAIL FUNCTION

```bash
curl -X POST https://your-project.supabase.co/functions/v1/send-email \
  -H "Authorization: Bearer your-anon-key" \
  -H "Content-Type: application/json" \
  -d '{
    "to": "your-email@example.com",
    "subject": "Test from QuickSell",
    "html": "<h1>Hello!</h1><p>This is a test email from Resend.</p>"
  }'
```

---

## 🚨 TROUBLESHOOTING RLS ERRORS

If you still get RLS errors:

1. **Check if user is authenticated:**
   ```sql
   SELECT auth.uid();
   ```

2. **Check user exists in profiles:**
   ```sql
   SELECT * FROM profiles WHERE id = auth.uid();
   ```

3. **Temporarily disable RLS for testing (DON'T do in production):**
   ```sql
   ALTER TABLE stores DISABLE ROW LEVEL SECURITY;
   ```

4. **Check exact error:**
   Open browser DevTools → Network tab → Look for the failed request

---

**Your Keys:**
- Resend: `re_aD57URUu_65eCF3uDeiNsAYqVAas3H6cW`
- Paystack Secret: `sk_test_e52d0e5b7b6eaeefe9135821df5c043fdcac9391`
- Paystack Public: `pk_test_07abb96718985968696bbbbc3bcd5f9f943c040d`
