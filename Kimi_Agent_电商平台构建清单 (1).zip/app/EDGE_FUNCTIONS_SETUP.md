# QuickSell Africa - Edge Functions Setup Guide

This guide contains all the Supabase Edge Functions you need to create manually.

---

## 📁 FUNCTION 1: send-email

**Purpose**: Send transactional emails (order confirmations, notifications, etc.)

### Create Function:
1. Go to Supabase Dashboard → Edge Functions → New Function
2. Name: `send-email`
3. Copy the code below:

```typescript
// supabase/functions/send-email/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { SmtpClient } from 'https://deno.land/x/smtp@v0.7.0/mod.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { to, subject, html, text } = await req.json()

    // Validate required fields
    if (!to || !subject || (!html && !text)) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const client = new SmtpClient()
    
    await client.connectTLS({
      hostname: Deno.env.get('SMTP_HOST') || 'smtp.gmail.com',
      port: parseInt(Deno.env.get('SMTP_PORT') || '587'),
      username: Deno.env.get('SMTP_USER'),
      password: Deno.env.get('SMTP_PASS'),
    })

    await client.send({
      from: Deno.env.get('SMTP_FROM') || 'noreply@qafrica.com',
      to: to,
      subject: subject,
      content: text || '',
      html: html,
    })

    await client.close()

    return new Response(
      JSON.stringify({ success: true, message: 'Email sent successfully' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Email send error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
```

### Secrets to Add:
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@qafrica.com
```

---

## 📁 FUNCTION 2: paystack-webhook

**Purpose**: Handle Paystack payment webhooks

### Create Function:
1. Go to Supabase Dashboard → Edge Functions → New Function
2. Name: `paystack-webhook`
3. Copy the code below:

```typescript
// supabase/functions/paystack-webhook/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.0'
import { crypto } from 'https://deno.land/std@0.168.0/crypto/mod.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Initialize Supabase client
const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Verify Paystack signature
    const signature = req.headers.get('x-paystack-signature')
    const secret = Deno.env.get('PAYSTACK_SECRET_KEY')
    
    if (!signature || !secret) {
      return new Response('Unauthorized', { status: 401 })
    }

    const body = await req.text()
    
    // Verify signature (HMAC SHA512)
    const encoder = new TextEncoder()
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-512' },
      false,
      ['sign']
    )
    
    const signatureBuffer = await crypto.subtle.sign('HMAC', key, encoder.encode(body))
    const computedSignature = Array.from(new Uint8Array(signatureBuffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('')
    
    if (signature !== computedSignature) {
      return new Response('Invalid signature', { status: 401 })
    }

    const event = JSON.parse(body)
    const { event: eventType, data } = event

    console.log('Paystack webhook received:', eventType)

    switch (eventType) {
      case 'charge.success':
        await handleChargeSuccess(data)
        break
      case 'transfer.success':
        await handleTransferSuccess(data)
        break
      case 'transfer.failed':
        await handleTransferFailed(data)
        break
      case 'subscription.create':
        await handleSubscriptionCreate(data)
        break
      case 'subscription.disable':
        await handleSubscriptionDisable(data)
        break
      default:
        console.log('Unhandled event type:', eventType)
    }

    return new Response(JSON.stringify({ received: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  } catch (error) {
    console.error('Webhook error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

async function handleChargeSuccess(data: any) {
  const { reference, metadata, amount, customer } = data
  
  // Determine payment type from metadata
  const paymentType = metadata?.type || 'order'
  
  if (paymentType === 'order') {
    // Update order payment status
    const { error } = await supabase
      .from('orders')
      .update({
        payment_status: 'paid',
        paid_at: new Date().toISOString(),
        payment_reference: reference,
        status: 'confirmed'
      })
      .eq('payment_reference', reference)
    
    if (error) {
      console.error('Error updating order:', error)
    }
  } else if (paymentType === 'subscription') {
    // Update subscription
    const { error } = await supabase
      .from('subscriptions')
      .update({
        payment_reference: reference,
        is_active: true
      })
      .eq('payment_reference', reference)
    
    if (error) {
      console.error('Error updating subscription:', error)
    }
  }
  
  // Create notification for store owner
  if (metadata?.store_id) {
    await supabase.from('notifications').insert({
      user_id: metadata.owner_id,
      type: 'payment_received',
      title: 'Payment Received',
      message: `Payment of ₦${(amount / 100).toLocaleString()} has been received`,
      data: { order_id: metadata.order_id, reference }
    })
  }
}

async function handleTransferSuccess(data: any) {
  const { reference, recipient, amount } = data
  
  // Update withdrawal request
  const { error } = await supabase
    .from('withdrawal_requests')
    .update({
      status: 'paid',
      paid_at: new Date().toISOString()
    })
    .eq('id', reference)
  
  if (error) {
    console.error('Error updating withdrawal:', error)
  }
}

async function handleTransferFailed(data: any) {
  const { reference, reason } = data
  
  // Update withdrawal request
  const { error } = await supabase
    .from('withdrawal_requests')
    .update({
      status: 'rejected',
      admin_note: reason
    })
    .eq('id', reference)
  
  if (error) {
    console.error('Error updating withdrawal:', error)
  }
}

async function handleSubscriptionCreate(data: any) {
  console.log('Subscription created:', data)
}

async function handleSubscriptionDisable(data: any) {
  const { subscription_code } = data
  
  // Deactivate subscription
  const { error } = await supabase
    .from('subscriptions')
    .update({ is_active: false })
    .eq('payment_reference', subscription_code)
  
  if (error) {
    console.error('Error disabling subscription:', error)
  }
}
```

### Secrets to Add:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
PAYSTACK_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxx
```

---

## 📁 FUNCTION 3: generate-tax-report

**Purpose**: Generate tax reports in PDF, CSV, or Excel format

### Create Function:
1. Go to Supabase Dashboard → Edge Functions → New Function
2. Name: `generate-tax-report`
3. Copy the code below:

```typescript
// supabase/functions/generate-tax-report/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { store_id, start_date, end_date, format } = await req.json()

    if (!store_id || !start_date || !end_date || !format) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Fetch tax data using the database function
    const { data: taxData, error: taxError } = await supabase.rpc('calculate_tax_for_period', {
      p_store_id: store_id,
      p_start_date: start_date,
      p_end_date: end_date
    })

    if (taxError) throw taxError

    // Fetch expenses breakdown
    const { data: expenses, error: expenseError } = await supabase.rpc('get_expense_categories_summary', {
      p_store_id: store_id,
      p_start_date: start_date,
      p_end_date: end_date
    })

    if (expenseError) throw expenseError

    // Get store info
    const { data: store, error: storeError } = await supabase
      .from('stores')
      .select('name, owner:profiles(full_name, email)')
      .eq('id', store_id)
      .single()

    if (storeError) throw storeError

    let reportContent: string | Uint8Array
    let contentType: string
    let fileExtension: string

    switch (format) {
      case 'csv':
        reportContent = generateCSV(taxData, expenses, store, start_date, end_date)
        contentType = 'text/csv'
        fileExtension = 'csv'
        break
      case 'excel':
        reportContent = generateExcel(taxData, expenses, store, start_date, end_date)
        contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        fileExtension = 'xlsx'
        break
      case 'pdf':
      default:
        reportContent = generatePDF(taxData, expenses, store, start_date, end_date)
        contentType = 'application/pdf'
        fileExtension = 'pdf'
        break
    }

    // Upload to storage
    const fileName = `tax-report-${store_id}-${start_date}-${end_date}.${fileExtension}`
    const { data: uploadData, error: uploadError } = await supabase
      .storage
      .from('tax-reports')
      .upload(fileName, reportContent, {
        contentType,
        upsert: true
      })

    if (uploadError) throw uploadError

    // Get public URL
    const { data: { publicUrl } } = supabase
      .storage
      .from('tax-reports')
      .getPublicUrl(fileName)

    // Save report record
    const { error: saveError } = await supabase
      .from('tax_reports')
      .insert({
        store_id,
        owner_id: store.owner.id,
        report_name: `Tax Report ${start_date} to ${end_date}`,
        report_period_start: start_date,
        report_period_end: end_date,
        total_revenue: taxData.total_revenue,
        total_expenses: taxData.total_expenses,
        taxable_income: taxData.taxable_income,
        tax_rate: taxData.tax_rate,
        tax_amount: taxData.tax_amount,
        deductions: taxData.total_expenses,
        net_tax_payable: taxData.tax_amount,
        report_data: { taxData, expenses },
        file_url: publicUrl,
        file_format: format
      })

    if (saveError) throw saveError

    return new Response(
      JSON.stringify({
        success: true,
        download_url: publicUrl,
        file_name: fileName
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Report generation error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

function generateCSV(taxData: any, expenses: any[], store: any, startDate: string, endDate: string): string {
  const rows = [
    ['QuickSell Africa - Tax Report'],
    [''],
    ['Store:', store.name],
    ['Owner:', store.owner.full_name],
    ['Period:', `${startDate} to ${endDate}`],
    ['Generated:', new Date().toISOString()],
    [''],
    ['SUMMARY'],
    ['Total Revenue', taxData.total_revenue],
    ['Total Expenses', taxData.total_expenses],
    ['Taxable Income', taxData.taxable_income],
    ['Tax Rate', `${taxData.tax_rate}%`],
    ['Tax Amount', taxData.tax_amount],
    ['Net After Tax', taxData.net_after_tax],
    [''],
    ['EXPENSE BREAKDOWN'],
    ['Category', 'Amount', 'Count'],
    ...expenses.map(e => [e.category, e.total_amount, e.expense_count])
  ]

  return rows.map(row => row.join(',')).join('\n')
}

function generateExcel(taxData: any, expenses: any[], store: any, startDate: string, endDate: string): Uint8Array {
  // For Excel, we'll generate a simple XML-based format
  // In production, use a proper library like xlsx
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet">
  <Worksheet ss:Name="Tax Report">
    <Table>
      <Row><Cell><Data ss:Type="String">QuickSell Africa - Tax Report</Data></Cell></Row>
      <Row><Cell><Data ss:Type="String">Store: ${store.name}</Data></Cell></Row>
      <Row><Cell><Data ss:Type="String">Period: ${startDate} to ${endDate}</Data></Cell></Row>
      <Row><Cell><Data ss:Type="String"></Data></Cell></Row>
      <Row>
        <Cell><Data ss:Type="String">Total Revenue</Data></Cell>
        <Cell><Data ss:Type="Number">${taxData.total_revenue}</Data></Cell>
      </Row>
      <Row>
        <Cell><Data ss:Type="String">Total Expenses</Data></Cell>
        <Cell><Data ss:Type="Number">${taxData.total_expenses}</Data></Cell>
      </Row>
      <Row>
        <Cell><Data ss:Type="String">Taxable Income</Data></Cell>
        <Cell><Data ss:Type="Number">${taxData.taxable_income}</Data></Cell>
      </Row>
      <Row>
        <Cell><Data ss:Type="String">Tax Rate</Data></Cell>
        <Cell><Data ss:Type="String">${taxData.tax_rate}%</Data></Cell>
      </Row>
      <Row>
        <Cell><Data ss:Type="String">Tax Amount</Data></Cell>
        <Cell><Data ss:Type="Number">${taxData.tax_amount}</Data></Cell>
      </Row>
    </Table>
  </Worksheet>
</Workbook>`

  return new TextEncoder().encode(xml)
}

function generatePDF(taxData: any, expenses: any[], store: any, startDate: string, endDate: string): Uint8Array {
  // For PDF, we'll generate a simple HTML-based format
  // In production, use a proper PDF library
  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Tax Report</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 40px; }
    h1 { color: #F97316; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
    th { background: #f5f5f5; }
    .total { font-weight: bold; font-size: 1.2em; }
  </style>
</head>
<body>
  <h1>QuickSell Africa - Tax Report</h1>
  <p><strong>Store:</strong> ${store.name}</p>
  <p><strong>Owner:</strong> ${store.owner.full_name}</p>
  <p><strong>Period:</strong> ${startDate} to ${endDate}</p>
  <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
  
  <h2>Summary</h2>
  <table>
    <tr><td>Total Revenue</td><td>₦${taxData.total_revenue.toLocaleString()}</td></tr>
    <tr><td>Total Expenses</td><td>₦${taxData.total_expenses.toLocaleString()}</td></tr>
    <tr><td>Taxable Income</td><td>₦${taxData.taxable_income.toLocaleString()}</td></tr>
    <tr><td>Tax Rate</td><td>${taxData.tax_rate}%</td></tr>
    <tr class="total"><td>Tax Amount</td><td>₦${taxData.tax_amount.toLocaleString()}</td></tr>
    <tr class="total"><td>Net After Tax</td><td>₦${taxData.net_after_tax.toLocaleString()}</td></tr>
  </table>
  
  <h2>Expense Breakdown</h2>
  <table>
    <tr><th>Category</th><th>Amount</th><th>Count</th></tr>
    ${expenses.map(e => `<tr><td>${e.category}</td><td>₦${e.total_amount.toLocaleString()}</td><td>${e.expense_count}</td></tr>`).join('')}
  </table>
</body>
</html>`

  return new TextEncoder().encode(html)
}
```

### Secrets to Add:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

---

## 📁 FUNCTION 4: process-escrow

**Purpose**: Process escrow releases automatically after 7 days

### Create Function:
1. Go to Supabase Dashboard → Edge Functions → New Function
2. Name: `process-escrow`
3. Copy the code below:

```typescript
// supabase/functions/process-escrow/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Find orders where escrow should be released (7 days after delivery)
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

    const { data: orders, error } = await supabase
      .from('orders')
      .select('*, store:stores(owner_id)')
      .eq('status', 'delivered')
      .eq('is_escrow_released', false)
      .lte('delivered_at', sevenDaysAgo.toISOString())

    if (error) throw error

    const results = []

    for (const order of orders || []) {
      try {
        // Calculate store earnings (total - platform fee)
        const storeEarnings = order.total - order.platform_fee

        // Credit store owner's wallet
        const { error: walletError } = await supabase.rpc('credit_wallet', {
          p_user_id: order.store.owner_id,
          p_amount: storeEarnings,
          p_description: `Order #${order.order_number} earnings`,
          p_reference: order.id
        })

        if (walletError) throw walletError

        // Mark escrow as released
        const { error: updateError } = await supabase
          .from('orders')
          .update({ is_escrow_released: true })
          .eq('id', order.id)

        if (updateError) throw updateError

        // Create notification
        await supabase.from('notifications').insert({
          user_id: order.store.owner_id,
          type: 'escrow_released',
          title: 'Earnings Released',
          message: `₦${storeEarnings.toLocaleString()} from Order #${order.order_number} has been credited to your wallet`,
          data: { order_id: order.id, amount: storeEarnings }
        })

        results.push({ order_id: order.id, status: 'released', amount: storeEarnings })
      } catch (err) {
        console.error(`Error processing order ${order.id}:`, err)
        results.push({ order_id: order.id, status: 'error', error: err.message })
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        processed: results.length,
        results
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Escrow processing error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
```

### Secrets to Add:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

---

## 📁 FUNCTION 5: send-notification

**Purpose**: Send push/email notifications to users

### Create Function:
1. Go to Supabase Dashboard → Edge Functions → New Function
2. Name: `send-notification`
3. Copy the code below:

```typescript
// supabase/functions/send-notification/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { user_id, type, title, message, data = {} } = await req.json()

    if (!user_id || !type || !title || !message) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Save notification to database
    const { error: dbError } = await supabase
      .from('notifications')
      .insert({
        user_id,
        type,
        title,
        message,
        data
      })

    if (dbError) throw dbError

    // Get user email for email notification
    const { data: user, error: userError } = await supabase
      .from('profiles')
      .select('email, full_name')
      .eq('id', user_id)
      .single()

    if (userError) throw userError

    // Send email notification (optional - can be disabled for non-critical notifications)
    if (type === 'order' || type === 'payment' || type === 'escrow_released') {
      await fetch(`${supabaseUrl}/functions/v1/send-email`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseServiceKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          to: user.email,
          subject: title,
          html: `
            <h2>Hello ${user.full_name},</h2>
            <p>${message}</p>
            <p>Log in to your dashboard to view details.</p>
            <p>Best regards,<br>QuickSell Africa Team</p>
          `
        })
      })
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Notification error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
```

### Secrets to Add:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

---

## 📁 FUNCTION 6: track-store-visit

**Purpose**: Track store visits for analytics

### Create Function:
1. Go to Supabase Dashboard → Edge Functions → New Function
2. Name: `track-store-visit`
3. Copy the code below:

```typescript
// supabase/functions/track-store-visit/index.ts
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { store_id } = await req.json()
    
    // Get request info
    const ip = req.headers.get('x-forwarded-for') || 'unknown'
    const userAgent = req.headers.get('user-agent') || 'unknown'
    const referrer = req.headers.get('referer') || 'direct'
    
    // Determine traffic source
    let source = 'direct'
    if (referrer.includes('google')) source = 'search'
    else if (referrer.includes('facebook') || referrer.includes('instagram') || referrer.includes('twitter')) source = 'social'
    else if (referrer.includes('ad')) source = 'ads'

    // Save visit
    const { error } = await supabase
      .from('store_visits')
      .insert({
        store_id,
        ip: ip.split(',')[0], // Get first IP if multiple
        user_agent: userAgent,
        referrer,
        source
      })

    if (error) throw error

    // Update store analytics
    const { data: store } = await supabase
      .from('stores')
      .select('analytics')
      .eq('id', store_id)
      .single()

    if (store) {
      const analytics = store.analytics || {}
      analytics.total_visits = (analytics.total_visits || 0) + 1
      
      // Update traffic sources
      analytics.traffic_sources = analytics.traffic_sources || {}
      analytics.traffic_sources[source] = (analytics.traffic_sources[source] || 0) + 1

      await supabase
        .from('stores')
        .update({ analytics })
        .eq('id', store_id)
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Track visit error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
```

### Secrets to Add:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

---

## 🔐 SECRETS SUMMARY

Add these secrets to **each Edge Function** (Settings → Secrets):

### Required for ALL functions:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

### Required for `send-email`:
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@qafrica.com
```

### Required for `paystack-webhook`:
```
PAYSTACK_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxx
```

---

## ⏰ CRON JOBS (Scheduled Functions)

Set up these cron jobs in Supabase (Database → Cron Jobs):

### 1. Process Escrow Daily
```sql
SELECT cron.schedule('process-escrow-daily', '0 0 * * *', $$
  SELECT net.http_post(
    url:='https://your-project.supabase.co/functions/v1/process-escrow',
    headers:='{"Authorization": "Bearer your-service-role-key"}'::jsonb
  ) as request_id;
$$);
```

### 2. Send Daily Summary (Optional)
```sql
SELECT cron.schedule('daily-summary', '0 9 * * *', $$
  SELECT net.http_post(
    url:='https://your-project.supabase.co/functions/v1/send-daily-summary',
    headers:='{"Authorization": "Bearer your-service-role-key"}'::jsonb
  ) as request_id;
$$);
```

---

## 🧪 TESTING EDGE FUNCTIONS

Test each function using curl:

### Test send-email:
```bash
curl -X POST https://your-project.supabase.co/functions/v1/send-email \
  -H "Authorization: Bearer your-anon-key" \
  -H "Content-Type: application/json" \
  -d '{
    "to": "test@example.com",
    "subject": "Test Email",
    "html": "<h1>Hello World</h1>"
  }'
```

### Test generate-tax-report:
```bash
curl -X POST https://your-project.supabase.co/functions/v1/generate-tax-report \
  -H "Authorization: Bearer your-anon-key" \
  -H "Content-Type: application/json" \
  -d '{
    "store_id": "your-store-uuid",
    "start_date": "2024-01-01",
    "end_date": "2024-12-31",
    "format": "pdf"
  }'
```

---

## 🚨 TROUBLESHOOTING

### Function not found:
- Ensure function is deployed (Edge Functions → Deploy)
- Check URL is correct

### Secrets not working:
- Verify secrets are added to EACH function
- Redeploy function after adding secrets

### CORS errors:
- Ensure corsHeaders are set correctly
- Check browser console for exact error

### Timeout errors:
- Edge functions have 10-second timeout
- For long operations, use background jobs

---

**Last Updated**: 2024
**Version**: 1.0.0
