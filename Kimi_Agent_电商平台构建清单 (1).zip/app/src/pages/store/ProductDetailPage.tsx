import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ShoppingCart, ArrowLeft, Heart, Truck, Shield, 
  Clock, Minus, Plus, MapPin, MessageCircle,
  Check, AlertCircle, Store as StoreIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { storeService, productService, deliveryZoneService } from '@/services/supabase';
import Reviews from '@/components/Reviews';
import { toast } from 'sonner';
import { getThemeById } from '@/lib/themes';
import { useCartStore } from '@/stores';
import type { Store as StoreType, Product, DeliveryZone } from '@/types';

export default function ProductDetailPage() {
  const { slug, productId } = useParams<{ slug: string; productId: string }>();
  const navigate = useNavigate();
  const { addItem, addToWishlist, removeFromWishlist, isInWishlist } = useCartStore();
  const [store, setStore] = useState<StoreType | null>(null);
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [deliveryZones, setDeliveryZones] = useState<DeliveryZone[]>([]);
  const [selectedState, setSelectedState] = useState('');
  const [deliveryFee, setDeliveryFee] = useState<number | null>(null);
  const [showContactModal, setShowContactModal] = useState(false);

  const theme = store?.theme ? getThemeById(store.theme) : getThemeById('modern');

  // Nigerian states
  const nigerianStates = [
    'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa', 'Benue', 
    'Borno', 'Cross River', 'Delta', 'Ebonyi', 'Edo', 'Ekiti', 'Enugu', 'FCT',
    'Gombe', 'Imo', 'Jigawa', 'Kaduna', 'Kano', 'Katsina', 'Kebbi', 'Kogi', 
    'Kwara', 'Lagos', 'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun', 'Oyo', 
    'Plateau', 'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara'
  ];

  useEffect(() => {
    if (slug && productId) {
      loadData();
    }
  }, [slug, productId]);

  useEffect(() => {
    checkDelivery();
  }, [selectedState, deliveryZones]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      // Load store
      const { data: storeData } = await storeService.getStoreBySlug(slug!);
      if (!storeData) {
        toast.error('Store not found');
        navigate('/store-not-found');
        return;
      }
      setStore(storeData as StoreType);

      // Load product
      const { data: productData } = await productService.getProduct(productId!);
      if (!productData) {
        toast.error('Product not found');
        navigate(`/my-site/${slug}`);
        return;
      }
      setProduct(productData as Product);

      // Load delivery zones
      const { data: zonesData } = await deliveryZoneService.getStoreZones(storeData.id);
      if (zonesData) {
        setDeliveryZones(zonesData as DeliveryZone[]);
      }

      // Load related products
      const { data: productsData } = await productService.getStoreProducts(storeData.id);
      if (productsData) {
        const related = (productsData as Product[])
          .filter(p => p.id !== productId && p.is_active)
          .slice(0, 4);
        setRelatedProducts(related);
      }
    } catch (err) {
      console.error('Error loading product:', err);
      toast.error('Failed to load product');
    }
    setIsLoading(false);
  };

  const checkDelivery = () => {
    if (!selectedState) {
      setDeliveryFee(null);
      return;
    }

    const zone = deliveryZones.find(z => 
      z.state.toLowerCase() === selectedState.toLowerCase() && z.is_active
    );

    if (zone) {
      setDeliveryFee(zone.price);
    } else {
      setDeliveryFee(null);
    }
  };

  const handleAddToCart = () => {
    if (!product || !store) return;

    if (product.stock_quantity < quantity) {
      toast.error(`Only ${product.stock_quantity} items available`);
      return;
    }

    // Add to universal cart
    addItem(product, store, quantity);
    toast.success(`${product.name} added to cart!`);
  };

  const handleWishlistToggle = () => {
    if (!product) return;
    
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
      toast.success('Removed from wishlist');
    } else {
      addToWishlist(product.id);
      toast.success('Added to wishlist');
    }
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate(`/my-site/${slug}/checkout`);
  };

  const canDeliverToState = () => {
    if (!selectedState) return null;
    return deliveryFee !== null;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!product || !store) return null;

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-white dark:bg-gray-800 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link 
              to={`/my-site/${slug}`}
              className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Store</span>
            </Link>

            <Link to={`/my-site/${slug}`} className="flex items-center gap-2">
              {store.logo_url ? (
                <img src={store.logo_url} alt={store.name} className="w-8 h-8 rounded-lg object-cover" />
              ) : (
                <div 
                  className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: store.primary_color || theme?.colors.primary }}
                >
                  <span className="text-white font-bold">{store.name.charAt(0)}</span>
                </div>
              )}
              <span className="font-semibold text-gray-900 dark:text-white hidden sm:block">{store.name}</span>
            </Link>

            <Link to="/cart" className="relative p-2">
              <ShoppingCart className="w-6 h-6 text-gray-600 dark:text-gray-300" />
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-6">
          <Link to={`/my-site/${slug}`} className="hover:text-orange-500">{store.name}</Link>
          <span>/</span>
          <span>{product.category || 'Products'}</span>
          <span>/</span>
          <span className="text-gray-900 dark:text-white">{product.name}</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Product Images with Invisible Tap Navigation */}
          <div className="space-y-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="aspect-square bg-gray-100 dark:bg-gray-800 rounded-2xl overflow-hidden relative group"
            >
              {product.images && product.images.length > 0 ? (
                <>
                  <img 
                    src={product.images[selectedImage]} 
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Invisible Tap Navigation */}
                  {product.images.length > 1 && (
                    <>
                      {/* Left Tap Area */}
                      <button
                        onClick={() => setSelectedImage(prev => prev > 0 ? prev - 1 : product.images.length - 1)}
                        className="absolute left-0 top-0 h-full w-1/4 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-start pl-4"
                        aria-label="Previous image"
                      >
                        <div className="w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-white">
                          ‹
                        </div>
                      </button>
                      
                      {/* Right Tap Area */}
                      <button
                        onClick={() => setSelectedImage(prev => prev < product.images.length - 1 ? prev + 1 : 0)}
                        className="absolute right-0 top-0 h-full w-1/4 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-end pr-4"
                        aria-label="Next image"
                      >
                        <div className="w-10 h-10 bg-black/50 rounded-full flex items-center justify-center text-white">
                          ›
                        </div>
                      </button>
                      
                      {/* Image Counter */}
                      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-3 py-1 bg-black/50 rounded-full text-white text-sm">
                        {selectedImage + 1} / {product.images.length}
                      </div>
                    </>
                  )}
                </>
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <span className="text-6xl text-gray-300">{product.name.charAt(0)}</span>
                </div>
              )}
            </motion.div>

            {/* Thumbnail Gallery */}
            {product.images && product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-20 h-20 rounded-lg overflow-hidden flex-shrink-0 border-2 transition-colors ${
                      selectedImage === idx ? 'border-orange-500' : 'border-transparent'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-2">
                {product.name}
              </h1>
              <p className="text-gray-500 dark:text-gray-400">{product.category}</p>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-4">
              <span 
                className="text-3xl sm:text-4xl font-bold"
                style={{ color: store.primary_color || theme?.colors.primary }}
              >
                ₦{product.selling_price.toLocaleString()}
              </span>
              {product.cost_price > 0 && product.cost_price < product.selling_price && (
                <span className="text-lg text-gray-400 line-through">
                  ₦{Math.round(product.selling_price * 1.2).toLocaleString()}
                </span>
              )}
            </div>

            {/* Stock Status */}
            <div className="flex items-center gap-4">
              {product.stock_quantity === 0 ? (
                <span className="flex items-center gap-2 text-red-500">
                  <AlertCircle className="w-5 h-5" />
                  Out of Stock
                </span>
              ) : product.stock_quantity <= 5 ? (
                <span className="flex items-center gap-2 text-orange-500">
                  <Clock className="w-5 h-5" />
                  Only {product.stock_quantity} left!
                </span>
              ) : (
                <span className="flex items-center gap-2 text-green-500">
                  <Check className="w-5 h-5" />
                  In Stock ({product.stock_quantity} available)
                </span>
              )}
            </div>

            {/* Description */}
            {product.description && (
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Description</h3>
                <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{product.description}</p>
              </div>
            )}

            {/* Delivery Location */}
            <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Delivery Location
              </h3>
              <select
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none"
              >
                <option value="">Select your state</option>
                {nigerianStates.map(state => (
                  <option key={state} value={state}>{state}</option>
                ))}
              </select>

              {/* Delivery Status */}
              {selectedState && (
                <div className="mt-3">
                  {canDeliverToState() === true ? (
                    <div className="flex items-center gap-2 text-green-600 dark:text-green-400">
                      <Truck className="w-5 h-5" />
                      <span>Delivery available - ₦{deliveryFee?.toLocaleString()}</span>
                    </div>
                  ) : (
                    <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3 mt-3">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="font-medium text-red-800 dark:text-red-300">
                            Delivery Not Available
                          </p>
                          <p className="text-sm text-red-600 dark:text-red-400 mt-1">
                            Sorry, this seller doesn't deliver to {selectedState} yet.
                          </p>
                          <button
                            onClick={() => setShowContactModal(true)}
                            className="text-sm text-orange-600 hover:text-orange-700 dark:text-orange-400 dark:hover:text-orange-300 mt-2 font-medium"
                          >
                            Contact seller to request delivery →
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Quantity Selector */}
            {product.stock_quantity > 0 && (
              <div className="flex items-center gap-4">
                <span className="font-medium text-gray-700 dark:text-gray-300">Quantity:</span>
                <div className="flex items-center border border-gray-200 dark:border-gray-600 rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    disabled={quantity <= 1}
                    className="p-3 hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center font-medium dark:text-white">{quantity}</span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))}
                    disabled={quantity >= product.stock_quantity}
                    className="p-3 hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={handleAddToCart}
                disabled={product.stock_quantity === 0 || (selectedState !== '' && !canDeliverToState())}
                className="flex-1 h-14 text-lg font-medium"
                style={{ 
                  backgroundColor: product.stock_quantity === 0 ? '#9CA3AF' : (store.primary_color || theme?.colors.primary),
                }}
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                {product.stock_quantity === 0 ? 'Out of Stock' : 'Add to Cart'}
              </Button>

              <Button
                onClick={handleBuyNow}
                disabled={product.stock_quantity === 0 || (selectedState !== '' && !canDeliverToState())}
                className="flex-1 h-14 text-lg font-medium bg-gray-900 hover:bg-gray-800 dark:bg-white dark:text-gray-900 dark:hover:bg-gray-100"
              >
                Buy Now
              </Button>

              <button
                onClick={handleWishlistToggle}
                className={`p-4 rounded-lg border-2 transition-colors ${
                  isInWishlist(product?.id || '') 
                    ? 'border-red-500 text-red-500' 
                    : 'border-gray-200 dark:border-gray-600 text-gray-400 hover:border-gray-300'
                }`}
              >
                <Heart className={`w-6 h-6 ${isInWishlist(product?.id || '') ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t dark:border-gray-700">
              <div className="text-center">
                <Truck className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600 dark:text-gray-400">Fast Delivery</p>
              </div>
              <div className="text-center">
                <Shield className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600 dark:text-gray-400">Secure Payment</p>
              </div>
              <div className="text-center">
                <Clock className="w-6 h-6 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600 dark:text-gray-400">7-Day Returns</p>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mt-16">
          <Reviews productId={productId!} storeId={store.id} />
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">You May Also Like</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {relatedProducts.map((related) => (
                <Link
                  key={related.id}
                  to={`/my-site/${slug}/product/${related.id}`}
                  className="group bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="aspect-square bg-gray-100 dark:bg-gray-700">
                    {related.images?.[0] ? (
                      <img src={related.images[0]} alt={related.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <span className="text-4xl text-gray-300">{related.name.charAt(0)}</span>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium text-gray-900 dark:text-white line-clamp-1">{related.name}</h3>
                    <p className="font-bold mt-1" style={{ color: store.primary_color || theme?.colors.primary }}>
                      ₦{related.selling_price.toLocaleString()}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Contact Seller Modal */}
      {showContactModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-gray-800 rounded-2xl max-w-md w-full p-6"
          >
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">Contact Seller</h3>
              <button onClick={() => setShowContactModal(false)}>
                <span className="text-2xl text-gray-400">&times;</span>
              </button>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600 dark:text-gray-300">
                Ask <strong>{store.name}</strong> about delivery to <strong>{selectedState}</strong>:
              </p>

              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 space-y-3">
                {store.social_links?.whatsapp && (
                  <a 
                    href={`https://wa.me/${store.social_links.whatsapp}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-green-600 hover:text-green-700"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span>Chat on WhatsApp</span>
                  </a>
                )}
                
                <a 
                  href={`mailto:support@qafrica.store?subject=Delivery Request for ${store.name}`}
                  className="flex items-center gap-3 text-blue-600 hover:text-blue-700"
                >
                  <span className="w-5 h-5 flex items-center justify-center">@</span>
                  <span>Send Email</span>
                </a>

                <div className="flex items-center gap-3 text-gray-600 dark:text-gray-400">
                  <StoreIcon className="w-5 h-5" />
                  <span>Store: {store.name}</span>
                </div>
              </div>

              <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-4">
                <p className="text-sm text-orange-800 dark:text-orange-300">
                  <strong>Tip:</strong> Mention that you're interested in buying {product.name} and would like delivery to {selectedState}.
                </p>
              </div>

              <Button
                onClick={() => setShowContactModal(false)}
                className="w-full bg-gray-900 hover:bg-gray-800 dark:bg-white dark:text-gray-900"
              >
                Close
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
