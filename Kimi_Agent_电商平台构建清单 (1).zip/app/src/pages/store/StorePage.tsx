import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ShoppingCart, Search, Menu, X, Phone, Mail,
  Instagram, Facebook, Twitter, Heart, Filter,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { StoreSEO } from '@/components/SEO';
import { storeService, productService } from '@/services/supabase';
import { toast } from 'sonner';
import { getThemeById } from '@/lib/themes';
import type { Store, Product } from '@/types';

export default function StorePage() {
  const { slug } = useParams<{ slug: string }>();
  const [store, setStore] = useState<Store | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [cart, setCart] = useState<Product[]>([]);
  const [showCart, setShowCart] = useState(false);

  const theme = store?.theme ? getThemeById(store.theme) : getThemeById('modern');

  useEffect(() => {
    if (slug) {
      loadStore();
    }
  }, [slug]);

  useEffect(() => {
    filterProducts();
  }, [products, searchQuery, selectedCategory]);

  const loadStore = async () => {
    setIsLoading(true);
    try {
      const { data: storeData, error: storeError } = await storeService.getStoreBySlug(slug!);
      
      if (storeError || !storeData) {
        toast.error('Store not found');
        setIsLoading(false);
        return;
      }

      setStore(storeData as Store);

      // Load products
      const { data: productsData } = await productService.getStoreProducts(storeData.id);
      if (productsData) {
        const activeProducts = (productsData as Product[]).filter(p => p.is_active);
        setProducts(activeProducts);
        setFilteredProducts(activeProducts);
      }
    } catch (err) {
      console.error('Error loading store:', err);
      toast.error('Failed to load store');
    }
    setIsLoading(false);
  };

  const filterProducts = () => {
    let filtered = products;

    if (searchQuery) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(p => p.category === selectedCategory);
    }

    setFilteredProducts(filtered);
  };

  const removeFromCart = (index: number) => {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.selling_price, 0);

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category).filter(Boolean)))];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!store) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Store Not Found</h1>
          <p className="text-gray-500">The store you're looking for doesn't exist.</p>
          <Link to="/">
            <Button className="mt-4 bg-orange-500 hover:bg-orange-600 text-white">
              Go Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* SEO */}
      <StoreSEO
        storeName={store.name}
        storeDescription={store.description}
        storeLogo={store.logo_url}
        storeUrl={`${window.location.origin}/my-site/${slug}`}
      />

      {/* Header */}
      <header 
        className="sticky top-0 z-40 border-b"
        style={{ backgroundColor: theme?.colors.background }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to={`/my-site/${slug}`} className="flex items-center gap-3">
              {store.logo_url ? (
                <img src={store.logo_url} alt={store.name} className="w-10 h-10 rounded-lg object-cover" />
              ) : (
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: store.primary_color || theme?.colors.primary }}
                >
                  <span className="text-white font-bold text-lg">
                    {store.name.charAt(0)}
                  </span>
                </div>
              )}
              <span className="font-bold text-xl" style={{ color: theme?.colors.text }}>
                {store.name}
              </span>
            </Link>

            {/* Desktop Search */}
            <div className="hidden md:flex flex-1 max-w-md mx-8">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search products..."
                  className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2"
                  style={{ 
                    borderColor: theme?.colors.secondary,
                    '--tw-ring-color': store.primary_color || theme?.colors.primary 
                  } as React.CSSProperties}
                />
              </div>
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-4">
              {/* Cart */}
              <button
                onClick={() => setShowCart(true)}
                className="relative p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <ShoppingCart className="w-6 h-6" style={{ color: theme?.colors.text }} />
                {cart.length > 0 && (
                  <span 
                    className="absolute -top-1 -right-1 w-5 h-5 text-white text-xs rounded-full flex items-center justify-center"
                    style={{ backgroundColor: store.primary_color || theme?.colors.primary }}
                  >
                    {cart.length}
                  </span>
                )}
              </button>

              {/* Mobile Menu */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="md:hidden border-t bg-white"
          >
            <div className="px-4 py-4 space-y-4">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search products..."
                className="w-full px-4 py-2 border rounded-lg"
              />
              <div className="flex flex-wrap gap-2">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedCategory === cat 
                        ? 'text-white' 
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                    style={selectedCategory === cat ? { backgroundColor: store.primary_color || theme?.colors.primary } : {}}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </header>

      {/* Hero Banner */}
      {store.banner_url && (
        <div className="relative h-64 md:h-80">
          <img 
            src={store.banner_url} 
            alt={store.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
            <div className="text-center text-white px-4">
              <h1 className="text-3xl md:text-5xl font-bold mb-2">{store.name}</h1>
              {store.description && (
                <p className="text-lg md:text-xl opacity-90">{store.description}</p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Category Filter - Desktop */}
        <div className="hidden md:flex items-center gap-2 mb-8 overflow-x-auto pb-2">
          <Filter className="w-5 h-5 text-gray-400 mr-2" />
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                selectedCategory === cat 
                  ? 'text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              style={selectedCategory === cat ? { backgroundColor: store.primary_color || theme?.colors.primary } : {}}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-500">Try adjusting your search or filter</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="group bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg transition-shadow"
              >
                {/* Product Image */}
                <div className="aspect-square bg-gray-100 relative overflow-hidden">
                  {product.images && product.images.length > 0 ? (
                    <img 
                      src={product.images[0]} 
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-4xl text-gray-300">
                        {product.name.charAt(0)}
                      </span>
                    </div>
                  )}
                  
                  {/* Quick Actions */}
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-2 bg-white rounded-full shadow-md hover:bg-gray-50">
                      <Heart className="w-4 h-4 text-gray-600" />
                    </button>
                  </div>
                </div>

                {/* Product Info */}
                <Link to={`/my-site/${slug}/product/${product.id}`} className="block p-4">
                  <h3 className="font-medium text-gray-900 dark:text-white mb-1 line-clamp-2 hover:text-orange-500 transition-colors">{product.name}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-2 line-clamp-1">{product.category}</p>
                  
                  <div className="flex items-center justify-between">
                    <p 
                      className="text-lg font-bold"
                      style={{ color: store.primary_color || theme?.colors.primary }}
                    >
                      ₦{product.selling_price.toLocaleString()}
                    </p>
                    <span className="text-sm text-orange-500 font-medium">View →</span>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Store Info */}
            <div>
              <h3 className="text-lg font-bold mb-4">{store.name}</h3>
              {store.description && (
                <p className="text-gray-400 mb-4">{store.description}</p>
              )}
              <div className="flex gap-4">
                {store.social_links?.instagram && (
                  <a href={store.social_links.instagram} target="_blank" rel="noopener noreferrer"
                     className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700">
                    <Instagram className="w-5 h-5" />
                  </a>
                )}
                {store.social_links?.facebook && (
                  <a href={store.social_links.facebook} target="_blank" rel="noopener noreferrer"
                     className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700">
                    <Facebook className="w-5 h-5" />
                  </a>
                )}
                {store.social_links?.twitter && (
                  <a href={store.social_links.twitter} target="_blank" rel="noopener noreferrer"
                     className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700">
                    <Twitter className="w-5 h-5" />
                  </a>
                )}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-lg font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to={`/my-site/${slug}`} className="hover:text-white">Home</Link></li>
                <li><Link to={`/my-site/${slug}/products`} className="hover:text-white">Products</Link></li>
                <li><Link to={`/my-site/${slug}/about`} className="hover:text-white">About Us</Link></li>
                <li><Link to={`/my-site/${slug}/contact`} className="hover:text-white">Contact</Link></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-lg font-bold mb-4">Contact Us</h3>
              <ul className="space-y-3 text-gray-400">
                <li className="flex items-center gap-3">
                  <Phone className="w-5 h-5" />
                  <span>Contact via store owner</span>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="w-5 h-5" />
                  <span>support@qafrica.store</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
            <p>© {new Date().getFullYear()} {store.name}. Powered by QAFRICA</p>
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      {showCart && (
        <>
          <div 
            className="fixed inset-0 bg-black/50 z-50"
            onClick={() => setShowCart(false)}
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-xl"
          >
            <div className="flex flex-col h-full">
              {/* Cart Header */}
              <div className="flex items-center justify-between p-4 border-b">
                <h2 className="text-lg font-bold">Shopping Cart ({cart.length})</h2>
                <button onClick={() => setShowCart(false)}>
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Cart Items */}
              <div className="flex-1 overflow-y-auto p-4">
                {cart.length === 0 ? (
                  <div className="text-center py-8">
                    <ShoppingCart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Your cart is empty</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {cart.map((item, index) => (
                      <div key={index} className="flex gap-4 p-4 bg-gray-50 rounded-lg">
                        {item.images?.[0] ? (
                          <img src={item.images[0]} alt={item.name} className="w-20 h-20 object-cover rounded-lg" />
                        ) : (
                          <div className="w-20 h-20 bg-gray-200 rounded-lg flex items-center justify-center">
                            <span className="text-2xl text-gray-400">{item.name.charAt(0)}</span>
                          </div>
                        )}
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{item.name}</h4>
                          <p className="text-orange-600 font-bold">₦{item.selling_price.toLocaleString()}</p>
                        </div>
                        <button
                          onClick={() => removeFromCart(index)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <X className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Cart Footer */}
              {cart.length > 0 && (
                <div className="border-t p-4 space-y-4">
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total:</span>
                    <span>₦{cartTotal.toLocaleString()}</span>
                  </div>
                  <Button 
                    className="w-full text-white"
                    style={{ backgroundColor: store.primary_color || theme?.colors.primary }}
                    onClick={() => toast.info('Checkout coming soon!')}
                  >
                    Proceed to Checkout
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </div>
  );
}
