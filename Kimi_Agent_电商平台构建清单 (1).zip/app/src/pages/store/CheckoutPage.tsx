import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, MapPin, User,
  CreditCard, Check, AlertCircle, Lock, Truck, Home,
  Building2, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { storeService, deliveryZoneService, authService } from '@/services/supabase';
import { loadPaystackScript, initializePayment, generateReference } from '@/services/paystack';
import { toast } from 'sonner';
import { getThemeById } from '@/lib/themes';
import type { Store, DeliveryZone } from '@/types';

interface CartItem {
  productId: string;
  name: string;
  price: number;
  image?: string;
  quantity: number;
  storeId: string;
  storeName: string;
}

export default function CheckoutPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [store, setStore] = useState<Store | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [deliveryZones, setDeliveryZones] = useState<DeliveryZone[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Checkout steps
  const [currentStep, setCurrentStep] = useState<'auth' | 'shipping' | 'payment' | 'confirm'>('auth');
  
  // Auth state
  const [, setIsLoggedIn] = useState(false);
  
  // Shipping form
  const [shippingForm, setShippingForm] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    deliveryInstructions: '',
  });
  
  // Payment form
  const [paymentMethod, setPaymentMethod] = useState<'paystack' | 'cod'>('paystack');
  
  const theme = store?.theme ? getThemeById(store.theme) : getThemeById('modern');

  // Nigerian states
  const nigerianStates = [
    'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa', 'Benue', 
    'Borno', 'Cross River', 'Delta', 'Ebonyi', 'Edo', 'Ekiti', 'Enugu', 'FCT',
    'Gombe', 'Imo', 'Jigawa', 'Kaduna', 'Kano', 'Katsina', 'Kebbi', 'Kogi', 
    'Kwara', 'Lagos', 'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun', 'Oyo', 
    'Plateau', 'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara'
  ];

  useEffect(() => {
    checkAuth();
    loadData();
  }, [slug]);

  const checkAuth = async () => {
    const { session } = await authService.getSession();
    if (session?.user) {
      setIsLoggedIn(true);
      setCurrentStep('shipping');
      // Pre-fill email if logged in
      setShippingForm(prev => ({ ...prev, email: session.user.email || '' }));
    }
  };

  const loadData = async () => {
    if (!slug) return;
    
    // Load cart
    const cartKey = `cart_${slug}`;
    const cart = JSON.parse(localStorage.getItem(cartKey) || '[]');
    
    if (cart.length === 0) {
      toast.error('Your cart is empty');
      navigate(`/my-site/${slug}`);
      return;
    }

    setCartItems(cart);

    // Load store
    const { data: storeData } = await storeService.getStoreBySlug(slug);
    if (storeData) {
      setStore(storeData as Store);
      
      // Load delivery zones
      const { data: zonesData } = await deliveryZoneService.getStoreZones(storeData.id);
      if (zonesData) {
        setDeliveryZones(zonesData as DeliveryZone[]);
      }
    }

    setIsLoading(false);
  };

  const PLATFORM_DELIVERY_MARKUP = 500; // ₦500 platform markup on all delivery fees

  const getDeliveryFee = () => {
    if (!shippingForm.state) return 0;
    const zone = deliveryZones.find(z => 
      z.state.toLowerCase() === shippingForm.state.toLowerCase() && z.is_active
    );
    return (zone?.price || 0) + PLATFORM_DELIVERY_MARKUP;
  };

  const canDeliverToState = () => {
    if (!shippingForm.state) return true; // Don't block yet
    const zone = deliveryZones.find(z => 
      z.state.toLowerCase() === shippingForm.state.toLowerCase() && z.is_active
    );
    return !!zone;
  };

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const deliveryFee = getDeliveryFee();
  const total = subtotal + deliveryFee;

  const handleBuyerSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    // For buyers, we just collect info - no account creation needed
    // But we store it for the order
    setIsLoggedIn(true);
    setCurrentStep('shipping');
    toast.success('Welcome! Please enter your shipping details.');
  };

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!canDeliverToState()) {
      toast.error(`Sorry, delivery is not available to ${shippingForm.state}`);
      return;
    }
    
    setCurrentStep('payment');
  };

  const handlePayment = async () => {
    if (paymentMethod === 'cod') {
      // Cash on Delivery - skip payment
      setIsProcessing(true);
      
      // Create order in database (would be done here)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Clear cart
      const cartKey = `cart_${slug}`;
      localStorage.removeItem(cartKey);
      
      setIsProcessing(false);
      setCurrentStep('confirm');
      toast.success('Order placed successfully! Pay on delivery.');
      return;
    }

    // Paystack payment
    try {
      setIsProcessing(true);
      
      // Load Paystack script
      await loadPaystackScript();
      
      const reference = generateReference('ORD');
      const amountInKobo = total * 100; // Paystack expects amount in kobo
      
      initializePayment({
        email: shippingForm.email,
        amount: amountInKobo,
        reference,
        metadata: {
          store_id: store?.id,
          store_name: store?.name,
          customer_name: shippingForm.fullName,
          customer_phone: shippingForm.phone,
          delivery_address: `${shippingForm.address}, ${shippingForm.city}, ${shippingForm.state}`,
          items: cartItems.map(item => ({
            product_id: item.productId,
            name: item.name,
            quantity: item.quantity,
            price: item.price,
          })),
        },
        onSuccess: async (response) => {
          // Payment successful
          toast.success('Payment successful!');
          
          // Create order in database (would be done here with the transaction reference)
          console.log('Payment reference:', response.reference);
          
          // Clear cart
          const cartKey = `cart_${slug}`;
          localStorage.removeItem(cartKey);
          
          setIsProcessing(false);
          setCurrentStep('confirm');
        },
        onCancel: () => {
          setIsProcessing(false);
          toast.info('Payment cancelled. You can try again.');
        },
      });
    } catch (err) {
      setIsProcessing(false);
      toast.error('Payment initialization failed. Please try again.');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link 
              to={`/my-site/${slug}`}
              className="flex items-center gap-2 text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="hidden sm:inline">Continue Shopping</span>
            </Link>

            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep === 'auth' ? 'bg-orange-500 text-white' : 'bg-green-500 text-white'
              }`}>
                {currentStep === 'auth' ? '1' : <Check className="w-4 h-4" />}
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400" />
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep === 'shipping' ? 'bg-orange-500 text-white' : 
                currentStep === 'payment' || currentStep === 'confirm' ? 'bg-green-500 text-white' : 'bg-gray-200 dark:bg-gray-700'
              }`}>
                {currentStep === 'shipping' ? '2' : currentStep === 'payment' || currentStep === 'confirm' ? <Check className="w-4 h-4" /> : '2'}
              </div>
              <ChevronRight className="w-4 h-4 text-gray-400" />
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep === 'payment' ? 'bg-orange-500 text-white' : 
                currentStep === 'confirm' ? 'bg-green-500 text-white' : 'bg-gray-200 dark:bg-gray-700'
              }`}>
                {currentStep === 'payment' ? '3' : currentStep === 'confirm' ? <Check className="w-4 h-4" /> : '3'}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Auth Step */}
        {currentStep === 'auth' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-md mx-auto"
          >
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-8">
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User className="w-8 h-8 text-orange-500" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                  Checkout as Guest
                </h2>
                <p className="text-gray-500 dark:text-gray-400">
                  Enter your details to continue with your order
                </p>
              </div>

              <form onSubmit={handleBuyerSignup} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={shippingForm.fullName}
                    onChange={(e) => setShippingForm({ ...shippingForm, fullName: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none"
                    placeholder="John Doe"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={shippingForm.email}
                    onChange={(e) => setShippingForm({ ...shippingForm, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none"
                    placeholder="john@example.com"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    value={shippingForm.phone}
                    onChange={(e) => setShippingForm({ ...shippingForm, phone: e.target.value })}
                    className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none"
                    placeholder="+234 800 000 0000"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 text-lg font-medium"
                  style={{ backgroundColor: store?.primary_color || theme?.colors.primary }}
                >
                  Continue to Shipping
                  <ArrowLeft className="w-5 h-5 ml-2 rotate-180" />
                </Button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                  Already have an account?{' '}
                  <Link to="/login" className="text-orange-500 hover:text-orange-600 font-medium">
                    Sign in
                  </Link>
                </p>
              </div>
            </div>
          </motion.div>
        )}

        {/* Shipping Step */}
        {currentStep === 'shipping' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="grid lg:grid-cols-3 gap-8"
          >
            {/* Shipping Form */}
            <div className="lg:col-span-2">
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-6">
                <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  Shipping Address
                </h2>

                <form onSubmit={handleShippingSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Street Address *
                      </label>
                      <div className="relative">
                        <Home className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          value={shippingForm.address}
                          onChange={(e) => setShippingForm({ ...shippingForm, address: e.target.value })}
                          className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none"
                          placeholder="123 Main Street"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        City *
                      </label>
                      <div className="relative">
                        <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          value={shippingForm.city}
                          onChange={(e) => setShippingForm({ ...shippingForm, city: e.target.value })}
                          className="w-full pl-10 pr-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none"
                          placeholder="Lagos"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        State *
                      </label>
                      <select
                        value={shippingForm.state}
                        onChange={(e) => setShippingForm({ ...shippingForm, state: e.target.value })}
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none"
                        required
                      >
                        <option value="">Select state</option>
                        {nigerianStates.map(state => (
                          <option key={state} value={state}>{state}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Delivery Check */}
                  {shippingForm.state && (
                    <div className="mt-4">
                      {canDeliverToState() ? (
                        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                          <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                            <Truck className="w-5 h-5" />
                            <span className="font-medium">Delivery available to {shippingForm.state}</span>
                          </div>
                          <p className="text-sm text-green-600 dark:text-green-400 mt-1">
                            Delivery fee: ₦{deliveryFee.toLocaleString()}
                          </p>
                        </div>
                      ) : (
                        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                          <div className="flex items-start gap-3">
                            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="font-medium text-red-800 dark:text-red-300">
                                Delivery Not Available
                              </p>
                              <p className="text-sm text-red-600 dark:text-red-400 mt-1">
                                Sorry, {store?.name} doesn't deliver to {shippingForm.state} yet.
                              </p>
                              <Link
                                to={`/my-site/${slug}`}
                                className="text-sm text-orange-600 hover:text-orange-700 dark:text-orange-400 mt-2 inline-block"
                              >
                                ← Continue shopping
                              </Link>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Delivery Instructions (Optional)
                    </label>
                    <textarea
                      value={shippingForm.deliveryInstructions}
                      onChange={(e) => setShippingForm({ ...shippingForm, deliveryInstructions: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 outline-none"
                      rows={3}
                      placeholder="Any special instructions for delivery..."
                    />
                  </div>

                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => setCurrentStep('auth')}
                      className="px-6 py-3 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                    >
                      Back
                    </button>
                    <Button
                      type="submit"
                      className="flex-1 h-12 text-lg font-medium"
                      disabled={!canDeliverToState()}
                      style={{ backgroundColor: store?.primary_color || theme?.colors.primary }}
                    >
                      Continue to Payment
                      <ArrowLeft className="w-5 h-5 ml-2 rotate-180" />
                    </Button>
                  </div>
                </form>
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-6 sticky top-24">
                <h3 className="font-bold text-gray-900 dark:text-white mb-4">Order Summary</h3>
                
                <div className="space-y-4 mb-6">
                  {cartItems.map((item, idx) => (
                    <div key={idx} className="flex gap-3">
                      {item.image ? (
                        <img src={item.image} alt={item.name} className="w-16 h-16 rounded-lg object-cover" />
                      ) : (
                        <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-lg flex items-center justify-center">
                          <span className="text-xl text-gray-400">{item.name.charAt(0)}</span>
                        </div>
                      )}
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-white line-clamp-1">{item.name}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Qty: {item.quantity}</p>
                        <p className="text-sm font-medium">₦{(item.price * item.quantity).toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t dark:border-gray-700 pt-4 space-y-2">
                  <div className="flex justify-between text-gray-600 dark:text-gray-400">
                    <span>Subtotal</span>
                    <span>₦{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-gray-600 dark:text-gray-400">
                    <span>Delivery</span>
                    <span>{deliveryFee > 0 ? `₦${deliveryFee.toLocaleString()}` : 'Free'}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold text-gray-900 dark:text-white pt-2 border-t dark:border-gray-700">
                    <span>Total</span>
                    <span>₦{total.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Payment Step */}
        {currentStep === 'payment' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-2xl mx-auto"
          >
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Payment Method
              </h2>

              {/* Payment Options */}
              <div className="space-y-4 mb-8">
                <button
                  onClick={() => setPaymentMethod('paystack')}
                  className={`w-full p-4 rounded-xl border-2 flex items-center gap-4 transition-colors ${
                    paymentMethod === 'paystack'
                      ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/20'
                      : 'border-gray-200 dark:border-gray-600 hover:border-gray-300'
                  }`}
                >
                  <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                    <CreditCard className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-gray-900 dark:text-white">Pay with Card</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Secure payment via Paystack</p>
                  </div>
                  {paymentMethod === 'paystack' && <Check className="w-6 h-6 text-orange-500" />}
                </button>

                <button
                  onClick={() => setPaymentMethod('cod')}
                  className={`w-full p-4 rounded-xl border-2 flex items-center gap-4 transition-colors ${
                    paymentMethod === 'cod'
                      ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/20'
                      : 'border-gray-200 dark:border-gray-600 hover:border-gray-300'
                  }`}
                >
                  <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
                    <Truck className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-gray-900 dark:text-white">Cash on Delivery</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Pay when you receive your order</p>
                  </div>
                  {paymentMethod === 'cod' && <Check className="w-6 h-6 text-orange-500" />}
                </button>
              </div>

              {/* Order Summary */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4 mb-6">
                <h3 className="font-medium text-gray-900 dark:text-white mb-3">Order Total</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-gray-600 dark:text-gray-400">
                    <span>Subtotal ({cartItems.reduce((a, b) => a + b.quantity, 0)} items)</span>
                    <span>₦{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-gray-600 dark:text-gray-400">
                    <span>Delivery</span>
                    <span>{deliveryFee > 0 ? `₦${deliveryFee.toLocaleString()}` : 'Free'}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold text-gray-900 dark:text-white pt-2 border-t dark:border-gray-600">
                    <span>Total</span>
                    <span>₦{total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Security Note */}
              <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-6">
                <Lock className="w-4 h-4" />
                <span>Your payment information is secure and encrypted</span>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={() => setCurrentStep('shipping')}
                  className="px-6 py-3 border border-gray-200 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                  Back
                </button>
                <Button
                  onClick={handlePayment}
                  disabled={isProcessing}
                  className="flex-1 h-14 text-lg font-medium"
                  style={{ backgroundColor: store?.primary_color || theme?.colors.primary }}
                >
                  {isProcessing ? (
                    <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      Pay ₦{total.toLocaleString()}
                      <ArrowLeft className="w-5 h-5 ml-2 rotate-180" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Confirmation Step */}
        {currentStep === 'confirm' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-md mx-auto text-center"
          >
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-8">
              <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
                <Check className="w-10 h-10 text-green-500" />
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                Order Confirmed!
              </h2>
              <p className="text-gray-500 dark:text-gray-400 mb-6">
                Thank you for your order. We've sent a confirmation email to {shippingForm.email}
              </p>

              <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4 mb-6 text-left">
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Order Total</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">₦{total.toLocaleString()}</p>
              </div>

              <div className="space-y-3">
                <Link to={`/my-site/${slug}`}>
                  <Button
                    className="w-full h-12"
                    style={{ backgroundColor: store?.primary_color || theme?.colors.primary }}
                  >
                    Continue Shopping
                  </Button>
                </Link>
                <Link to="/">
                  <Button variant="outline" className="w-full h-12">
                    Back to QAFRICA
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
}
