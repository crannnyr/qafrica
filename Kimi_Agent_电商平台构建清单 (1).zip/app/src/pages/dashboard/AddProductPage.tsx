import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Loader2, Check, X, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStoreStore, useAuthStore } from '@/stores';
import { toast } from 'sonner';
import { supabase } from '@/services/supabase';
import { getNicheCategories, getSubcategories } from '@/lib/nicheCategories';

// Image upload component
function MultiImageUpload({ 
  value, 
  onChange, 
  maxImages = 5 
}: { 
  value: string[]; 
  onChange: (urls: string[]) => void;
  maxImages?: number;
}) {
  const [uploading, setUploading] = useState(false);
  const { currentStore } = useStoreStore();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const remainingSlots = maxImages - value.length;
    const filesToUpload = Array.from(files).slice(0, remainingSlots);

    if (filesToUpload.length === 0) {
      toast.error(`Maximum ${maxImages} images allowed`);
      return;
    }

    setUploading(true);
    const uploadedUrls: string[] = [];

    for (const file of filesToUpload) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error(`${file.name} is too large (max 5MB)`);
        continue;
      }

      const fileName = `${currentStore?.id || 'general'}/${Date.now()}_${file.name}`;
      
      try {
        const { error } = await supabase.storage
          .from('products')
          .upload(fileName, file);

        if (error) throw error;

        const { data: { publicUrl } } = supabase.storage
          .from('products')
          .getPublicUrl(fileName);

        uploadedUrls.push(publicUrl);
      } catch (err) {
        console.error('Upload error:', err);
        toast.error(`Failed to upload ${file.name}`);
      }
    }

    onChange([...value, ...uploadedUrls]);
    setUploading(false);
  };

  const removeImage = (index: number) => {
    onChange(value.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-4">
      {/* Image Preview Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-5 gap-4">
        {value.map((url, index) => (
          <div key={index} className="relative aspect-square rounded-lg overflow-hidden bg-gray-100 group">
            <img 
              src={url} 
              alt={`Product ${index + 1}`}
              className="w-full h-full object-cover"
            />
            <button
              type="button"
              onClick={() => removeImage(index)}
              className="absolute top-2 right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="w-4 h-4" />
            </button>
            {index === 0 && (
              <span className="absolute bottom-2 left-2 px-2 py-1 bg-orange-500 text-white text-xs rounded">
                Main
              </span>
            )}
          </div>
        ))}
        
        {/* Add Image Button */}
        {value.length < maxImages && (
          <label className="aspect-square rounded-lg border-2 border-dashed border-gray-300 hover:border-orange-500 flex flex-col items-center justify-center cursor-pointer transition-colors">
            <Plus className="w-8 h-8 text-gray-400" />
            <span className="text-sm text-gray-500 mt-2">Add Image</span>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileChange}
              className="hidden"
              disabled={uploading}
            />
          </label>
        )}
      </div>

      {uploading && (
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <Loader2 className="w-4 h-4 animate-spin" />
          Uploading...
        </div>
      )}

      <p className="text-sm text-gray-500">
        {value.length} of {maxImages} images • First image is the main image
      </p>
    </div>
  );
}

export default function AddProductPage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { currentStore, addProduct } = useStoreStore();
  const [isLoading, setIsLoading] = useState(false);
  const [images, setImages] = useState<string[]>([]);
  
  // Get categories from store niches
  const storeNiches = currentStore?.niches || [];
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    niche: '',
    category: '',
    subcategory: '',
    cost_price: '',
    selling_price: '',
    dropship_price: '',
    wholesale_price: '',
    stock_quantity: '',
    low_stock_threshold: '10',
    is_importable: true,
    has_variants: false,
  });

  const selectedNicheCategories = formData.niche 
    ? getNicheCategories(formData.niche) 
    : [];
  
  const selectedCategorySubcategories = formData.niche && formData.category
    ? getSubcategories(formData.niche, formData.category)
    : [];

  const validateForm = () => {
    if (!formData.name || !formData.selling_price || !formData.stock_quantity) {
      toast.error('Please fill in all required fields');
      return false;
    }

    if (!formData.niche || !formData.category) {
      toast.error('Please select a niche and category');
      return false;
    }

    const sellingPrice = parseFloat(formData.selling_price);
    const dropshipPrice = parseFloat(formData.dropship_price) || 0;
    const wholesalePrice = parseFloat(formData.wholesale_price) || 0;

    if (dropshipPrice > 0 && dropshipPrice >= sellingPrice) {
      toast.error('Dropship price must be lower than selling price');
      return false;
    }

    if (wholesalePrice > 0 && wholesalePrice >= sellingPrice) {
      toast.error('Wholesale price must be lower than selling price');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;
    if (!currentStore?.id) {
      toast.error('Store not found');
      return;
    }

    setIsLoading(true);

    const stockQty = parseInt(formData.stock_quantity);
    const lowStockThreshold = parseInt(formData.low_stock_threshold) || 10;
    
    const result = await addProduct({
      store_id: currentStore.id,
      owner_id: user?.id,
      name: formData.name,
      description: formData.description,
      category: formData.category,
      subcategory: formData.subcategory,
      cost_price: parseFloat(formData.cost_price) || 0,
      selling_price: parseFloat(formData.selling_price),
      dropship_price: parseFloat(formData.dropship_price) || 0,
      wholesale_price: parseFloat(formData.wholesale_price) || 0,
      stock_quantity: stockQty,
      low_stock_threshold: lowStockThreshold,
      is_out_of_stock: stockQty === 0,
      images,
      is_importable: formData.is_importable,
      has_variants: formData.has_variants,
      niche: formData.niche,
      is_active: stockQty > 0,
      views: 0,
      sales_count: 0,
      import_count: 0,
      tags: [],
    });

    if (result.success) {
      toast.success('Product added successfully!');
      navigate('/dashboard/products');
    } else {
      toast.error(result.error || 'Failed to add product');
    }

    setIsLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => navigate('/dashboard/products')}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Add New Product</h1>
          <p className="text-gray-500">Create a new product for your store</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl border border-gray-100 p-6"
        >
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Basic Information</h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Product Name *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                placeholder="Enter product name"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 min-h-[120px]"
                placeholder="Describe your product..."
              />
            </div>
          </div>
        </motion.div>

        {/* Category Selection */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="bg-white rounded-xl border border-gray-100 p-6"
        >
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Category *</h2>
          
          <div className="space-y-6">
            {/* Niche Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Niche
              </label>
              <select
                value={formData.niche}
                onChange={(e) => setFormData({ ...formData, niche: e.target.value, category: '', subcategory: '' })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                required
              >
                <option value="">Select a niche</option>
                {storeNiches.map(nicheId => (
                  <option key={nicheId} value={nicheId}>
                    {nicheId.charAt(0).toUpperCase() + nicheId.slice(1)}
                  </option>
                ))}
              </select>
            </div>

            {/* Category Selection */}
            {formData.niche && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value, subcategory: '' })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                  required
                >
                  <option value="">Select a category</option>
                  {selectedNicheCategories.map(cat => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Subcategory Selection */}
            {formData.category && selectedCategorySubcategories.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Subcategory (Optional)
                </label>
                <select
                  value={formData.subcategory}
                  onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">Select a subcategory</option>
                  {selectedCategorySubcategories.map(sub => (
                    <option key={sub} value={sub}>
                      {sub}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </motion.div>

        {/* Images */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl border border-gray-100 p-6"
        >
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Product Images (Up to 5)</h2>
          
          <MultiImageUpload
            value={images}
            onChange={setImages}
            maxImages={5}
          />
        </motion.div>

        {/* Pricing */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl border border-gray-100 p-6"
        >
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Pricing</h2>
          
          <div className="grid sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cost Price (₦)
              </label>
              <input
                type="number"
                value={formData.cost_price}
                onChange={(e) => setFormData({ ...formData, cost_price: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                placeholder="0.00"
                min="0"
              />
              <p className="text-xs text-gray-500 mt-1">What you paid for the product</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Selling Price (₦) *
              </label>
              <input
                type="number"
                value={formData.selling_price}
                onChange={(e) => setFormData({ ...formData, selling_price: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                placeholder="0.00"
                min="0"
                required
              />
              <p className="text-xs text-gray-500 mt-1">Price customers will pay</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Dropship Price (₦)
              </label>
              <input
                type="number"
                value={formData.dropship_price}
                onChange={(e) => setFormData({ ...formData, dropship_price: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                placeholder="0.00"
                min="0"
              />
              <p className="text-xs text-gray-500 mt-1">Price for dropshippers</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Wholesale Price (₦)
              </label>
              <input
                type="number"
                value={formData.wholesale_price}
                onChange={(e) => setFormData({ ...formData, wholesale_price: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                placeholder="0.00"
                min="0"
              />
              <p className="text-xs text-gray-500 mt-1">Price for bulk orders</p>
            </div>
          </div>
        </motion.div>

        {/* Inventory */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl border border-gray-100 p-6"
        >
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Inventory</h2>
          
          <div className="grid sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Stock Quantity *
              </label>
              <input
                type="number"
                value={formData.stock_quantity}
                onChange={(e) => setFormData({ ...formData, stock_quantity: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                placeholder="0"
                min="0"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Low Stock Alert Threshold
              </label>
              <input
                type="number"
                value={formData.low_stock_threshold}
                onChange={(e) => setFormData({ ...formData, low_stock_threshold: e.target.value })}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500"
                placeholder="10"
                min="1"
              />
              <p className="text-xs text-gray-500 mt-1">You'll be notified when stock falls below this</p>
            </div>
          </div>

          <div className="mt-6 space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.is_importable}
                onChange={(e) => setFormData({ ...formData, is_importable: e.target.checked })}
                className="w-5 h-5 rounded border-gray-300 text-orange-500 focus:ring-orange-500"
              />
              <span className="text-gray-700">Allow other sellers to import this product</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.has_variants}
                onChange={(e) => setFormData({ ...formData, has_variants: e.target.checked })}
                className="w-5 h-5 rounded border-gray-300 text-orange-500 focus:ring-orange-500"
              />
              <span className="text-gray-700">This product has variants (size, color, etc.)</span>
            </label>
          </div>
        </motion.div>

        {/* Submit Buttons */}
        <div className="flex items-center justify-end gap-4">
          <button
            type="button"
            onClick={() => navigate('/dashboard/products')}
            className="px-6 py-3 text-gray-600 hover:text-gray-900 font-medium"
          >
            Cancel
          </button>
          <Button
            type="submit"
            className="bg-orange-500 hover:bg-orange-600 text-white px-8"
            disabled={isLoading}
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Check className="w-5 h-5 mr-2" />
                Add Product
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}
