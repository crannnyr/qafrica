import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  ShoppingCart, DollarSign, TrendingUp, Users, Eye,
  BarChart3, PieChart, Activity, Package, AlertTriangle,
  Target, MousePointer, ArrowUpRight, ArrowDownRight,
  Calendar, Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStoreStore } from '@/stores';
import { productEarningsService, analyticsService } from '@/services/supabase';
import { toast } from 'sonner';
import type { ProductEarningsSummary } from '@/types';

const timeRanges = [
  { value: '7d', label: 'Last 7 Days' },
  { value: '30d', label: 'Last 30 Days' },
  { value: '90d', label: 'Last 90 Days' },
  { value: 'all', label: 'All Time' },
];

interface EarningItem {
  total_revenue: number;
  total_cost: number;
  profit: number;
  net_profit: number;
}

interface VisitorStats {
  totalVisits: number;
  uniqueVisitors: number;
  avgSessionDuration: string;
  bounceRate: number;
}

interface ConversionStats {
  conversionRate: number;
  addToCartRate: number;
  checkoutRate: number;
  abandonedCarts: number;
}

export default function AnalyticsPage() {
  const { currentStore, products } = useStoreStore();
  const [timeRange, setTimeRange] = useState('30d');
  const [earnings, setEarnings] = useState<ProductEarningsSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [visitorStats, setVisitorStats] = useState<VisitorStats>({
    totalVisits: 0,
    uniqueVisitors: 0,
    avgSessionDuration: '0m 0s',
    bounceRate: 0,
  });
  const [conversionStats, setConversionStats] = useState<ConversionStats>({
    conversionRate: 0,
    addToCartRate: 0,
    checkoutRate: 0,
    abandonedCarts: 0,
  });
  const [stats, setStats] = useState({
    totalRevenue: 0,
    totalProfit: 0,
    totalOrders: 0,
    totalProducts: 0,
    lowStockCount: 0,
    outOfStockCount: 0,
  });
  const [trafficSources, setTrafficSources] = useState<Record<string, number>>({
    direct: 0,
    social: 0,
    search: 0,
    ads: 0,
  });
  const [popularProducts, setPopularProducts] = useState<ProductEarningsSummary[]>([]);

  useEffect(() => {
    if (currentStore?.id) {
      loadAnalytics();
    }
  }, [currentStore, timeRange]);

  const loadAnalytics = async () => {
    setIsLoading(true);
    try {
      // Calculate date range
      const endDate = new Date().toISOString();
      let startDate: string | undefined;
      
      if (timeRange !== 'all') {
        const days = parseInt(timeRange);
        startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
      }

      // Load earnings summary
      const { data: earningsData, error: earningsError } = await productEarningsService.getEarningsSummary(
        currentStore!.id,
        startDate,
        endDate
      );

      if (earningsError) {
        console.error('Failed to load earnings:', earningsError);
      } else {
        setEarnings(earningsData || []);
        setPopularProducts((earningsData || [])
          .sort((a: ProductEarningsSummary, b: ProductEarningsSummary) => b.total_quantity_sold - a.total_quantity_sold)
          .slice(0, 10));
      }

      // Load visitor analytics
      const { data: visitorData, error: visitorError } = await analyticsService.getVisitorStats(
        currentStore!.id,
        startDate,
        endDate
      );

      if (!visitorError && visitorData) {
        setVisitorStats({
          totalVisits: visitorData.totalVisits || 0,
          uniqueVisitors: visitorData.uniqueVisitors || 0,
          avgSessionDuration: visitorData.avgSessionDuration || '0m 0s',
          bounceRate: visitorData.bounceRate || 0,
        });
        setTrafficSources(visitorData.trafficSources || { direct: 0, social: 0, search: 0, ads: 0 });
      }

      // Load conversion analytics
      const { data: conversionData, error: conversionError } = await analyticsService.getConversionStats(
        currentStore!.id,
        startDate,
        endDate
      );

      if (!conversionError && conversionData) {
        setConversionStats({
          conversionRate: conversionData.conversionRate || 0,
          addToCartRate: conversionData.addToCartRate || 0,
          checkoutRate: conversionData.checkoutRate || 0,
          abandonedCarts: conversionData.abandonedCarts || 0,
        });
      }

      // Calculate stats
      const totalRevenue = (earningsData || []).reduce((sum: number, e: EarningItem) => sum + (e.total_revenue || 0), 0);
      const totalProfit = (earningsData || []).reduce((sum: number, e: EarningItem) => sum + (e.net_profit || 0), 0);
      const totalOrders = (earningsData || []).reduce((sum: number, e: ProductEarningsSummary) => sum + (e.total_quantity_sold || 0), 0);
      
      // Count low stock and out of stock products
      const lowStockCount = products?.filter(
        (p) => p.stock_quantity > 0 && p.stock_quantity <= (p.low_stock_threshold || 10)
      ).length || 0;
      
      const outOfStockCount = products?.filter(
        (p) => p.stock_quantity === 0
      ).length || 0;

      setStats({
        totalRevenue,
        totalProfit,
        totalOrders,
        totalProducts: earningsData?.length || 0,
        lowStockCount,
        outOfStockCount,
      });

    } catch (error) {
      console.error('Error loading analytics:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleExportReport = () => {
    const reportData = {
      timeRange,
      generatedAt: new Date().toISOString(),
      summary: {
        totalRevenue: stats.totalRevenue,
        totalProfit: stats.totalProfit,
        totalOrders: stats.totalOrders,
        totalProducts: stats.totalProducts,
      },
      visitorStats,
      conversionStats,
      trafficSources,
      productEarnings: earnings,
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-report-${timeRange}-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success('Report exported successfully');
  };

  const formatCurrency = (amount: number) => {
    return `₦${amount.toLocaleString()}`;
  };

  const formatPercentage = (value: number) => {
    return `${value.toFixed(1)}%`;
  };

  const mainStatCards = [
    { 
      label: 'Total Revenue', 
      value: formatCurrency(stats.totalRevenue), 
      icon: DollarSign, 
      color: 'bg-green-500',
      trend: '+12.5%',
      trendUp: true,
    },
    { 
      label: 'Net Profit', 
      value: formatCurrency(stats.totalProfit), 
      icon: TrendingUp, 
      color: 'bg-blue-500',
      trend: '+8.2%',
      trendUp: true,
    },
    { 
      label: 'Items Sold', 
      value: stats.totalOrders.toString(), 
      icon: ShoppingCart, 
      color: 'bg-purple-500',
      trend: '+15.3%',
      trendUp: true,
    },
    { 
      label: 'Active Products', 
      value: stats.totalProducts.toString(), 
      icon: Package, 
      color: 'bg-orange-500',
      trend: '+5.1%',
      trendUp: true,
    },
  ];

  const visitorStatCards = [
    {
      label: 'Total Visits',
      value: visitorStats.totalVisits.toLocaleString(),
      icon: Eye,
      color: 'bg-indigo-500',
    },
    {
      label: 'Unique Visitors',
      value: visitorStats.uniqueVisitors.toLocaleString(),
      icon: Users,
      color: 'bg-pink-500',
    },
    {
      label: 'Avg. Session',
      value: visitorStats.avgSessionDuration,
      icon: Calendar,
      color: 'bg-cyan-500',
    },
    {
      label: 'Bounce Rate',
      value: formatPercentage(visitorStats.bounceRate),
      icon: Target,
      color: 'bg-amber-500',
    },
  ];

  const conversionStatCards = [
    {
      label: 'Conversion Rate',
      value: formatPercentage(conversionStats.conversionRate),
      icon: Target,
      color: 'bg-emerald-500',
      description: 'Visitors who made a purchase',
    },
    {
      label: 'Add to Cart Rate',
      value: formatPercentage(conversionStats.addToCartRate),
      icon: ShoppingCart,
      color: 'bg-violet-500',
      description: 'Visitors who added items to cart',
    },
    {
      label: 'Checkout Rate',
      value: formatPercentage(conversionStats.checkoutRate),
      icon: MousePointer,
      color: 'bg-rose-500',
      description: 'Visitors who reached checkout',
    },
    {
      label: 'Abandoned Carts',
      value: conversionStats.abandonedCarts.toString(),
      icon: AlertTriangle,
      color: 'bg-red-500',
      description: 'Carts not converted to orders',
    },
  ];

  const totalTraffic = trafficSources.direct + trafficSources.social + trafficSources.search + trafficSources.ads;

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Analytics Dashboard</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Track your store performance, visitors, and conversions</p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex gap-2">
            {timeRanges.map((range) => (
              <button
                key={range.value}
                onClick={() => setTimeRange(range.value)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors text-sm ${
                  timeRange === range.value
                    ? 'bg-orange-500 text-white'
                    : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                {range.label}
              </button>
            ))}
          </div>
          <Button
            variant="outline"
            onClick={handleExportReport}
            className="flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Export
          </Button>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {mainStatCards.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-100 dark:border-gray-700"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                <div className={`flex items-center gap-1 text-sm mt-1 ${stat.trendUp ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.trendUp ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                  {stat.trend}
                </div>
              </div>
              <div className={`w-10 h-10 ${stat.color} rounded-lg flex items-center justify-center`}>
                <stat.icon className="w-5 h-5 text-white" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Visitor Stats */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <Eye className="w-5 h-5 text-orange-500" />
          Visitor Analytics
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {visitorStatCards.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className={`w-8 h-8 ${stat.color} rounded-lg flex items-center justify-center`}>
                  <stat.icon className="w-4 h-4 text-white" />
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
              </div>
              <p className="text-xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Conversion Stats */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
          <Target className="w-5 h-5 text-orange-500" />
          Conversion Funnel
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {conversionStatCards.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-xl p-5 border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className={`w-8 h-8 ${stat.color} rounded-lg flex items-center justify-center`}>
                  <stat.icon className="w-4 h-4 text-white" />
                </div>
              </div>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{stat.label}</p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">{stat.description}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Traffic Sources */}
      {totalTraffic > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-100 dark:border-gray-700"
        >
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-orange-500" />
            Traffic Sources
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Direct', value: trafficSources.direct, color: 'bg-blue-500' },
              { label: 'Social Media', value: trafficSources.social, color: 'bg-pink-500' },
              { label: 'Search Engines', value: trafficSources.search, color: 'bg-green-500' },
              { label: 'Ads', value: trafficSources.ads, color: 'bg-orange-500' },
            ].map((source) => (
              <div key={source.label} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600 dark:text-gray-400">{source.label}</span>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {((source.value / totalTraffic) * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${source.color} rounded-full transition-all duration-500`}
                    style={{ width: `${(source.value / totalTraffic) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-500">{source.value.toLocaleString()} visits</p>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Stock Alerts */}
      {(stats.lowStockCount > 0 || stats.outOfStockCount > 0) && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            <div>
              <p className="font-medium text-amber-900 dark:text-amber-200">Stock Alerts</p>
              <p className="text-sm text-amber-700 dark:text-amber-300">
                {stats.outOfStockCount > 0 && `${stats.outOfStockCount} product(s) out of stock. `}
                {stats.lowStockCount > 0 && `${stats.lowStockCount} product(s) running low on stock.`}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Popular Products */}
      <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Popular Products</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Your best-selling products by quantity sold</p>
            </div>
            <Activity className="w-5 h-5 text-gray-400" />
          </div>
        </div>

        {isLoading ? (
          <div className="p-12 text-center">
            <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-gray-500 mt-4">Loading analytics...</p>
          </div>
        ) : popularProducts.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">No data yet</h3>
            <p className="text-gray-500 dark:text-gray-400">Start selling products to see your popular items</p>
          </div>
        ) : (
          <div className="p-6">
            <div className="space-y-4">
              {popularProducts.map((product, index) => (
                <motion.div
                  key={product.product_id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl"
                >
                  <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg flex items-center justify-center text-white font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 dark:text-white truncate">{product.product_name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{product.total_quantity_sold} sales</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-green-600">{formatCurrency(product.total_revenue)}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{formatCurrency(product.total_net_profit)} net</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Product Earnings Table */}
      <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Product Earnings</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Revenue and profit breakdown by product</p>
            </div>
            <PieChart className="w-5 h-5 text-gray-400" />
          </div>
        </div>

        {isLoading ? (
          <div className="p-12 text-center">
            <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-gray-500 mt-4">Loading analytics...</p>
          </div>
        ) : earnings.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">No earnings yet</h3>
            <p className="text-gray-500 dark:text-gray-400">Start selling products to see your earnings here</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Product</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-500 dark:text-gray-400">Quantity Sold</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-500 dark:text-gray-400">Revenue</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-500 dark:text-gray-400">Cost</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-500 dark:text-gray-400">Profit</th>
                  <th className="px-6 py-4 text-right text-sm font-medium text-gray-500 dark:text-gray-400">Net Profit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {earnings.map((earning, index) => (
                  <motion.tr
                    key={earning.product_id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="hover:bg-gray-50 dark:hover:bg-gray-700/50"
                  >
                    <td className="px-6 py-4">
                      <p className="font-medium text-gray-900 dark:text-white">{earning.product_name}</p>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="font-medium text-gray-900 dark:text-white">{earning.total_quantity_sold}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="font-medium text-green-600">{formatCurrency(earning.total_revenue)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="text-gray-500 dark:text-gray-400">{formatCurrency(earning.total_cost)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="font-medium text-blue-600">{formatCurrency(earning.total_profit)}</span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <span className="font-medium text-orange-600">{formatCurrency(earning.total_net_profit)}</span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50 dark:bg-gray-700 font-medium">
                <tr>
                  <td className="px-6 py-4 text-gray-900 dark:text-white">Total</td>
                  <td className="px-6 py-4 text-right text-gray-900 dark:text-white">
                    {earnings.reduce((sum, e) => sum + e.total_quantity_sold, 0)}
                  </td>
                  <td className="px-6 py-4 text-right text-green-600">
                    {formatCurrency(earnings.reduce((sum, e) => sum + e.total_revenue, 0))}
                  </td>
                  <td className="px-6 py-4 text-right text-gray-500 dark:text-gray-400">
                    {formatCurrency(earnings.reduce((sum, e) => sum + e.total_cost, 0))}
                  </td>
                  <td className="px-6 py-4 text-right text-blue-600">
                    {formatCurrency(earnings.reduce((sum, e) => sum + e.total_profit, 0))}
                  </td>
                  <td className="px-6 py-4 text-right text-orange-600">
                    {formatCurrency(earnings.reduce((sum, e) => sum + e.total_net_profit, 0))}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
