import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Palette, Check, ArrowRight, Sparkles, Shirt, 
  Smartphone, Home, Utensils, Dumbbell, Laptop,
  Baby, Gem, Car, BookOpen, Music, Camera,
  Briefcase, Heart, X, Eye, Crown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStoreStore } from '@/stores';
import { toast } from 'sonner';
import { AVAILABLE_THEMES, getThemeById } from '@/lib/themes';

// Template/Niche definitions
const templates = [
  {
    id: 'fashion',
    name: 'Fashion & Apparel',
    description: 'Clothing, shoes, and accessories for men, women, and children',
    icon: Shirt,
    color: 'from-pink-500 to-rose-500',
    bgColor: 'bg-pink-50',
    themes: ['modern', 'elegant', 'minimal'],
    sampleProducts: ['Dresses', 'Shirts', 'Shoes', 'Bags'],
  },
  {
    id: 'electronics',
    name: 'Electronics & Gadgets',
    description: 'Phones, laptops, accessories, and tech gadgets',
    icon: Smartphone,
    color: 'from-blue-500 to-cyan-500',
    bgColor: 'bg-blue-50',
    themes: ['modern', 'tech'],
    sampleProducts: ['Phones', 'Headphones', 'Chargers', 'Cases'],
  },
  {
    id: 'home',
    name: 'Home & Living',
    description: 'Furniture, decor, kitchenware, and home essentials',
    icon: Home,
    color: 'from-amber-500 to-orange-500',
    bgColor: 'bg-amber-50',
    themes: ['elegant', 'warm'],
    sampleProducts: ['Furniture', 'Decor', 'Kitchen', 'Bedding'],
  },
  {
    id: 'food',
    name: 'Food & Groceries',
    description: 'Fresh food, packaged goods, and kitchen supplies',
    icon: Utensils,
    color: 'from-green-500 to-emerald-500',
    bgColor: 'bg-green-50',
    themes: ['fresh', 'warm'],
    sampleProducts: ['Fresh Produce', 'Snacks', 'Beverages', 'Spices'],
  },
  {
    id: 'beauty',
    name: 'Beauty & Personal Care',
    description: 'Skincare, makeup, haircare, and personal care products',
    icon: Sparkles,
    color: 'from-purple-500 to-violet-500',
    bgColor: 'bg-purple-50',
    themes: ['elegant', 'modern'],
    sampleProducts: ['Skincare', 'Makeup', 'Haircare', 'Fragrances'],
  },
  {
    id: 'fitness',
    name: 'Sports & Fitness',
    description: 'Gym equipment, sportswear, and fitness accessories',
    icon: Dumbbell,
    color: 'from-red-500 to-orange-500',
    bgColor: 'bg-red-50',
    themes: ['modern', 'bold'],
    sampleProducts: ['Equipment', 'Apparel', 'Supplements', 'Accessories'],
  },
  {
    id: 'computers',
    name: 'Computers & Accessories',
    description: 'Laptops, desktops, peripherals, and software',
    icon: Laptop,
    color: 'from-indigo-500 to-blue-500',
    bgColor: 'bg-indigo-50',
    themes: ['tech', 'modern'],
    sampleProducts: ['Laptops', 'Mice', 'Keyboards', 'Monitors'],
  },
  {
    id: 'baby',
    name: 'Baby & Kids',
    description: 'Baby care, toys, clothing, and nursery items',
    icon: Baby,
    color: 'from-teal-400 to-cyan-400',
    bgColor: 'bg-teal-50',
    themes: ['warm', 'soft'],
    sampleProducts: ['Clothing', 'Toys', 'Feeding', 'Diapers'],
  },
  {
    id: 'jewelry',
    name: 'Jewelry & Watches',
    description: 'Fine jewelry, fashion jewelry, and timepieces',
    icon: Gem,
    color: 'from-yellow-400 to-amber-500',
    bgColor: 'bg-yellow-50',
    themes: ['elegant', 'luxury'],
    sampleProducts: ['Rings', 'Necklaces', 'Watches', 'Earrings'],
  },
  {
    id: 'automotive',
    name: 'Automotive',
    description: 'Car parts, accessories, and maintenance products',
    icon: Car,
    color: 'from-slate-500 to-gray-600',
    bgColor: 'bg-slate-50',
    themes: ['bold', 'modern'],
    sampleProducts: ['Parts', 'Accessories', 'Tools', 'Care'],
  },
  {
    id: 'books',
    name: 'Books & Stationery',
    description: 'Books, notebooks, pens, and office supplies',
    icon: BookOpen,
    color: 'from-amber-600 to-yellow-600',
    bgColor: 'bg-amber-50',
    themes: ['warm', 'classic'],
    sampleProducts: ['Fiction', 'Textbooks', 'Stationery', 'Art Supplies'],
  },
  {
    id: 'music',
    name: 'Music & Instruments',
    description: 'Musical instruments, equipment, and accessories',
    icon: Music,
    color: 'from-violet-600 to-purple-600',
    bgColor: 'bg-violet-50',
    themes: ['bold', 'creative'],
    sampleProducts: ['Guitars', 'Keyboards', 'Drums', 'Accessories'],
  },
  {
    id: 'photography',
    name: 'Photography',
    description: 'Cameras, lenses, and photography equipment',
    icon: Camera,
    color: 'from-gray-700 to-slate-800',
    bgColor: 'bg-gray-50',
    themes: ['modern', 'minimal'],
    sampleProducts: ['Cameras', 'Lenses', 'Tripods', 'Lighting'],
  },
  {
    id: 'office',
    name: 'Office & Business',
    description: 'Office furniture, supplies, and business equipment',
    icon: Briefcase,
    color: 'from-blue-600 to-indigo-600',
    bgColor: 'bg-blue-50',
    themes: ['professional', 'modern'],
    sampleProducts: ['Furniture', 'Supplies', 'Equipment', 'Software'],
  },
  {
    id: 'health',
    name: 'Health & Wellness',
    description: 'Health products, supplements, and wellness items',
    icon: Heart,
    color: 'from-rose-400 to-pink-500',
    bgColor: 'bg-rose-50',
    themes: ['fresh', 'clean'],
    sampleProducts: ['Supplements', 'Devices', 'Personal Care', 'Organic'],
  },
];

// Theme Preview Component
function ThemePreview({ themeId, isSelected, onClick }: { themeId: string; isSelected: boolean; onClick: () => void }) {
  const theme = getThemeById(themeId);
  if (!theme) return null;

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`relative p-4 rounded-xl border-2 transition-all text-left ${
        isSelected
          ? 'border-orange-500 ring-2 ring-orange-200 bg-orange-50 dark:bg-orange-900/20'
          : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 bg-white dark:bg-gray-800'
      }`}
    >
      {/* Premium Badge */}
      {theme.is_premium && (
        <div className="absolute -top-2 -right-2 bg-gradient-to-r from-yellow-400 to-amber-500 text-white text-xs px-2 py-0.5 rounded-full flex items-center gap-1 shadow-md">
          <Crown className="w-3 h-3" />
          PRO
        </div>
      )}

      {/* Color Swatches */}
      <div className="flex gap-1 mb-3">
        <div 
          className="w-8 h-8 rounded-lg shadow-sm"
          style={{ backgroundColor: theme.colors.primary }}
          title="Primary"
        />
        <div 
          className="w-8 h-8 rounded-lg shadow-sm"
          style={{ backgroundColor: theme.colors.secondary }}
          title="Secondary"
        />
        <div 
          className="w-8 h-8 rounded-lg shadow-sm"
          style={{ backgroundColor: theme.colors.accent }}
          title="Accent"
        />
        <div 
          className="w-8 h-8 rounded-lg shadow-sm border border-gray-200 dark:border-gray-600"
          style={{ backgroundColor: theme.colors.background }}
          title="Background"
        />
      </div>

      {/* Theme Info */}
      <h4 className="font-semibold text-gray-900 dark:text-white text-sm mb-1">
        {theme.name}
      </h4>
      <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2">
        {theme.description}
      </p>

      {/* Fonts */}
      <div className="mt-2 text-xs text-gray-400 dark:text-gray-500">
        {theme.fonts.heading} · {theme.fonts.body}
      </div>

      {/* Selection Indicator */}
      {isSelected && (
        <div className="absolute top-2 right-2 w-5 h-5 bg-orange-500 rounded-full flex items-center justify-center">
          <Check className="w-3 h-3 text-white" />
        </div>
      )}
    </motion.button>
  );
}

export default function StoreTemplatesPage() {
  const { currentStore, updateStore } = useStoreStore();
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);
  const [viewingTemplate, setViewingTemplate] = useState<string | null>(null);
  const [isApplying, setIsApplying] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'popular' | 'new'>('all');

  const handleApplyTemplate = async () => {
    if (!selectedTemplate || !currentStore) return;

    const template = templates.find(t => t.id === selectedTemplate);
    if (!template) return;

    const themeToApply = selectedTheme || template.themes[0];
    const theme = getThemeById(themeToApply);

    setIsApplying(true);

    try {
      // Update store with template settings
      await updateStore(currentStore.id, {
        niches: [...currentStore.niches, template.id],
        theme: themeToApply,
        primary_color: theme?.colors.primary || template.color.split(' ')[0].replace('from-', ''),
      });

      toast.success(`${template.name} template with ${theme?.name || themeToApply} theme applied successfully!`);
      setSelectedTemplate(null);
      setSelectedTheme(null);
      setViewingTemplate(null);
    } catch (err) {
      toast.error('Failed to apply template');
    } finally {
      setIsApplying(false);
    }
  };

  const filteredTemplates = templates.filter(template => {
    if (activeTab === 'popular') {
      return ['fashion', 'electronics', 'beauty', 'home'].includes(template.id);
    }
    if (activeTab === 'new') {
      return ['health', 'photography', 'music'].includes(template.id);
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Store Templates</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">
            Choose a template to quickly set up your store with pre-designed themes and sample products
          </p>
        </div>
      </div>

      {/* Current Template Banner */}
      {currentStore?.niches && currentStore.niches.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl p-6 text-white"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
              <Palette className="w-6 h-6" />
            </div>
            <div>
              <p className="text-orange-100 text-sm">Your Current Niches</p>
              <p className="text-lg font-semibold">
                {currentStore.niches.map(n => 
                  templates.find(t => t.id === n)?.name || n
                ).join(', ')}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 border-b dark:border-gray-700">
        {[
          { key: 'all', label: 'All Templates' },
          { key: 'popular', label: 'Popular' },
          { key: 'new', label: 'New' },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`px-4 py-3 font-medium text-sm border-b-2 transition-colors ${
              activeTab === tab.key
                ? 'border-orange-500 text-orange-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template, index) => {
          const Icon = template.icon;
          const isSelected = selectedTemplate === template.id;
          const isApplied = currentStore?.niches?.includes(template.id);

          return (
            <motion.div
              key={template.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => setSelectedTemplate(template.id)}
              className={`relative group cursor-pointer rounded-xl border-2 p-6 transition-all ${
                isSelected
                  ? 'border-orange-500 ring-2 ring-orange-200'
                  : isApplied
                  ? 'border-green-500'
                  : 'border-gray-200 dark:border-gray-600 hover:border-orange-300'
              }`}
            >
              {/* Applied Badge */}
              {isApplied && (
                <div className="absolute top-4 right-4 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                  <Check className="w-5 h-5 text-white" />
                </div>
              )}

              {/* Icon */}
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${template.color} flex items-center justify-center mb-4`}>
                <Icon className="w-7 h-7 text-white" />
              </div>

              {/* Content */}
              <h3 className="font-semibold text-gray-900 dark:text-white text-lg mb-2">
                {template.name}
              </h3>
              <p className="text-gray-500 dark:text-gray-400 text-sm mb-4">
                {template.description}
              </p>

              {/* Sample Products */}
              <div className="flex flex-wrap gap-2 mb-4">
                {template.sampleProducts.map((product, i) => (
                  <span
                    key={i}
                    className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 text-xs rounded-full"
                  >
                    {product}
                  </span>
                ))}
              </div>

              {/* Themes */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setViewingTemplate(template.id);
                }}
                className="flex items-center gap-2 text-sm text-orange-600 hover:text-orange-700 font-medium mt-3 group"
              >
                <Palette className="w-4 h-4" />
                <span>{template.themes.length} themes available</span>
                <Eye className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>

              {/* Selection Indicator */}
              {isSelected && (
                <motion.div
                  layoutId="selectionIndicator"
                  className="absolute inset-0 border-2 border-orange-500 rounded-xl pointer-events-none"
                />
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Selected Template Actions */}
      {selectedTemplate && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 p-4 flex items-center gap-4 z-40"
        >
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Selected Template</p>
            <p className="font-semibold text-gray-900 dark:text-white">
              {templates.find(t => t.id === selectedTemplate)?.name}
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => setSelectedTemplate(null)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleApplyTemplate}
              disabled={isApplying}
              className="bg-orange-500 hover:bg-orange-600 text-white"
            >
              {isApplying ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Applying...
                </>
              ) : (
                <>
                  Apply Template
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          </div>
        </motion.div>
      )}

      {/* Info Section */}
      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-6">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-2 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-blue-500" />
          What happens when you apply a template?
        </h3>
        <ul className="space-y-2 text-gray-600 dark:text-gray-400 text-sm">
          <li className="flex items-start gap-2">
            <Check className="w-4 h-4 text-green-500 mt-0.5" />
            Your store theme will be updated to match the template style
          </li>
          <li className="flex items-start gap-2">
            <Check className="w-4 h-4 text-green-500 mt-0.5" />
            The niche will be added to your store categories
          </li>
          <li className="flex items-start gap-2">
            <Check className="w-4 h-4 text-green-500 mt-0.5" />
            You can customize everything after applying
          </li>
          <li className="flex items-start gap-2">
            <Check className="w-4 h-4 text-green-500 mt-0.5" />
            You can apply multiple templates to your store
          </li>
        </ul>
      </div>

      {/* Theme Preview Modal */}
      <AnimatePresence>
        {viewingTemplate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setViewingTemplate(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white dark:bg-gray-900 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
            >
              {(() => {
                const template = templates.find(t => t.id === viewingTemplate);
                if (!template) return null;
                const TemplateIcon = template.icon;

                return (
                  <>
                    {/* Modal Header */}
                    <div className="p-6 border-b dark:border-gray-700 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${template.color} flex items-center justify-center`}>
                          <TemplateIcon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                            {template.name} Themes
                          </h2>
                          <p className="text-gray-500 dark:text-gray-400 text-sm">
                            Choose a theme that matches your brand
                          </p>
                        </div>
                      </div>
                      <button
                        onClick={() => setViewingTemplate(null)}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                      >
                        <X className="w-5 h-5 text-gray-500" />
                      </button>
                    </div>

                    {/* Themes Grid */}
                    <div className="p-6 overflow-y-auto max-h-[60vh]">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {template.themes.map((themeId) => (
                          <ThemePreview
                            key={themeId}
                            themeId={themeId}
                            isSelected={selectedTheme === themeId}
                            onClick={() => {
                              setSelectedTheme(themeId);
                              setSelectedTemplate(template.id);
                            }}
                          />
                        ))}
                      </div>

                      {/* All Available Themes */}
                      <div className="mt-8 pt-6 border-t dark:border-gray-700">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                          <Palette className="w-5 h-5 text-orange-500" />
                          All Available Themes
                        </h3>
                        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
                          {AVAILABLE_THEMES.map((theme) => (
                            <div
                              key={theme.id}
                              className="flex items-center gap-2 p-2 rounded-lg bg-gray-50 dark:bg-gray-800"
                            >
                              <div
                                className="w-4 h-4 rounded-full"
                                style={{ backgroundColor: theme.colors.primary }}
                              />
                              <span className="text-xs text-gray-600 dark:text-gray-400 truncate">
                                {theme.name}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Modal Footer */}
                    <div className="p-6 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 flex items-center justify-between">
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {selectedTheme 
                          ? `Selected: ${getThemeById(selectedTheme)?.name}`
                          : 'Click a theme to select it'
                        }
                      </p>
                      <div className="flex gap-3">
                        <Button
                          variant="outline"
                          onClick={() => {
                            setViewingTemplate(null);
                            setSelectedTheme(null);
                          }}
                        >
                          Close
                        </Button>
                        <Button
                          onClick={handleApplyTemplate}
                          disabled={!selectedTheme || isApplying}
                          className="bg-orange-500 hover:bg-orange-600 text-white"
                        >
                          {isApplying ? (
                            <>
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                              Applying...
                            </>
                          ) : (
                            <>
                              Apply Theme
                              <ArrowRight className="w-4 h-4 ml-2" />
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </>
                );
              })()}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
