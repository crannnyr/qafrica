import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Crown, Check, ArrowRight, Calendar, CreditCard, 
  RefreshCw, AlertTriangle, ToggleLeft, ToggleRight,
  Loader2, Zap, Sparkles,
  TrendingUp, Clock,
  Infinity as InfinityIcon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuthStore } from '@/stores';
import { toast } from 'sonner';
import { 
  PRICING_TIERS, 
  DURATION_PLANS,
  calculateSubscriptionPrice,
  getLifetimePrice,
  formatPrice,
  canUpgradeTier,
  canDowngradeTier
} from '@/lib/pricing';
import { supabase } from '@/services/supabase';

interface SubscriptionData {
  id: string;
  tier: string;
  duration_months: number;
  expires_at: string;
  auto_renew: boolean;
  is_active: boolean;
}

interface BillingRecord {
  id: string;
  date: string;
  amount: number;
  status: 'paid' | 'pending' | 'failed';
  description: string;
}

export default function SubscriptionPage() {
  const { user } = useAuthStore();
  
  const [subscription, setSubscription] = useState<SubscriptionData | null>(null);
  const [billingHistory, setBillingHistory] = useState<BillingRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Upgrade/Downgrade modal
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [selectedTier, setSelectedTier] = useState<string>('');
  const [selectedDuration, setSelectedDuration] = useState<number>(3);
  const [isLifetime, setIsLifetime] = useState(false);
  
  // Auto-renewal
  const [autoRenewal, setAutoRenewal] = useState(false);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  // Load subscription data
  useEffect(() => {
    loadSubscriptionData();
  }, [user?.id]);

  const loadSubscriptionData = async () => {
    if (!user?.id) return;
    
    setIsLoading(true);
    try {
      // Fetch subscription
      const { data: subData, error: subError } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (subData && !subError) {
        setSubscription(subData);
        setAutoRenewal(subData.auto_renew);
      }

      // Fetch billing history
      const { data: billingData } = await supabase
        .from('subscriptions')
        .select('id, created_at, amount_paid, payment_status, tier')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (billingData) {
        setBillingHistory(billingData.map(b => ({
          id: b.id,
          date: b.created_at,
          amount: b.amount_paid,
          status: b.payment_status === 'paid' ? 'paid' : b.payment_status,
          description: `${b.tier} Plan Subscription`
        })));
      }
    } catch (err) {
      console.error('Error loading subscription:', err);
    }
    setIsLoading(false);
  };

  const handleTierSelect = (tierId: string) => {
    setSelectedTier(tierId);
    setShowUpgradeModal(true);
  };

  const handleSubscribe = async () => {
    if (!selectedTier) return;
    
    setIsProcessing(true);
    try {
      const tier = PRICING_TIERS.find(t => t.id === selectedTier);
      if (!tier) throw new Error('Invalid tier');

      let amount: number;
      let durationMonths: number;

      if (isLifetime) {
        amount = getLifetimePrice(selectedTier);
        durationMonths = 9999; // Lifetime marker
      } else {
        const pricing = calculateSubscriptionPrice(selectedTier, selectedDuration);
        amount = pricing.discountedPrice;
        durationMonths = selectedDuration;
      }

      // Initialize Paystack payment
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/paystack-init`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
        },
        body: JSON.stringify({
          email: user?.email,
          amount: amount * 100, // Paystack uses kobo
          metadata: {
            user_id: user?.id,
            tier: selectedTier,
            duration_months: durationMonths,
            is_lifetime: isLifetime,
            type: 'subscription'
          }
        })
      });

      const data = await response.json();

      if (data.authorization_url) {
        window.location.href = data.authorization_url;
      } else {
        throw new Error('Failed to initialize payment');
      }
    } catch (err) {
      console.error('Subscription error:', err);
      toast.error('Failed to process subscription');
      setIsProcessing(false);
    }
  };

  const handleToggleAutoRenewal = async () => {
    if (!subscription) return;
    
    setIsProcessing(true);
    try {
      const { error } = await supabase
        .from('subscriptions')
        .update({ auto_renew: !autoRenewal })
        .eq('id', subscription.id);

      if (error) throw error;

      setAutoRenewal(!autoRenewal);
      toast.success(autoRenewal ? 'Auto-renewal disabled' : 'Auto-renewal enabled');
    } catch (err) {
      toast.error('Failed to update auto-renewal');
    }
    setIsProcessing(false);
  };

  const handleCancelSubscription = async () => {
    if (!subscription) return;
    
    setIsProcessing(true);
    try {
      const { error } = await supabase
        .from('subscriptions')
        .update({ 
          auto_renew: false,
          cancel_at_period_end: true 
        })
        .eq('id', subscription.id);

      if (error) throw error;

      toast.success('Subscription will be cancelled at the end of the billing period');
      setShowCancelConfirm(false);
      loadSubscriptionData();
    } catch (err) {
      toast.error('Failed to cancel subscription');
    }
    setIsProcessing(false);
  };

  const getTierAction = (tierId: string) => {
    const currentTierId = subscription?.tier || 'single';
    
    if (tierId === currentTierId) {
      return { label: 'Current Plan', disabled: true, variant: 'default' as const };
    }
    
    if (canUpgradeTier(currentTierId, tierId)) {
      return { label: 'Upgrade', disabled: false, variant: 'default' as const };
    }
    
    if (canDowngradeTier(currentTierId, tierId)) {
      return { label: 'Downgrade', disabled: false, variant: 'outline' as const };
    }
    
    return { label: 'Select', disabled: false, variant: 'outline' as const };
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-NG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const currentTier = PRICING_TIERS.find(t => t.id === subscription?.tier) || PRICING_TIERS[0];
  const pricing = selectedTier ? calculateSubscriptionPrice(selectedTier, selectedDuration) : null;
  const lifetimePrice = selectedTier ? getLifetimePrice(selectedTier) : 0;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Subscription</h1>
        <p className="text-gray-500 dark:text-gray-400 mt-1">Manage your plan and billing</p>
      </div>

      {/* Current Plan Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-2xl p-6 text-white"
      >
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Crown className="w-5 h-5" />
              <span className="font-medium">Current Plan</span>
            </div>
            <h2 className="text-3xl font-bold mb-1">{currentTier.name}</h2>
            <p className="text-orange-100">
              {subscription?.expires_at && new Date(subscription.expires_at) > new Date()
                ? `Expires on ${formatDate(subscription.expires_at)}`
                : 'No active subscription'}
            </p>
            {subscription?.duration_months === 9999 && (
              <span className="inline-flex items-center gap-1 mt-2 px-3 py-1 bg-white/20 rounded-full text-sm">
                <InfinityIcon className="w-4 h-4" />
                Lifetime Access
              </span>
            )}
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold">{formatPrice(currentTier.basePrice)}</p>
            <p className="text-orange-100">/month</p>
            <p className="text-sm mt-2 text-orange-100">
              {currentTier.nichesAllowed === Infinity 
                ? 'Unlimited niches' 
                : `${currentTier.nichesAllowed} niche${currentTier.nichesAllowed > 1 ? 's' : ''}`}
            </p>
          </div>
        </div>
      </motion.div>

      {/* Auto-Renewal Section */}
      {subscription && subscription.duration_months !== 9999 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 p-6"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                <RefreshCw className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Auto-Renewal</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {autoRenewal 
                    ? 'Your subscription renews automatically'
                    : 'Enable to avoid service interruption'}
                </p>
              </div>
            </div>
            <button
              onClick={handleToggleAutoRenewal}
              disabled={isProcessing}
              className="relative disabled:opacity-50"
            >
              {autoRenewal ? (
                <ToggleRight className="w-14 h-8 text-green-500" />
              ) : (
                <ToggleLeft className="w-14 h-8 text-gray-400" />
              )}
            </button>
          </div>
        </motion.div>
      )}

      {/* Plan Selection */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Available Plans</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {PRICING_TIERS.map((tier, index) => {
            const action = getTierAction(tier.id);
            const isCurrent = tier.id === subscription?.tier;
            
            return (
              <motion.div
                key={tier.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
                className={`rounded-xl border-2 p-6 relative ${
                  isCurrent
                    ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/10'
                    : 'border-gray-200 dark:border-gray-600 hover:border-orange-300'
                }`}
              >
                {tier.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-orange-500 text-white text-xs font-medium rounded-full">
                    Most Popular
                  </div>
                )}
                
                <div className="flex items-center gap-2 mb-3">
                  {tier.id === 'single' && <Zap className="w-5 h-5 text-orange-500" />}
                  {tier.id === 'three' && <TrendingUp className="w-5 h-5 text-blue-500" />}
                  {tier.id === 'unlimited' && <Crown className="w-5 h-5 text-purple-500" />}
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{tier.name}</h3>
                </div>
                
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">{tier.description}</p>
                
                <div className="mb-6">
                  <span className="text-3xl font-bold text-gray-900 dark:text-white">{formatPrice(tier.basePrice)}</span>
                  <span className="text-gray-500 dark:text-gray-400">/month</span>
                </div>

                <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {tier.nichesAllowed === Infinity 
                      ? '✓ Unlimited niches' 
                      : `✓ ${tier.nichesAllowed} niche${tier.nichesAllowed > 1 ? 's' : ''}`}
                  </p>
                </div>
                
                <ul className="space-y-2 mb-6">
                  {tier.features.slice(0, 5).map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                      <span className="truncate">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button 
                  onClick={() => handleTierSelect(tier.id)}
                  disabled={action.disabled || isProcessing}
                  variant={action.variant}
                  className={`w-full ${action.variant === 'default' ? 'bg-orange-500 hover:bg-orange-600 text-white' : ''}`}
                >
                  {action.label}
                  {!action.disabled && <ArrowRight className="w-4 h-4 ml-2" />}
                </Button>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Billing History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-white dark:bg-gray-800 rounded-xl border border-gray-100 dark:border-gray-700 p-6"
      >
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">Billing History</h2>
        {billingHistory.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No billing history yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {billingHistory.map((bill) => (
              <div key={bill.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white dark:bg-gray-600 rounded-lg flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-gray-400" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{bill.description}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{formatDate(bill.date)}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900 dark:text-white">{formatPrice(bill.amount)}</p>
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                    bill.status === 'paid' 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                      : bill.status === 'pending'
                      ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300'
                      : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                  }`}>
                    {bill.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </motion.div>

      {/* Cancel Subscription */}
      {subscription && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-red-50 dark:bg-red-900/10 rounded-xl border border-red-100 dark:border-red-800 p-6"
        >
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h3 className="font-semibold text-red-900 dark:text-red-300">Cancel Subscription</h3>
              <p className="text-sm text-red-600 dark:text-red-400 mt-1">
                Your store will remain active until the end of your billing period
              </p>
            </div>
            <Button
              variant="outline"
              onClick={() => setShowCancelConfirm(true)}
              className="border-red-300 text-red-600 hover:bg-red-100 dark:border-red-700 dark:hover:bg-red-900/30"
            >
              Cancel Subscription
            </Button>
          </div>
        </motion.div>
      )}

      {/* Upgrade/Downgrade Modal */}
      <AnimatePresence>
        {showUpgradeModal && selectedTier && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-gray-800 rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                    {subscription?.tier === selectedTier ? 'Extend Subscription' : 'Change Plan'}
                  </h3>
                  <button 
                    onClick={() => setShowUpgradeModal(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ×
                  </button>
                </div>

                {/* Selected Tier Info */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4 mb-6">
                  <p className="text-sm text-gray-500 dark:text-gray-400">Selected Plan</p>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">
                    {PRICING_TIERS.find(t => t.id === selectedTier)?.name}
                  </p>
                  <p className="text-orange-600 font-medium">
                    {formatPrice(PRICING_TIERS.find(t => t.id === selectedTier)?.basePrice || 0)}/month
                  </p>
                </div>

                {/* Duration Selection */}
                {!isLifetime && (
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                      Select Duration
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {DURATION_PLANS.map((plan) => (
                        <button
                          key={plan.months}
                          onClick={() => setSelectedDuration(plan.months)}
                          className={`p-3 rounded-lg border-2 text-left transition-colors ${
                            selectedDuration === plan.months
                              ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/20'
                              : 'border-gray-200 dark:border-gray-600 hover:border-orange-300'
                          }`}
                        >
                          <p className="font-medium text-gray-900 dark:text-white">{plan.label}</p>
                          {plan.discount > 0 && (
                            <p className="text-sm text-green-600">Save {plan.discount}%</p>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Lifetime Option */}
                <div className="mb-6">
                  <button
                    onClick={() => setIsLifetime(!isLifetime)}
                    className={`w-full p-4 rounded-lg border-2 text-left transition-colors ${
                      isLifetime
                        ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/20'
                        : 'border-gray-200 dark:border-gray-600 hover:border-orange-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900 dark:text-white flex items-center gap-2">
                          <Sparkles className="w-5 h-5 text-orange-500" />
                          Lifetime Access
                        </p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Pay once, use forever
                        </p>
                      </div>
                      <p className="text-xl font-bold text-orange-600">
                        {formatPrice(lifetimePrice)}
                      </p>
                    </div>
                  </button>
                </div>

                {/* Price Summary */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4 mb-6">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600 dark:text-gray-400">Original Price</span>
                    <span className="text-gray-900 dark:text-white">
                      {isLifetime ? formatPrice(lifetimePrice) : formatPrice(pricing?.originalPrice || 0)}
                    </span>
                  </div>
                  {!isLifetime && pricing && pricing.savings > 0 && (
                    <div className="flex justify-between mb-2">
                      <span className="text-green-600">Discount</span>
                      <span className="text-green-600">-{formatPrice(pricing.savings)}</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-2 border-t border-gray-200 dark:border-gray-600">
                    <span className="font-medium text-gray-900 dark:text-white">Total</span>
                    <span className="font-bold text-xl text-orange-600">
                      {isLifetime ? formatPrice(lifetimePrice) : formatPrice(pricing?.discountedPrice || 0)}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setShowUpgradeModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleSubscribe}
                    disabled={isProcessing}
                    className="flex-1 bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <CreditCard className="w-4 h-4 mr-2" />
                        Pay Now
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cancel Confirmation Modal */}
      <AnimatePresence>
        {showCancelConfirm && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-gray-800 rounded-2xl max-w-md w-full p-6"
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertTriangle className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  Cancel Subscription?
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Your store will remain active until{' '}
                  <strong>{subscription?.expires_at ? formatDate(subscription.expires_at) : 'the end of your billing period'}</strong>. 
                  After that, your store will be suspended.
                </p>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowCancelConfirm(false)}
                  className="flex-1"
                >
                  Keep Subscription
                </Button>
                <Button
                  onClick={handleCancelSubscription}
                  disabled={isProcessing}
                  className="flex-1 bg-red-500 hover:bg-red-600 text-white"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Cancelling...
                    </>
                  ) : (
                    'Yes, Cancel'
                  )}
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
