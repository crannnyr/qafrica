import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Package, Search, Plus, Store } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStoreStore, useImportStore } from '@/stores';
import { toast } from 'sonner';

export default function ImportCatalogPage() {
  const { currentStore } = useStoreStore();
  const { imports, availableProducts, fetchStoreImports, fetchAvailableProducts, importProduct } = useImportStore();
  const [activeTab, setActiveTab] = useState<'browse' | 'imported'>('browse');
  const [searchQuery, setSearchQuery] = useState('');
  const [isImporting, setIsImporting] = useState<string | null>(null);

  useEffect(() => {
    if (currentStore?.id) {
      fetchStoreImports(currentStore.id);
      if (currentStore.niches?.[0]) {
        fetchAvailableProducts(currentStore.niches[0], currentStore.id);
      }
    }
  }, [currentStore, fetchStoreImports, fetchAvailableProducts]);

  const handleImport = async (product: any) => {
    if (!currentStore?.id || !currentStore?.owner_id) return;

    setIsImporting(product.id);

    const result = await importProduct({
      original_product_id: product.id,
      original_store_id: product.store_id,
      original_owner_id: product.owner_id,
      importer_store_id: currentStore.id,
      importer_owner_id: currentStore.owner_id,
      name: product.name,
      description: product.description,
      images: product.images,
      category: product.category,
      niche: product.niche,
      selling_price: product.selling_price,
      dropship_price: product.dropship_price,
      is_active: true,
      total_sales: 0,
    });

    if (result.success) {
      toast.success('Product imported successfully!');
    } else {
      toast.error(result.error || 'Failed to import product');
    }

    setIsImporting(null);
  };

  const filteredProducts = availableProducts.filter((product) =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Import Catalog</h1>
          <p className="text-gray-500 mt-1">Browse and import products from other sellers</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 border-b">
        <button
          onClick={() => setActiveTab('browse')}
          className={`px-4 py-3 font-medium border-b-2 transition-colors ${
            activeTab === 'browse'
              ? 'border-orange-500 text-orange-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          Browse Products
        </button>
        <button
          onClick={() => setActiveTab('imported')}
          className={`px-4 py-3 font-medium border-b-2 transition-colors ${
            activeTab === 'imported'
              ? 'border-orange-500 text-orange-600'
              : 'border-transparent text-gray-500 hover:text-gray-700'
          }`}
        >
          My Imports ({imports.length})
        </button>
      </div>

      {activeTab === 'browse' ? (
        <>
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products to import..."
              className="w-full pl-12 pr-4 py-3 rounded-lg border border-gray-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none"
            />
          </div>

          {/* Products Grid */}
          {filteredProducts.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-100 p-12 text-center">
              <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-10 h-10 text-orange-500" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No products available</h3>
              <p className="text-gray-500">Check back later for new products in your niche</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-xl border border-gray-100 overflow-hidden"
                >
                  <div className="aspect-square bg-gray-100 relative">
                    {product.images && product.images.length > 0 ? (
                      <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Package className="w-16 h-16 text-gray-300" />
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-900 mb-1">{product.name}</h3>
                    <p className="text-sm text-gray-500 mb-3 line-clamp-2">{product.description}</p>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-lg font-bold text-orange-600">₦{product.selling_price.toLocaleString()}</p>
                        <p className="text-xs text-gray-500">Dropship: ₦{product.dropship_price.toLocaleString()}</p>
                      </div>
                      <Button
                        onClick={() => handleImport(product)}
                        disabled={isImporting === product.id}
                        className="bg-orange-500 hover:bg-orange-600 text-white"
                        size="sm"
                      >
                        {isImporting === product.id ? (
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <>
                            <Plus className="w-4 h-4 mr-1" />
                            Import
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </>
      ) : (
        /* Imported Products */
        <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
          {imports.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No imported products</h3>
              <p className="text-gray-500">Browse the catalog to import products</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Original Store</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Your Price</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sales</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {imports.map((item) => (
                    <tr key={item.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                            <Package className="w-5 h-5 text-gray-400" />
                          </div>
                          <span className="font-medium text-gray-900">{item.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">
                        <div className="flex items-center gap-2">
                          <Store className="w-4 h-4" />
                          Store #{item.original_store_id?.slice(0, 8)}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">
                        ₦{(item.custom_selling_price || item.selling_price).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{item.total_sales}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          item.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                          {item.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
