import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ShoppingCart, Package, ArrowUpRight, 
  ArrowDownRight, DollarSign, Eye, Plus, Store
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuthStore, useStoreStore } from '@/stores';

const statsCards = [
  { 
    label: 'Total Revenue', 
    value: '₦245,000', 
    change: '+12.5%', 
    trend: 'up',
    icon: DollarSign,
    color: 'green'
  },
  { 
    label: 'Total Orders', 
    value: '156', 
    change: '+8.2%', 
    trend: 'up',
    icon: ShoppingCart,
    color: 'blue'
  },
  { 
    label: 'Products', 
    value: '42', 
    change: '+3', 
    trend: 'up',
    icon: Package,
    color: 'orange'
  },
  { 
    label: 'Store Views', 
    value: '2,847', 
    change: '-2.1%', 
    trend: 'down',
    icon: Eye,
    color: 'purple'
  },
];

const recentOrders = [
  { id: 'ORD-001', customer: 'John Doe', product: 'Nike Air Max', amount: 45000, status: 'completed', date: '2024-01-15' },
  { id: 'ORD-002', customer: 'Jane Smith', product: 'Adidas Ultra Boost', amount: 52000, status: 'processing', date: '2024-01-14' },
  { id: 'ORD-003', customer: 'Mike Johnson', product: 'Puma RS-X', amount: 38000, status: 'pending', date: '2024-01-14' },
  { id: 'ORD-004', customer: 'Sarah Williams', product: 'New Balance 574', amount: 42000, status: 'completed', date: '2024-01-13' },
  { id: 'ORD-005', customer: 'David Brown', product: 'Vans Old Skool', amount: 28000, status: 'shipped', date: '2024-01-13' },
];

const topProducts = [
  { name: 'Nike Air Max 90', sales: 45, revenue: 2025000, image: null },
  { name: 'Adidas Ultraboost', sales: 38, revenue: 1976000, image: null },
  { name: 'Puma RS-X Bold', sales: 32, revenue: 1216000, image: null },
  { name: 'New Balance 574', sales: 28, revenue: 1176000, image: null },
];

const quickActions = [
  { label: 'Add Product', icon: Plus, path: '/dashboard/products/add', color: 'bg-orange-500' },
  { label: 'View Orders', icon: ShoppingCart, path: '/dashboard/orders', color: 'bg-blue-500' },
  { label: 'Import Products', icon: Package, path: '/dashboard/import-catalog', color: 'bg-green-500' },
  { label: 'Store Settings', icon: Store, path: '/dashboard/settings', color: 'bg-purple-500' },
];

export default function DashboardHome() {
  const { user } = useAuthStore();
  const { currentStore } = useStoreStore();

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Welcome back, {user?.full_name?.split(' ')[0]}!
          </h1>
          <p className="text-gray-500 mt-1">
            Here's what's happening with your store today.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/dashboard/products/add">
            <Button className="bg-orange-500 hover:bg-orange-600 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Add Product
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statsCards.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-gray-500 mb-1">{stat.label}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <div className={`flex items-center gap-1 mt-2 ${
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.trend === 'up' ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                  <span className="text-sm font-medium">{stat.change}</span>
                  <span className="text-sm text-gray-400">vs last month</span>
                </div>
              </div>
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                stat.color === 'green' ? 'bg-green-100' :
                stat.color === 'blue' ? 'bg-blue-100' :
                stat.color === 'orange' ? 'bg-orange-100' :
                'bg-purple-100'
              }`}>
                <stat.icon className={`w-6 h-6 ${
                  stat.color === 'green' ? 'text-green-600' :
                  stat.color === 'blue' ? 'text-blue-600' :
                  stat.color === 'orange' ? 'text-orange-600' :
                  'text-purple-600'
                }`} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <motion.div
              key={action.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
            >
              <Link
                to={action.path}
                className="flex items-center gap-4 p-4 bg-white rounded-xl border border-gray-100 hover:border-orange-300 hover:shadow-md transition-all"
              >
                <div className={`w-12 h-12 ${action.color} rounded-xl flex items-center justify-center`}>
                  <action.icon className="w-6 h-6 text-white" />
                </div>
                <span className="font-medium text-gray-900">{action.label}</span>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Recent Orders */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-lg font-semibold text-gray-900">Recent Orders</h2>
              <Link to="/dashboard/orders" className="text-sm text-orange-500 hover:text-orange-600 font-medium">
                View All
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {recentOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{order.id}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{order.customer}</td>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">₦{order.amount.toLocaleString()}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          order.status === 'completed' ? 'bg-green-100 text-green-800' :
                          order.status === 'processing' ? 'bg-blue-100 text-blue-800' :
                          order.status === 'shipped' ? 'bg-purple-100 text-purple-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Top Products */}
        <div>
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-lg font-semibold text-gray-900">Top Products</h2>
              <Link to="/dashboard/products" className="text-sm text-orange-500 hover:text-orange-600 font-medium">
                View All
              </Link>
            </div>
            <div className="p-6 space-y-4">
              {topProducts.map((product, index) => (
                <div key={product.name} className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center text-gray-500 font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{product.name}</p>
                    <p className="text-sm text-gray-500">{product.sales} sales</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">₦{product.revenue.toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Store Setup Checklist */}
      {!currentStore && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl p-6 text-white"
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold mb-2">Complete Your Store Setup</h2>
              <p className="text-orange-100">
                You're just a few steps away from launching your store!
              </p>
            </div>
            <Link to="/dashboard/store-setup">
              <Button className="bg-white text-orange-600 hover:bg-orange-50">
                Set Up Store
                <ArrowUpRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </motion.div>
      )}
    </div>
  );
}
