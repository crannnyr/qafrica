import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Globe, Check, Loader2, AlertCircle, ArrowRight, 
  ExternalLink, Shield, Sparkles, Info
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStoreStore } from '@/stores';
import { toast } from 'sonner';

// Domain pricing
const DOMAIN_PRICING = {
  new: 12900,      // Buy new .store domain
  connect: 7000,   // Connect existing domain
};

export default function DomainPage() {
  const { currentStore, updateStore } = useStoreStore();
  const [domainType, setDomainType] = useState<'new' | 'existing'>('new');
  const [domainName, setDomainName] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [checkResult, setCheckResult] = useState<{
    available?: boolean;
    message?: string;
  } | null>(null);

  // Load current domain if exists
  useEffect(() => {
    if (currentStore?.custom_domain) {
      setDomainName(currentStore.custom_domain);
      setDomainType('existing');
    }
  }, [currentStore]);

  const handleCheckDomain = async () => {
    if (!domainName) {
      toast.error('Please enter a domain name');
      return;
    }

    // Format domain name
    let formattedDomain = domainName.toLowerCase().trim();
    if (domainType === 'new' && !formattedDomain.includes('.')) {
      formattedDomain = `${formattedDomain}.store`;
    }

    setIsChecking(true);
    setCheckResult(null);

    // Simulate domain availability check (in production, this would call an API)
    setTimeout(() => {
      // Mock check - in production, integrate with domain registrar API
      const isAvailable = Math.random() > 0.3; // Mock 70% availability
      
      setCheckResult({
        available: isAvailable,
        message: isAvailable 
          ? `${formattedDomain} is available!` 
          : `${formattedDomain} is already taken. Try another.`,
      });
      setIsChecking(false);
    }, 1500);
  };

  const handleSubmitRequest = async () => {
    if (!currentStore?.id || !checkResult?.available) return;

    setIsSubmitting(true);

    // Format domain
    let formattedDomain = domainName.toLowerCase().trim();
    if (domainType === 'new' && !formattedDomain.includes('.')) {
      formattedDomain = `${formattedDomain}.store`;
    }

    // Update store with domain request
    const result = await updateStore(currentStore.id, {
      custom_domain: formattedDomain,
      domain_status: 'pending',
    });

    if (result.success) {
      toast.success('Domain request submitted! Our team will process it shortly.');
      // In production, this would redirect to payment for domain
    } else {
      toast.error(result.error || 'Failed to submit domain request');
    }

    setIsSubmitting(false);
  };

  const getDomainStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      none: 'bg-gray-100 text-gray-600',
      pending: 'bg-yellow-100 text-yellow-700',
      processing: 'bg-blue-100 text-blue-700',
      connected: 'bg-green-100 text-green-700',
      failed: 'bg-red-100 text-red-700',
    };
    return styles[status] || styles.none;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Custom Domain</h1>
        <p className="text-gray-500 mt-1">Connect your own domain to your store</p>
      </div>

      {/* Current Domain Status */}
      {currentStore?.custom_domain && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl border border-gray-100 p-6"
        >
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Current Domain</h2>
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <Globe className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">{currentStore.custom_domain}</p>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  getDomainStatusBadge(currentStore.domain_status || 'none')
                }`}>
                  {(currentStore.domain_status || 'none').toUpperCase()}
                </span>
              </div>
            </div>
            {currentStore.domain_status === 'connected' && (
              <a 
                href={`https://${currentStore.custom_domain}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
              >
                Visit Store
                <ExternalLink className="w-4 h-4" />
              </a>
            )}
          </div>
        </motion.div>
      )}

      {/* Domain Options */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Buy New Domain */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          onClick={() => {
            setDomainType('new');
            setCheckResult(null);
          }}
          className={`p-6 rounded-xl border-2 cursor-pointer transition-all ${
            domainType === 'new'
              ? 'border-orange-500 bg-orange-50'
              : 'border-gray-200 hover:border-orange-300 bg-white'
          }`}
        >
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-orange-500" />
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">₦{DOMAIN_PRICING.new.toLocaleString()}</p>
              <p className="text-sm text-gray-500">one-time fee</p>
            </div>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Buy New .store Domain</h3>
          <p className="text-gray-600 text-sm mb-4">
            Get a brand new .store domain name for your business. We'll purchase and configure it for you.
          </p>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Professional .store extension
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Free SSL certificate included
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Full DNS management
            </li>
          </ul>
        </motion.div>

        {/* Connect Existing Domain */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          onClick={() => {
            setDomainType('existing');
            setCheckResult(null);
          }}
          className={`p-6 rounded-xl border-2 cursor-pointer transition-all ${
            domainType === 'existing'
              ? 'border-orange-500 bg-orange-50'
              : 'border-gray-200 hover:border-orange-300 bg-white'
          }`}
        >
          <div className="flex items-start justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-blue-500" />
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">₦{DOMAIN_PRICING.connect.toLocaleString()}</p>
              <p className="text-sm text-gray-500">one-time fee</p>
            </div>
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Connect Existing Domain</h3>
          <p className="text-gray-600 text-sm mb-4">
            Already own a domain? We'll help you connect it to your QAFRICA store.
          </p>
          <ul className="space-y-2 text-sm text-gray-600">
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Works with any domain extension
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Free SSL certificate included
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Expert setup assistance
            </li>
          </ul>
        </motion.div>
      </div>

      {/* Domain Search/Input */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-xl border border-gray-100 p-6"
      >
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          {domainType === 'new' ? 'Search for Your Domain' : 'Enter Your Domain'}
        </h2>

        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <input
              type="text"
              value={domainName}
              onChange={(e) => {
                setDomainName(e.target.value);
                setCheckResult(null);
              }}
              placeholder={domainType === 'new' ? 'yourstore' : 'yourstore.com'}
              className="w-full px-4 py-4 rounded-lg border border-gray-200 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none text-lg"
            />
            {domainType === 'new' && (
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 font-medium">
                .store
              </span>
            )}
          </div>
          <Button
            onClick={handleCheckDomain}
            disabled={isChecking || !domainName}
            className="bg-orange-500 hover:bg-orange-600 text-white px-8 h-14"
          >
            {isChecking ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                {domainType === 'new' ? 'Check Availability' : 'Verify Domain'}
                <ArrowRight className="w-5 h-5 ml-2" />
              </>
            )}
          </Button>
        </div>

        {/* Check Result */}
        {checkResult && (
          <div className={`mt-4 p-4 rounded-lg ${
            checkResult.available ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
          }`}>
            <div className="flex items-center gap-3">
              {checkResult.available ? (
                <Check className="w-5 h-5 text-green-500" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-500" />
              )}
              <p className={checkResult.available ? 'text-green-700' : 'text-red-700'}>
                {checkResult.message}
              </p>
            </div>
          </div>
        )}

        {/* Submit Button */}
        {checkResult?.available && (
          <div className="mt-6 pt-6 border-t">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="text-gray-500 mb-1">Total Cost</p>
                <p className="text-3xl font-bold text-gray-900">
                  ₦{(domainType === 'new' ? DOMAIN_PRICING.new : DOMAIN_PRICING.connect).toLocaleString()}
                </p>
              </div>
              <Button
                onClick={handleSubmitRequest}
                disabled={isSubmitting}
                className="bg-green-500 hover:bg-green-600 text-white px-8 h-14"
              >
                {isSubmitting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    Proceed to Payment
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </motion.div>

      {/* Info Box */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="font-medium text-blue-900 mb-1">How it works</h4>
            <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
              <li>Choose your domain option and search/enter your domain</li>
              <li>Complete the payment for domain registration/setup</li>
              <li>Our team will configure the DNS and SSL certificate</li>
              <li>Your custom domain will be live within 24-48 hours</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
}
