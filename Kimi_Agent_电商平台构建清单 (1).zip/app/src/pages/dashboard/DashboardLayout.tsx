import { useState, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, Package, ShoppingCart, Wallet, MapPin, 
  BarChart3, Settings, Store, LogOut, Menu, X,
  Import, Bell, User, Crown, Globe, ChevronLeft, AlertTriangle,
  Calculator, BookOpen, MessageSquare, Tag, Upload, Palette
} from 'lucide-react';
import LanguageSelector from '@/components/LanguageSelector';
import { Button } from '@/components/ui/button';
import { useAuthStore, useStoreStore } from '@/stores';
import { stockAlertService } from '@/services/supabase';
import { subscribeToOrders, subscribeToStockAlerts, subscribeToWalletUpdates } from '@/services/realtime';
import { toast } from 'sonner';
import type { StockAlert } from '@/types';

const sidebarItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard' },
  { icon: Package, label: 'Products', path: '/dashboard/products' },
  { icon: Upload, label: 'Bulk Import', path: '/dashboard/products/bulk-import' },
  { icon: Import, label: 'Import Catalog', path: '/dashboard/import-catalog' },
  { icon: ShoppingCart, label: 'Orders', path: '/dashboard/orders' },
  { icon: MessageSquare, label: 'Reviews', path: '/dashboard/reviews' },
  { icon: Tag, label: 'Coupons', path: '/dashboard/coupons' },
  { icon: Wallet, label: 'Wallet', path: '/dashboard/wallet' },
  { icon: MapPin, label: 'Delivery Zones', path: '/dashboard/delivery-zones' },
  { icon: Globe, label: 'Custom Domain', path: '/dashboard/domain' },
  { icon: BarChart3, label: 'Analytics', path: '/dashboard/analytics' },
  { icon: Calculator, label: 'Tax & Expenses', path: '/dashboard/tax-expenses' },
  { icon: Palette, label: 'Templates', path: '/dashboard/templates' },
  { icon: Settings, label: 'Settings', path: '/dashboard/settings' },
  { icon: BookOpen, label: 'How to Use', path: '/dashboard/how-to-use' },
];

export default function DashboardLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuthStore();
  const { currentStore, fetchUserStore } = useStoreStore();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [stockAlerts, setStockAlerts] = useState<StockAlert[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (user?.id) {
      fetchUserStore(user.id);
      loadStockAlerts();
    }
  }, [user, fetchUserStore]);

  // Real-time subscriptions
  useEffect(() => {
    if (!user?.id) return;

    const subscriptions: any[] = [];

    // Subscribe to new orders
    if (currentStore?.id) {
      const orderSub = subscribeToOrders(currentStore.id, (order) => {
        toast.success(`New order received! #${order.id.slice(0, 8)}`, {
          action: {
            label: 'View',
            onClick: () => navigate('/dashboard/orders'),
          },
        });
      });
      subscriptions.push(orderSub);
    }

    // Subscribe to stock alerts
    const stockSub = subscribeToStockAlerts(user.id, () => {
      loadStockAlerts();
    });
    subscriptions.push(stockSub);

    // Subscribe to wallet updates
    const walletSub = subscribeToWalletUpdates(user.id, (transaction) => {
      if (transaction.type === 'credit') {
        toast.success(`₦${transaction.amount.toLocaleString()} credited to your wallet!`);
      }
    });
    subscriptions.push(walletSub);

    return () => {
      subscriptions.forEach(sub => sub.unsubscribe());
    };
  }, [user?.id, currentStore?.id, navigate]);

  const loadStockAlerts = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await stockAlertService.getUnreadAlerts(user.id);
      if (!error && data) {
        setStockAlerts(data as StockAlert[]);
      }
    } catch (err) {
      console.error('Failed to load stock alerts:', err);
    }
  };

  const handleMarkAlertRead = async (alertId: string) => {
    const { error } = await stockAlertService.markAsRead(alertId);
    if (!error) {
      setStockAlerts(prev => prev.filter(a => a.id !== alertId));
    }
  };

  const handleMarkAllRead = async () => {
    if (!user?.id) return;
    const { error } = await stockAlertService.markAllAsRead(user.id);
    if (!error) {
      setStockAlerts([]);
      toast.success('All notifications marked as read');
    }
  };

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out successfully');
    navigate('/login');
  };

  const isActive = (path: string) => {
    if (path === '/dashboard') {
      return location.pathname === '/dashboard';
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar - Desktop & Mobile */}
      <motion.aside
        initial={false}
        animate={{ 
          width: isSidebarOpen ? 280 : 0,
          x: isMobileMenuOpen ? 0 : (isSidebarOpen ? 0 : -280)
        }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className={`fixed lg:static inset-y-0 left-0 z-50 bg-white border-r border-gray-200 flex flex-col overflow-hidden ${
          isMobileMenuOpen ? 'block' : 'hidden lg:flex'
        }`}
        style={{ width: isSidebarOpen ? 280 : 0 }}
      >
        {/* Logo & Close Button (Mobile) */}
        <div className="p-4 border-b flex items-center justify-between">
          <Link to="/dashboard" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div className="overflow-hidden">
              <span className="text-lg font-bold text-gray-900 whitespace-nowrap">QAFRICA</span>
              <p className="text-xs text-gray-500 whitespace-nowrap">Seller Dashboard</p>
            </div>
          </Link>
          {/* Mobile Close Button */}
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Store Info */}
        {currentStore && (
          <div className="p-4 border-b">
            <a 
              href={`/my-site/${currentStore.slug}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 bg-orange-50 rounded-xl hover:bg-orange-100 transition-colors"
            >
              <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center flex-shrink-0">
                <Store className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0 overflow-hidden">
                <p className="font-medium text-gray-900 truncate">{currentStore.name}</p>
                <p className="text-xs text-gray-500 truncate">/my-site/{currentStore.slug}</p>
              </div>
            </a>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {sidebarItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsMobileMenuOpen(false)}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                isActive(item.path)
                  ? 'bg-orange-50 text-orange-600 font-medium'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <item.icon className={`w-5 h-5 flex-shrink-0 ${isActive(item.path) ? 'text-orange-500' : 'text-gray-400'}`} />
              <span className="whitespace-nowrap">{item.label}</span>
              {isActive(item.path) && (
                <motion.div
                  layoutId="activeIndicator"
                  className="ml-auto w-1.5 h-1.5 bg-orange-500 rounded-full flex-shrink-0"
                />
              )}
            </Link>
          ))}
        </nav>

        {/* Subscription Card */}
        <div className="p-4">
          <div className="bg-gradient-to-r from-orange-500 to-orange-600 rounded-xl p-4 text-white">
            <div className="flex items-center gap-2 mb-2">
              <Crown className="w-5 h-5 flex-shrink-0" />
              <span className="font-medium whitespace-nowrap">Growth Plan</span>
            </div>
            <p className="text-sm text-orange-100 mb-3 whitespace-nowrap">Expires in 28 days</p>
            <Link to="/dashboard/subscription">
              <Button size="sm" variant="secondary" className="w-full bg-white text-orange-600 hover:bg-orange-50">
                Manage Subscription
              </Button>
            </Link>
          </div>
        </div>

        {/* User Section */}
        <div className="p-4 border-t">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center flex-shrink-0">
              <User className="w-5 h-5 text-gray-500" />
            </div>
            <div className="flex-1 min-w-0 overflow-hidden">
              <p className="font-medium text-gray-900 truncate">{user?.full_name}</p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <LogOut className="w-5 h-5 flex-shrink-0" />
            <span className="whitespace-nowrap">Logout</span>
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
          <div className="flex items-center justify-between h-16 px-4 lg:px-8">
            {/* Left Side */}
            <div className="flex items-center gap-4">
              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(true)}
                className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <Menu className="w-6 h-6" />
              </button>
              {/* Desktop Sidebar Toggle */}
              <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="hidden lg:flex p-2 hover:bg-gray-100 rounded-lg transition-colors"
                title={isSidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
              >
                {isSidebarOpen ? (
                  <ChevronLeft className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
              <h1 className="text-lg font-semibold text-gray-900 hidden sm:block">
                {sidebarItems.find((item) => isActive(item.path))?.label || 'Dashboard'}
              </h1>
            </div>

            {/* Right Side */}
            <div className="flex items-center gap-3">
              {/* Language Selector */}
              <LanguageSelector variant="minimal" />
              
              {/* Notifications */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Bell className="w-5 h-5 text-gray-600" />
                  {stockAlerts.length > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                      {stockAlerts.length > 9 ? '9+' : stockAlerts.length}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown */}
                {showNotifications && (
                  <>
                    <div 
                      className="fixed inset-0 z-40"
                      onClick={() => setShowNotifications(false)}
                    />
                    <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-lg border border-gray-200 z-50 overflow-hidden">
                      <div className="p-4 border-b flex items-center justify-between">
                        <h3 className="font-semibold text-gray-900">Notifications</h3>
                        {stockAlerts.length > 0 && (
                          <button
                            onClick={handleMarkAllRead}
                            className="text-sm text-orange-600 hover:text-orange-700"
                          >
                            Mark all read
                          </button>
                        )}
                      </div>
                      <div className="max-h-80 overflow-y-auto">
                        {stockAlerts.length === 0 ? (
                          <div className="p-8 text-center">
                            <Bell className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                            <p className="text-gray-500">No new notifications</p>
                          </div>
                        ) : (
                          stockAlerts.map((alert) => (
                            <div
                              key={alert.id}
                              className="p-4 border-b hover:bg-gray-50 cursor-pointer"
                              onClick={() => handleMarkAlertRead(alert.id)}
                            >
                              <div className="flex items-start gap-3">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                                  alert.alert_type === 'out_of_stock' 
                                    ? 'bg-red-100' 
                                    : 'bg-yellow-100'
                                }`}>
                                  <AlertTriangle className={`w-4 h-4 ${
                                    alert.alert_type === 'out_of_stock'
                                      ? 'text-red-600'
                                      : 'text-yellow-600'
                                  }`} />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium text-gray-900 text-sm">
                                    {alert.alert_type === 'out_of_stock' 
                                      ? 'Out of Stock' 
                                      : 'Low Stock Alert'}
                                  </p>
                                  <p className="text-sm text-gray-500 truncate">
                                    {alert.product?.name || 'Product'}
                                  </p>
                                  <p className="text-xs text-gray-400 mt-1">
                                    Stock: {alert.current_stock} units
                                  </p>
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* View Store */}
              {currentStore && (
                <a
                  href={`/my-site/${currentStore.slug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hidden sm:flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                >
                  <Store className="w-4 h-4" />
                  <span>View Store</span>
                </a>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 lg:p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
