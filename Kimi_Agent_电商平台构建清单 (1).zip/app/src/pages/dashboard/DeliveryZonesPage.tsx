import { useState, useEffect } from 'react';
import { MapPin, Plus, Trash2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useStoreStore } from '@/stores';
import CONFIG from '@/lib/config';
import { toast } from 'sonner';

export default function DeliveryZonesPage() {
  const { currentStore, deliveryZones, fetchDeliveryZones, addDeliveryZone, deleteDeliveryZone } = useStoreStore();
  const [isAdding, setIsAdding] = useState(false);
  const [isDeleting, setIsDeleting] = useState<string | null>(null);
  const [newZone, setNewZone] = useState({ state: '', price: '' });

  useEffect(() => {
    if (currentStore?.id) {
      fetchDeliveryZones(currentStore.id);
    }
  }, [currentStore, fetchDeliveryZones]);

  const handleAdd = async () => {
    if (!newZone.state || !newZone.price) {
      toast.error('Please fill in all fields');
      return;
    }

    if (!currentStore?.id) return;

    setIsAdding(true);

    const result = await addDeliveryZone({
      store_id: currentStore.id,
      state: newZone.state,
      price: parseFloat(newZone.price),
      is_active: true,
    });

    if (result.success) {
      toast.success('Delivery zone added');
      setNewZone({ state: '', price: '' });
    } else {
      toast.error(result.error || 'Failed to add zone');
    }

    setIsAdding(false);
  };

  const handleDelete = async (zoneId: string) => {
    if (!confirm('Are you sure?')) return;

    setIsDeleting(zoneId);
    const result = await deleteDeliveryZone(zoneId);

    if (result.success) {
      toast.success('Zone removed');
    } else {
      toast.error(result.error || 'Failed to remove zone');
    }

    setIsDeleting(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Delivery Zones</h1>
        <p className="text-gray-500 mt-1">Set delivery prices for different states</p>
      </div>

      {/* Add Zone */}
      <div className="bg-white rounded-xl border border-gray-100 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Add New Zone</h2>
        <div className="grid sm:grid-cols-3 gap-4">
          <select
            value={newZone.state}
            onChange={(e) => setNewZone({ ...newZone, state: e.target.value })}
            className="input-custom"
          >
            <option value="">Select State</option>
            {CONFIG.NIGERIAN_STATES.map((state) => (
              <option key={state} value={state}>{state}</option>
            ))}
          </select>
          <input
            type="number"
            value={newZone.price}
            onChange={(e) => setNewZone({ ...newZone, price: e.target.value })}
            placeholder="Delivery Price (₦)"
            className="input-custom"
          />
          <Button
            onClick={handleAdd}
            disabled={isAdding}
            className="bg-orange-500 hover:bg-orange-600 text-white"
          >
            {isAdding ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Plus className="w-4 h-4 mr-2" />
                Add Zone
              </>
            )}
          </Button>
        </div>
        <p className="text-sm text-gray-500 mt-3">
          A ₦{CONFIG.PLATFORM_MARKUP} platform fee will be added to each delivery
        </p>
      </div>

      {/* Zones List */}
      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
        {deliveryZones.length === 0 ? (
          <div className="p-12 text-center">
            <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No delivery zones set up yet</p>
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">State</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Your Price</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer Pays</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {deliveryZones.map((zone) => (
                <tr key={zone.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="font-medium text-gray-900">{zone.state}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">₦{zone.price.toLocaleString()}</td>
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">
                    ₦{(zone.price + CONFIG.PLATFORM_MARKUP).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button
                      onClick={() => handleDelete(zone.id)}
                      disabled={isDeleting === zone.id}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      {isDeleting === zone.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
