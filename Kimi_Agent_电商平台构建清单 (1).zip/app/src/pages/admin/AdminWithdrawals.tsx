import { useEffect, useState } from 'react';
import { CreditCard, CheckCircle, XCircle, Building2, User } from 'lucide-react';
import { useWalletStore } from '@/stores';
import { toast } from 'sonner';

export default function AdminWithdrawals() {
  const { pendingWithdrawals, fetchPendingWithdrawals, approveWithdrawal } = useWalletStore();
  const [processing, setProcessing] = useState<string | null>(null);

  useEffect(() => {
    fetchPendingWithdrawals();
  }, [fetchPendingWithdrawals]);

  const handleApprove = async (id: string, amount: number) => {
    setProcessing(id);
    const result = await approveWithdrawal(id, 'admin-id', amount);
    if (result.success) {
      toast.success('Withdrawal approved');
    } else {
      toast.error('Failed to approve');
    }
    setProcessing(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Withdrawals</h1>
        <p className="text-gray-500 mt-1">Manage withdrawal requests</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-6 border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">Pending</p>
          <p className="text-3xl font-bold text-gray-900">{pendingWithdrawals.length}</p>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">Total Amount</p>
          <p className="text-3xl font-bold text-gray-900">
            ₦{pendingWithdrawals.reduce((sum, w) => sum + w.amount, 0).toLocaleString()}
          </p>
        </div>
        <div className="bg-white rounded-xl p-6 border border-gray-100">
          <p className="text-sm text-gray-500 mb-1">Processed Today</p>
          <p className="text-3xl font-bold text-gray-900">0</p>
        </div>
      </div>

      {/* Pending Withdrawals */}
      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden">
        <div className="p-6 border-b">
          <h2 className="text-lg font-semibold text-gray-900">Pending Requests</h2>
        </div>
        {pendingWithdrawals.length === 0 ? (
          <div className="p-12 text-center">
            <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No pending withdrawals</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {pendingWithdrawals.map((withdrawal) => (
              <div key={withdrawal.id} className="p-6 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                    <User className="w-6 h-6 text-orange-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">₦{withdrawal.amount.toLocaleString()}</p>
                    <div className="flex items-center gap-4 mt-1 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Building2 className="w-4 h-4" />
                        {withdrawal.bank_name}
                      </span>
                      <span>{withdrawal.account_number}</span>
                      <span>{withdrawal.account_name}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleApprove(withdrawal.id, withdrawal.amount)}
                    disabled={processing === withdrawal.id}
                    className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                  >
                    {processing === withdrawal.id ? (
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <CheckCircle className="w-4 h-4" />
                    )}
                    Approve
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors">
                    <XCircle className="w-4 h-4" />
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
