import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, ArrowRight, Check, Loader2, Star, Zap, Crown, CheckCircle, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CONFIG from '@/lib/config';
import { loadPaystackScript, initializePayment, generateReference, toKobo } from '@/services/paystack';
import { toast } from 'sonner';

const durations = [
  { value: 1, label: '1 Month', multiplier: 1, discount: '0%' },
  { value: 3, label: '3 Months', multiplier: 2.7, discount: '10%' },
  { value: 6, label: '6 Months', multiplier: 5, discount: '17%' },
  { value: 12, label: '1 Year', multiplier: 9, discount: '25%' },
];

const plans = [
  {
    id: 'single',
    name: 'Starter',
    icon: Star,
    description: 'Perfect for beginners',
    basePrice: CONFIG.PRICING.SINGLE_NICHE,
    maxNiches: 1,
    features: [
      '1 Niche Selection',
      'Unlimited Products',
      'Basic Analytics',
      'Standard Themes',
      'Email Support',
      'Import Catalog (View Only)',
    ],
    cta: 'Get Started',
    popular: false,
  },
  {
    id: 'three',
    name: 'Growth',
    icon: Zap,
    description: 'For expanding businesses',
    basePrice: CONFIG.PRICING.THREE_NICHES,
    maxNiches: 3,
    features: [
      '3 Niche Selections',
      'Unlimited Products',
      'Advanced Analytics',
      'Premium Themes',
      'Priority Support',
      'Full Import Catalog Access',
      'Dropshipping Features',
    ],
    cta: 'Get Started',
    popular: true,
  },
  {
    id: 'unlimited',
    name: 'Enterprise',
    icon: Crown,
    description: 'For established brands',
    basePrice: CONFIG.PRICING.UNLIMITED,
    maxNiches: Infinity,
    features: [
      'Unlimited Niches',
      'Unlimited Products',
      'Full Analytics Suite',
      'All Themes + Custom',
      '24/7 Priority Support',
      'Import Catalog + Dropship',
      'Dedicated Account Manager',
      'API Access',
    ],
    cta: 'Contact Sales',
    popular: false,
  },
];

export default function PricingPage() {
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState<string>('three');
  const [selectedDuration, setSelectedDuration] = useState<number>(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isTrialLoading, setIsTrialLoading] = useState(false);
  const [selectedNiches, setSelectedNiches] = useState<string[]>([]);

  useEffect(() => {
    const niches = sessionStorage.getItem('selected_niches');
    if (niches) {
      setSelectedNiches(JSON.parse(niches));
    } else {
      toast.error('Please select a niche first');
      navigate('/select-niche');
    }
  }, [navigate]);

  const calculatePrice = (planId: string, duration: number) => {
    const plan = plans.find((p) => p.id === planId);
    if (!plan) return 0;
    
    const durationConfig = durations.find((d) => d.value === duration);
    const multiplier = durationConfig?.multiplier || 1;
    
    return Math.round(plan.basePrice * multiplier);
  };

  const handleSubscribe = async () => {
    setIsLoading(true);
    
    try {
      // Load Paystack script
      await loadPaystackScript();
      
      const amount = calculatePrice(selectedPlan, selectedDuration);
      const reference = generateReference('SUB');
      const email = sessionStorage.getItem('signup_email') || 'user@example.com';
      
      // Store subscription details
      sessionStorage.setItem('subscription_plan', selectedPlan);
      sessionStorage.setItem('subscription_duration', selectedDuration.toString());
      sessionStorage.setItem('subscription_amount', amount.toString());
      sessionStorage.setItem('payment_reference', reference);
      
      // Initialize Paystack inline payment
      initializePayment({
        email,
        amount: toKobo(amount),
        reference,
        metadata: {
          plan: selectedPlan,
          duration: selectedDuration,
          niches: selectedNiches,
        },
        onSuccess: (response) => {
          toast.success('Payment successful!');
          // Navigate to callback with payment reference
          navigate(`/payment/callback?reference=${response.reference}`);
        },
        onCancel: () => {
          setIsLoading(false);
          toast.info('Payment cancelled. You can try again.');
        },
      });
    } catch (err) {
      setIsLoading(false);
      toast.error('Payment initialization failed. Please try again.');
    }
  };

  const handleFreeTrial = async () => {
    setIsTrialLoading(true);
    
    // Store trial info and redirect to callback
    sessionStorage.setItem('subscription_plan', 'three');
    sessionStorage.setItem('subscription_duration', '0');
    sessionStorage.setItem('subscription_amount', '0');
    sessionStorage.setItem('payment_reference', 'FREE_TRIAL');
    
    // Redirect to callback with trial flag
    navigate('/payment/callback?trial=true');
    
    setIsTrialLoading(false);
  };

  const currentPrice = calculatePrice(selectedPlan, selectedDuration);
  const selectedPlanData = plans.find((p) => p.id === selectedPlan);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50 py-8 px-4">
      {/* Background Elements */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-orange-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-orange-300/20 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2">
            <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center">
              <ShoppingBag className="w-7 h-7 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-900">QAFRICA</span>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
              <Check className="w-5 h-5" />
            </div>
            <span className="text-sm font-medium text-green-600">Account</span>
          </div>
          <div className="w-12 h-0.5 bg-green-500" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
              <Check className="w-5 h-5" />
            </div>
            <span className="text-sm font-medium text-green-600">Niche</span>
          </div>
          <div className="w-12 h-0.5 bg-orange-500" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
              3
            </div>
            <span className="text-sm font-medium text-orange-600">Plan</span>
          </div>
        </div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-3">
              Choose Your Plan
            </h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Select the plan that best fits your business needs. All plans include secure payments, 
              escrow protection, and access to our import catalog.
            </p>
          </div>

          {/* Free Trial Banner */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl p-6 mb-8 text-white"
          >
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-7 h-7" />
                </div>
                <div>
                  <h2 className="text-xl font-bold mb-1">Start with a 3-Day Free Trial</h2>
                  <p className="text-green-100">Try all Growth plan features risk-free. No credit card required.</p>
                </div>
              </div>
              <Button
                onClick={handleFreeTrial}
                disabled={isTrialLoading}
                className="bg-white text-green-600 hover:bg-green-50 px-8 h-12"
              >
                {isTrialLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    Start Free Trial
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </motion.div>

          {/* Duration Selector */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-8 max-w-3xl mx-auto">
            <p className="text-sm font-medium text-gray-700 mb-3 text-center">Select Billing Period</p>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {durations.map((duration) => (
                <button
                  key={duration.value}
                  onClick={() => setSelectedDuration(duration.value)}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    selectedDuration === duration.value
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                >
                  <p className={`font-medium ${selectedDuration === duration.value ? 'text-orange-700' : 'text-gray-700'}`}>
                    {duration.label}
                  </p>
                  <p className={`text-xs ${selectedDuration === duration.value ? 'text-orange-600' : 'text-gray-500'}`}>
                    Save {duration.discount}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Plans Grid */}
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {plans.map((plan, index) => {
              const Icon = plan.icon;
              const price = calculatePrice(plan.id, selectedDuration);
              const isSelected = selectedPlan === plan.id;
              const canSelect = selectedNiches.length <= plan.maxNiches;

              return (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative rounded-2xl border-2 transition-all duration-300 ${
                    isSelected
                      ? 'border-orange-500 shadow-xl scale-105 bg-white'
                      : 'border-gray-200 hover:border-orange-300 hover:shadow-lg bg-white'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <span className="px-4 py-1 bg-orange-500 text-white text-sm font-medium rounded-full">
                        Most Popular
                      </span>
                    </div>
                  )}

                  {!canSelect && (
                    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm rounded-2xl flex items-center justify-center z-10">
                      <div className="text-center p-4">
                        <p className="text-gray-600 font-medium">Too many niches selected</p>
                        <p className="text-sm text-gray-500">Upgrade to select more</p>
                      </div>
                    </div>
                  )}

                  <div className="p-8">
                    {/* Plan Header */}
                    <div className="text-center mb-6">
                      <div className={`w-14 h-14 rounded-xl flex items-center justify-center mx-auto mb-4 ${
                        isSelected ? 'bg-orange-500' : 'bg-orange-100'
                      }`}>
                        <Icon className={`w-7 h-7 ${isSelected ? 'text-white' : 'text-orange-500'}`} />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-1">{plan.name}</h3>
                      <p className="text-sm text-gray-500">{plan.description}</p>
                    </div>

                    {/* Price */}
                    <div className="text-center mb-6">
                      <div className="flex items-baseline justify-center gap-1">
                        <span className="text-2xl font-bold text-gray-900">₦{price.toLocaleString()}</span>
                        <span className="text-gray-500">/{selectedDuration === 1 ? 'month' : `${selectedDuration} months`}</span>
                      </div>
                      {selectedDuration > 1 && (
                        <p className="text-sm text-green-600 mt-1">
                          You save ₦{((plan.basePrice * selectedDuration) - price).toLocaleString()}
                        </p>
                      )}
                    </div>

                    {/* Features */}
                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <CheckCircle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                            isSelected ? 'text-orange-500' : 'text-gray-400'
                          }`} />
                          <span className="text-sm text-gray-600">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Select Button */}
                    <button
                      onClick={() => canSelect && setSelectedPlan(plan.id)}
                      className={`w-full py-3 rounded-lg font-medium transition-all ${
                        isSelected
                          ? 'bg-orange-500 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                      disabled={!canSelect}
                    >
                      {isSelected ? 'Selected' : 'Select Plan'}
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Summary & CTA */}
          <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 max-w-2xl mx-auto">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <p className="text-gray-500 mb-1">Your Selection</p>
                <p className="text-lg font-semibold text-gray-900">
                  {selectedPlanData?.name} Plan • {durations.find(d => d.value === selectedDuration)?.label}
                </p>
                <p className="text-sm text-gray-500">
                  {selectedNiches.length} niche{selectedNiches.length > 1 ? 's' : ''} selected
                </p>
              </div>
              <div className="text-center md:text-right">
                <p className="text-3xl font-bold text-orange-600">₦{currentPrice.toLocaleString()}</p>
                <p className="text-sm text-gray-500">Total amount</p>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t">
              <Button
                onClick={handleSubscribe}
                className="w-full bg-orange-500 hover:bg-orange-600 text-white h-14 text-lg"
                disabled={isLoading}
              >
                {isLoading ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <>
                    Proceed to Payment
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>
              <p className="text-center text-sm text-gray-500 mt-4">
                Secure payment powered by Paystack
              </p>
            </div>
          </div>

          {/* Back Button */}
          <div className="text-center mt-8">
            <button
              onClick={() => navigate('/select-niche')}
              className="text-gray-500 hover:text-gray-700 font-medium"
            >
              ← Back to Niche Selection
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
