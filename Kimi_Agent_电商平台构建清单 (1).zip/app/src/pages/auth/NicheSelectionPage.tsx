import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, ArrowRight, Check, Shirt, Gem, Smartphone, Sparkles, Home, Dumbbell, Utensils, Heart, Gamepad, BookOpen, Car, PawPrint } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CONFIG from '@/lib/config';
import { toast } from 'sonner';

const nicheIcons: Record<string, React.ElementType> = {
  clothing: Shirt,
  jewelry: Gem,
  electronics: Smartphone,
  beauty: Sparkles,
  home: Home,
  sports: Dumbbell,
  food: Utensils,
  health: Heart,
  toys: Gamepad,
  books: BookOpen,
  automotive: Car,
  pets: PawPrint,
};

export default function NicheSelectionPage() {
  const navigate = useNavigate();
  const [selectedNiches, setSelectedNiches] = useState<string[]>([]);

  const toggleNiche = (nicheId: string) => {
    setSelectedNiches((prev) => {
      if (prev.includes(nicheId)) {
        return prev.filter((id) => id !== nicheId);
      }
      if (prev.length >= 3) {
        toast.info('You can select up to 3 niches on the Growth plan');
        return prev;
      }
      return [...prev, nicheId];
    });
  };

  const handleContinue = () => {
    if (selectedNiches.length === 0) {
      toast.error('Please select at least one niche');
      return;
    }

    // Store selected niches in session storage
    sessionStorage.setItem('selected_niches', JSON.stringify(selectedNiches));
    navigate('/pricing');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50 py-8 px-4">
      {/* Background Elements */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-orange-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-orange-300/20 rounded-full blur-3xl" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2">
            <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center">
              <ShoppingBag className="w-7 h-7 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-900">QAFRICA</span>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
              <Check className="w-5 h-5" />
            </div>
            <span className="text-sm font-medium text-green-600">Account</span>
          </div>
          <div className="w-12 h-0.5 bg-orange-500" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
              2
            </div>
            <span className="text-sm font-medium text-orange-600">Niche</span>
          </div>
          <div className="w-12 h-0.5 bg-gray-200" />
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gray-200 text-gray-500 rounded-full flex items-center justify-center text-sm font-medium">
              3
            </div>
            <span className="text-sm text-gray-500">Plan</span>
          </div>
        </div>

        {/* Main Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8"
        >
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-3">
              Select Your Niche
            </h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Choose the category that best describes your business. You can select up to 3 niches.
              Each niche comes with tailored themes and features.
            </p>
          </div>

          {/* Selected Count */}
          <div className="flex items-center justify-center gap-2 mb-8">
            <span className="text-sm text-gray-500">Selected:</span>
            <span className={`text-sm font-medium ${selectedNiches.length > 0 ? 'text-orange-600' : 'text-gray-400'}`}>
              {selectedNiches.length} of 3
            </span>
          </div>

          {/* Niches Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
            {CONFIG.NICHES.map((niche, index) => {
              const Icon = nicheIcons[niche.id] || ShoppingBag;
              const isSelected = selectedNiches.includes(niche.id);

              return (
                <motion.button
                  key={niche.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => toggleNiche(niche.id)}
                  className={`relative p-6 rounded-xl border-2 transition-all duration-300 text-left ${
                    isSelected
                      ? 'border-orange-500 bg-orange-50 shadow-lg'
                      : 'border-gray-200 hover:border-orange-300 hover:shadow-md bg-white'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute top-3 right-3 w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                  )}
                  
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${
                    isSelected ? 'bg-orange-500' : 'bg-orange-100'
                  }`}>
                    <Icon className={`w-6 h-6 ${isSelected ? 'text-white' : 'text-orange-500'}`} />
                  </div>
                  
                  <h3 className={`font-semibold mb-1 ${isSelected ? 'text-orange-900' : 'text-gray-900'}`}>
                    {niche.name}
                  </h3>
                  <p className={`text-sm ${isSelected ? 'text-orange-700' : 'text-gray-500'}`}>
                    {niche.description}
                  </p>
                </motion.button>
              );
            })}
          </div>

          {/* Info Box */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-8">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="font-semibold text-blue-900 mb-1">Why select a niche?</h4>
                <p className="text-sm text-blue-700">
                  Your niche determines the themes, features, and product categories available to you. 
                  You can always upgrade your plan to access more niches later.
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <button
              onClick={() => navigate('/signup')}
              className="text-gray-500 hover:text-gray-700 font-medium"
            >
              ← Back
            </button>
            
            <Button
              onClick={handleContinue}
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 h-12"
              disabled={selectedNiches.length === 0}
            >
              Continue to Pricing
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </motion.div>

        {/* Help Text */}
        <p className="text-center mt-6 text-gray-500 text-sm">
          Need help choosing? <a href="#" className="text-orange-500 hover:text-orange-600">Contact our support team</a>
        </p>
      </div>
    </div>
  );
}
