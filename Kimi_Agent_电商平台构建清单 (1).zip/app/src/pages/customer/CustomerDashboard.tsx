import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ShoppingBag, Package, Heart, MapPin, User, LogOut,
  ChevronRight, Clock, CheckCircle, Truck,
  ShoppingCart, Store
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCustomerAuthStore, useCartStore } from '@/stores';
import { supabase } from '@/services/supabase';
import { toast } from 'sonner';
import type { CustomerOrder } from '@/types';

// Tab Components
function OrdersTab() {
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { customer } = useCustomerAuthStore();

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    if (!customer) return;
    
    try {
      const { data, error } = await supabase
        .from('customer_orders')
        .select('*')
        .eq('customer_id', customer.id)
        .order('created_at', { ascending: false });

      if (data && !error) {
        setOrders(data as CustomerOrder[]);
      }
    } catch (err) {
      console.error('Failed to fetch orders:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'shipped':
        return <Truck className="w-5 h-5 text-blue-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-orange-500" />;
      default:
        return <Package className="w-5 h-5 text-gray-500" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12">
        <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">No orders yet</h3>
        <p className="text-gray-500 mb-4">Start shopping to see your orders here</p>
        <Link to="/stores">
          <Button className="bg-orange-500 hover:bg-orange-600 text-white">
            Browse Stores
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <motion.div
          key={order.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white border rounded-xl p-4 hover:shadow-md transition-shadow"
        >
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-sm text-gray-500">Order #{order.order_number}</p>
              <p className="text-sm text-gray-400">{new Date(order.created_at).toLocaleDateString()}</p>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(order.status)}
              <span className="text-sm font-medium capitalize">{order.status}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
              <Store className="w-6 h-6 text-gray-400" />
            </div>
            <div>
              <p className="font-medium">{order.store_name}</p>
              <p className="text-sm text-gray-500">{order.items.length} item(s)</p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t">
            <p className="font-bold">₦{order.total.toLocaleString()}</p>
            <Link 
              to={`/customer/orders/${order.id}`}
              className="text-orange-600 hover:text-orange-700 text-sm font-medium flex items-center gap-1"
            >
              View Details
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

function AddressesTab() {
  const { addresses, deleteAddress, setDefaultAddress } = useCustomerAuthStore();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-gray-900">Saved Addresses</h3>
        <Link to="/customer/dashboard?tab=addresses&add=true">
          <Button 
            variant="outline"
            className="text-orange-600 border-orange-600"
          >
            + Add New
          </Button>
        </Link>
      </div>

      {addresses.length === 0 ? (
        <div className="text-center py-8 bg-gray-50 rounded-xl">
          <MapPin className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No saved addresses</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {addresses.map((address) => (
            <div 
              key={address.id}
              className={`border rounded-xl p-4 ${address.is_default ? 'border-orange-500 bg-orange-50' : ''}`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium">{address.label}</span>
                    {address.is_default && (
                      <span className="text-xs bg-orange-500 text-white px-2 py-0.5 rounded-full">
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-gray-600">{address.street}</p>
                  <p className="text-gray-600">{address.city}, {address.state}</p>
                  <p className="text-gray-600">{address.country}</p>
                </div>
                <div className="flex gap-2">
                  {!address.is_default && (
                    <button
                      onClick={() => setDefaultAddress(address.id)}
                      className="text-sm text-orange-600 hover:text-orange-700"
                    >
                      Set Default
                    </button>
                  )}
                  <button
                    onClick={() => deleteAddress(address.id)}
                    className="text-sm text-red-500 hover:text-red-700"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function WishlistTab() {
  const { wishlist, removeFromWishlist } = useCartStore();
  const [wishlistItems, setWishlistItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchWishlistItems();
  }, [wishlist]);

  const fetchWishlistItems = async () => {
    if (wishlist.length === 0) {
      setIsLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('products')
        .select('*, store:stores(name, slug)')
        .in('id', wishlist);

      if (data && !error) {
        setWishlistItems(data);
      }
    } catch (err) {
      console.error('Failed to fetch wishlist:', err);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (wishlistItems.length === 0) {
    return (
      <div className="text-center py-12">
        <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Your wishlist is empty</h3>
        <p className="text-gray-500 mb-4">Save items you love for later</p>
        <Link to="/stores">
          <Button className="bg-orange-500 hover:bg-orange-600 text-white">
            Browse Stores
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {wishlistItems.map((item) => (
        <motion.div
          key={item.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-white border rounded-xl overflow-hidden group"
        >
          <div className="aspect-square bg-gray-100 relative">
            {item.images?.[0] ? (
              <img 
                src={item.images[0]} 
                alt={item.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-4xl text-gray-300">{item.name.charAt(0)}</span>
              </div>
            )}
            <button
              onClick={() => removeFromWishlist(item.id)}
              className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Heart className="w-4 h-4 fill-red-500 text-red-500" />
            </button>
          </div>
          <div className="p-3">
            <p className="font-medium text-sm line-clamp-1">{item.name}</p>
            <p className="text-orange-600 font-bold">₦{item.selling_price?.toLocaleString()}</p>
            <Link 
              to={`/my-site/${item.store?.slug}/product/${item.id}`}
              className="text-xs text-gray-500 hover:text-orange-600 mt-1 block"
            >
              {item.store?.name}
            </Link>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

function ProfileTab() {
  const { customer, updateProfile, logout } = useCustomerAuthStore();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: customer?.full_name || '',
    phone: customer?.phone || '',
  });

  const handleSave = async () => {
    const result = await updateProfile(formData);
    if (result.success) {
      toast.success('Profile updated');
      setIsEditing(false);
    } else {
      toast.error(result.error || 'Update failed');
    }
  };

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out');
    navigate('/');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white border rounded-xl p-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
            {customer?.full_name.charAt(0)}
          </div>
          <div>
            <h3 className="font-semibold text-lg">{customer?.full_name}</h3>
            <p className="text-gray-500">{customer?.email}</p>
          </div>
        </div>

        {isEditing ? (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              <input
                type="text"
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-4 py-2 border rounded-lg"
              />
            </div>
            <div className="flex gap-3">
              <Button onClick={handleSave} className="bg-orange-500 hover:bg-orange-600 text-white">
                Save Changes
              </Button>
              <Button variant="outline" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium">{customer?.phone || 'Not set'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Member Since</p>
                <p className="font-medium">
                  {customer?.created_at && new Date(customer.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
            <Button variant="outline" onClick={() => setIsEditing(true)}>
              Edit Profile
            </Button>
          </div>
        )}
      </div>

      <Button 
        variant="outline" 
        onClick={handleLogout}
        className="w-full text-red-500 border-red-500 hover:bg-red-50"
      >
        <LogOut className="w-4 h-4 mr-2" />
        Log Out
      </Button>
    </div>
  );
}

// Main Dashboard Component
export default function CustomerDashboard() {
  const [activeTab, setActiveTab] = useState<'orders' | 'addresses' | 'wishlist' | 'profile'>('orders');
  const { customer, isAuthenticated } = useCustomerAuthStore();
  const { getItemCount } = useCartStore();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/customer/login?return=/customer/dashboard');
    }
  }, [isAuthenticated, navigate]);

  if (!customer) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const tabs = [
    { key: 'orders', label: 'My Orders', icon: Package },
    { key: 'addresses', label: 'Addresses', icon: MapPin },
    { key: 'wishlist', label: 'Wishlist', icon: Heart },
    { key: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl">QuickSell</span>
            </Link>

            <div className="flex items-center gap-4">
              <Link to="/stores" className="text-gray-600 hover:text-gray-900">
                <Store className="w-5 h-5" />
              </Link>
              <Link to="/cart" className="relative text-gray-600 hover:text-gray-900">
                <ShoppingCart className="w-5 h-5" />
                {getItemCount() > 0 && (
                  <span className="absolute -top-2 -right-2 w-5 h-5 bg-orange-500 text-white text-xs rounded-full flex items-center justify-center">
                    {getItemCount()}
                  </span>
                )}
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border p-4">
              <div className="flex items-center gap-3 mb-6 p-2">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-full flex items-center justify-center text-white font-bold">
                  {customer.full_name.charAt(0)}
                </div>
                <div className="overflow-hidden">
                  <p className="font-medium truncate">{customer.full_name}</p>
                  <p className="text-sm text-gray-500 truncate">{customer.email}</p>
                </div>
              </div>

              <nav className="space-y-1">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.key}
                      onClick={() => setActiveTab(tab.key as any)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-colors ${
                        activeTab === tab.key
                          ? 'bg-orange-50 text-orange-600'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{tab.label}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-3">
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">
                {tabs.find(t => t.key === activeTab)?.label}
              </h2>

              {activeTab === 'orders' && <OrdersTab />}
              {activeTab === 'addresses' && <AddressesTab />}
              {activeTab === 'wishlist' && <WishlistTab />}
              {activeTab === 'profile' && <ProfileTab />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
