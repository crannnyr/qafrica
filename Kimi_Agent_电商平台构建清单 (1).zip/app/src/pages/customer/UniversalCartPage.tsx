// Universal Cart Page - Shows items from all stores
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ShoppingCart, Trash2, Minus, Plus, Store, ArrowRight,
  MapPin, AlertCircle, Package, ChevronLeft
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCartStore, useCustomerAuthStore } from '@/stores';
import { toast } from 'sonner';

export default function UniversalCartPage() {
  const navigate = useNavigate();
  const { isAuthenticated, addresses, getDefaultAddress } = useCustomerAuthStore();
  const { 
    items, 
    getItemsByStore, 
    getStoreCount, 
    getTotalItems, 
    getSubtotal,
    getStoreSubtotal,
    updateQuantity, 
    removeItem,
    clearStoreCart 
  } = useCartStore();

  const itemsByStore = getItemsByStore();
  const storeCount = getStoreCount();
  const totalItems = getTotalItems();
  const subtotal = getSubtotal();

  // Calculate delivery fees (mock - in production fetch from store delivery zones)
  const calculateDeliveryFee = (_storeId: string) => {
    // Base delivery fee per store
    return 1500; // ₦1,500 base + ₦500 platform markup = ₦2,000
  };

  const deliveryFees = Object.keys(itemsByStore).reduce((acc, storeId) => {
    acc[storeId] = calculateDeliveryFee(storeId);
    return acc;
  }, {} as Record<string, number>);

  const totalDeliveryFee = Object.values(deliveryFees).reduce((sum, fee) => sum + fee, 0);
  const platformFee = 500 * storeCount; // ₦500 per store
  const total = subtotal + totalDeliveryFee + platformFee;

  const handleCheckout = () => {
    if (!isAuthenticated) {
      toast.info('Please sign in to checkout');
      navigate(`/customer/login?return=/cart`);
      return;
    }

    if (!getDefaultAddress()) {
      toast.info('Please add a delivery address');
      navigate('/customer/dashboard?tab=addresses');
      return;
    }

    // Navigate to checkout
    navigate('/checkout');
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center h-16">
              <Link to="/" className="flex items-center gap-2">
                <ChevronLeft className="w-5 h-5" />
                <span className="font-medium">Continue Shopping</span>
              </Link>
            </div>
          </div>
        </header>

        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingCart className="w-12 h-12 text-gray-400" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Your cart is empty</h1>
            <p className="text-gray-500 mb-6">Looks like you haven't added anything yet</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/stores">
                <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                  Browse Stores
                </Button>
              </Link>
              <Link to="/">
                <Button variant="outline">
                  Go Home
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
                <ShoppingCart className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl">QuickSell</span>
            </Link>

            <div className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5 text-orange-500" />
              <span className="font-medium">Cart ({totalItems})</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold text-gray-900">
                Shopping Cart ({totalItems} items)
              </h1>
              {storeCount > 1 && (
                <span className="text-sm text-orange-600 bg-orange-50 px-3 py-1 rounded-full">
                  From {storeCount} stores
                </span>
              )}
            </div>

            {/* Items Grouped by Store */}
            {Object.entries(itemsByStore).map(([storeId, storeItems]) => (
              <motion.div
                key={storeId}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-xl border overflow-hidden"
              >
                {/* Store Header */}
                <div className="bg-gray-50 px-4 py-3 border-b flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Store className="w-5 h-5 text-gray-400" />
                    <Link 
                      to={`/my-site/${storeItems[0].store_slug}`}
                      className="font-medium hover:text-orange-600"
                    >
                      {storeItems[0].store_name}
                    </Link>
                  </div>
                  <button
                    onClick={() => clearStoreCart(storeId)}
                    className="text-sm text-red-500 hover:text-red-700 flex items-center gap-1"
                  >
                    <Trash2 className="w-4 h-4" />
                    Remove All
                  </button>
                </div>

                {/* Store Items */}
                <div className="divide-y">
                  {storeItems.map((item) => (
                    <div key={item.id} className="p-4 flex gap-4">
                      {/* Product Image */}
                      <div className="w-24 h-24 bg-gray-100 rounded-lg flex-shrink-0 overflow-hidden">
                        {item.product_image ? (
                          <img 
                            src={item.product_image} 
                            alt={item.product_name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Package className="w-8 h-8 text-gray-300" />
                          </div>
                        )}
                      </div>

                      {/* Product Details */}
                      <div className="flex-1 min-w-0">
                        <Link 
                          to={`/my-site/${item.store_slug}/product/${item.product_id}`}
                          className="font-medium text-gray-900 hover:text-orange-600 line-clamp-2"
                        >
                          {item.product_name}
                        </Link>
                        <p className="text-sm text-gray-500 mt-1">{item.store_name}</p>
                        <p className="text-lg font-bold text-orange-600 mt-2">
                          ₦{item.unit_price.toLocaleString()}
                        </p>

                        {/* Quantity Controls */}
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center border rounded-lg">
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity - 1)}
                              className="p-2 hover:bg-gray-100"
                            >
                              <Minus className="w-4 h-4" />
                            </button>
                            <span className="w-10 text-center font-medium">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                              className="p-2 hover:bg-gray-100"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                          <button
                            onClick={() => removeItem(item.id)}
                            className="text-gray-400 hover:text-red-500"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>

                      {/* Item Total */}
                      <div className="text-right">
                        <p className="font-bold text-lg">
                          ₦{item.total_price.toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Store Subtotal */}
                <div className="bg-gray-50 px-4 py-3 border-t text-right">
                  <p className="text-sm text-gray-500">
                    Subtotal: <span className="font-bold text-gray-900">₦{getStoreSubtotal(storeId).toLocaleString()}</span>
                  </p>
                </div>
              </motion.div>
            ))}

            {/* Continue Shopping */}
            <Link 
              to="/stores"
              className="inline-flex items-center gap-2 text-orange-600 hover:text-orange-700 font-medium"
            >
              <ChevronLeft className="w-4 h-4" />
              Continue Shopping
            </Link>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl border sticky top-24">
              <div className="p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Order Summary</h2>

                {/* Delivery Address */}
                {isAuthenticated && addresses.length > 0 ? (
                  <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="font-medium text-sm">Deliver to</span>
                    </div>
                    {getDefaultAddress() ? (
                      <div>
                        <p className="font-medium">{getDefaultAddress()?.label}</p>
                        <p className="text-sm text-gray-500">{getDefaultAddress()?.street}</p>
                        <p className="text-sm text-gray-500">
                          {getDefaultAddress()?.city}, {getDefaultAddress()?.state}
                        </p>
                      </div>
                    ) : (
                      <p className="text-sm text-gray-500">No default address</p>
                    )}
                    <Link 
                      to="/customer/dashboard?tab=addresses"
                      className="text-sm text-orange-600 hover:text-orange-700 mt-2 inline-block"
                    >
                      Change Address
                    </Link>
                  </div>
                ) : isAuthenticated ? (
                  <div className="mb-6 p-4 bg-orange-50 rounded-lg">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm text-orange-800">No delivery address</p>
                        <Link 
                          to="/customer/dashboard?tab=addresses"
                          className="text-sm text-orange-600 hover:text-orange-700 font-medium"
                        >
                          Add Address →
                        </Link>
                      </div>
                    </div>
                  </div>
                ) : null}

                {/* Price Breakdown */}
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Subtotal ({totalItems} items)</span>
                    <span>₦{subtotal.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Delivery Fee ({storeCount} store{storeCount > 1 ? 's' : ''})</span>
                    <span>₦{totalDeliveryFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Platform Fee</span>
                    <span>₦{platformFee.toLocaleString()}</span>
                  </div>
                  <div className="border-t pt-3">
                    <div className="flex justify-between">
                      <span className="font-bold">Total</span>
                      <span className="font-bold text-xl text-orange-600">₦{total.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Checkout Button */}
                <Button
                  onClick={handleCheckout}
                  className="w-full h-12 bg-orange-500 hover:bg-orange-600 text-white font-medium"
                >
                  Proceed to Checkout
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>

                {!isAuthenticated && (
                  <p className="text-center text-sm text-gray-500 mt-4">
                    You'll be asked to sign in during checkout
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
