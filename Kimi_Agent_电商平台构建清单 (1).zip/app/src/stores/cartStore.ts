import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { supabase } from '@/services/supabase';
import type { CartItem, Product, Store } from '@/types';

interface CartStore {
  items: CartItem[];
  isLoading: boolean;
  
  // Getters
  getItemsByStore: () => Record<string, CartItem[]>;
  getStoreCount: () => number;
  getItemCount: () => number;
  getTotalItems: () => number;
  getSubtotal: () => number;
  getStoreSubtotal: (storeId: string) => number;
  
  // Actions
  addItem: (product: Product, store: Store, quantity?: number) => void;
  removeItem: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, quantity: number) => void;
  clearCart: () => void;
  clearStoreCart: (storeId: string) => void;
  
  // Sync with server (for logged-in customers)
  syncWithServer: (customerId: string) => Promise<void>;
  saveToServer: (customerId: string) => Promise<void>;
  
  // Wishlist (also universal)
  wishlist: string[]; // product IDs
  addToWishlist: (productId: string) => void;
  removeFromWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  clearWishlist: () => void;
}

// Generate unique cart item ID
const generateCartItemId = () => `cart_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      isLoading: false,
      wishlist: [],

      // Group items by store
      getItemsByStore: () => {
        const { items } = get();
        return items.reduce((acc, item) => {
          if (!acc[item.store_id]) {
            acc[item.store_id] = [];
          }
          acc[item.store_id].push(item);
          return acc;
        }, {} as Record<string, CartItem[]>);
      },

      // Get number of unique stores in cart
      getStoreCount: () => {
        const { items } = get();
        return new Set(items.map(item => item.store_id)).size;
      },

      // Get number of unique products in cart
      getItemCount: () => {
        return get().items.length;
      },

      // Get total quantity of all items
      getTotalItems: () => {
        return get().items.reduce((sum, item) => sum + item.quantity, 0);
      },

      // Get total cart value
      getSubtotal: () => {
        return get().items.reduce((sum, item) => sum + item.total_price, 0);
      },

      // Get subtotal for a specific store
      getStoreSubtotal: (storeId: string) => {
        return get().items
          .filter(item => item.store_id === storeId)
          .reduce((sum, item) => sum + item.total_price, 0);
      },

      // Add item to cart
      addItem: (product, store, quantity = 1) => {
        set((state) => {
          // Check if same product already in cart from same store
          const existingItemIndex = state.items.findIndex(
            item => item.product_id === product.id && item.store_id === store.id
          );

          if (existingItemIndex >= 0) {
            // Update quantity
            const updatedItems = [...state.items];
            const existingItem = updatedItems[existingItemIndex];
            const newQuantity = existingItem.quantity + quantity;
            updatedItems[existingItemIndex] = {
              ...existingItem,
              quantity: newQuantity,
              total_price: newQuantity * existingItem.unit_price,
            };
            return { items: updatedItems };
          }

          // Add new item
          const newItem: CartItem = {
            id: generateCartItemId(),
            product_id: product.id,
            store_id: store.id,
            store_name: store.name,
            store_slug: store.slug,
            product_name: product.name,
            product_image: product.images?.[0],
            quantity,
            unit_price: product.selling_price,
            total_price: product.selling_price * quantity,
            added_at: new Date().toISOString(),
          };

          return { items: [...state.items, newItem] };
        });
      },

      // Remove item from cart
      removeItem: (cartItemId) => {
        set((state) => ({
          items: state.items.filter(item => item.id !== cartItemId),
        }));
      },

      // Update item quantity
      updateQuantity: (cartItemId, quantity) => {
        if (quantity <= 0) {
          get().removeItem(cartItemId);
          return;
        }

        set((state) => ({
          items: state.items.map(item =>
            item.id === cartItemId
              ? { ...item, quantity, total_price: quantity * item.unit_price }
              : item
          ),
        }));
      },

      // Clear entire cart
      clearCart: () => {
        set({ items: [] });
      },

      // Clear cart for a specific store
      clearStoreCart: (storeId) => {
        set((state) => ({
          items: state.items.filter(item => item.store_id !== storeId),
        }));
      },

      // Sync cart with server (for logged-in customers)
      syncWithServer: async (customerId) => {
        try {
          const { data, error } = await supabase
            .from('customer_carts')
            .select('items')
            .eq('customer_id', customerId)
            .single();

          if (data && !error && data.items) {
            set({ items: data.items as CartItem[] });
          }
        } catch (err) {
          console.error('Failed to sync cart:', err);
        }
      },

      // Save cart to server
      saveToServer: async (customerId) => {
        try {
          const { items } = get();
          
          const { error } = await supabase
            .from('customer_carts')
            .upsert({
              customer_id: customerId,
              items,
              updated_at: new Date().toISOString(),
            }, {
              onConflict: 'customer_id',
            });

          if (error) {
            console.error('Failed to save cart:', error);
          }
        } catch (err) {
          console.error('Failed to save cart:', err);
        }
      },

      // Wishlist functions
      addToWishlist: (productId) => {
        set((state) => ({
          wishlist: [...new Set([...state.wishlist, productId])],
        }));
      },

      removeFromWishlist: (productId) => {
        set((state) => ({
          wishlist: state.wishlist.filter(id => id !== productId),
        }));
      },

      isInWishlist: (productId) => {
        return get().wishlist.includes(productId);
      },

      clearWishlist: () => {
        set({ wishlist: [] });
      },
    }),
    {
      name: 'qafrica-universal-cart',
      partialize: (state) => ({ 
        items: state.items,
        wishlist: state.wishlist,
      }),
    }
  )
);

export default useCartStore;
