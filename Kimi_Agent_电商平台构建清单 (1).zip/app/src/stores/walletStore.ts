import { create } from 'zustand';
import { walletService, withdrawalService } from '@/services/supabase';
import type { Wallet, WalletTransaction, WithdrawalRequest } from '@/types';

interface WalletState {
  wallet: Wallet | null;
  transactions: WalletTransaction[];
  withdrawalRequests: WithdrawalRequest[];
  pendingWithdrawals: WithdrawalRequest[];
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchWallet: (userId: string) => Promise<void>;
  fetchTransactions: (userId: string) => Promise<void>;
  fetchWithdrawalRequests: (userId: string) => Promise<void>;
  fetchPendingWithdrawals: () => Promise<void>;
  createWithdrawalRequest: (requestData: Partial<WithdrawalRequest>) => Promise<{ success: boolean; error?: string }>;
  approveWithdrawal: (requestId: string, adminId: string, amount: number) => Promise<{ success: boolean; error?: string }>;
  creditWallet: (userId: string, amount: number, description: string, reference?: string) => Promise<{ success: boolean; error?: string }>;
  clearError: () => void;
  reset: () => void;
}

export const useWalletStore = create<WalletState>((set, get) => ({
  wallet: null,
  transactions: [],
  withdrawalRequests: [],
  pendingWithdrawals: [],
  isLoading: false,
  error: null,

  fetchWallet: async (userId) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await walletService.getWallet(userId);
      
      if (error) {
        // If wallet doesn't exist, create one
        if (error.code === 'PGRST116') {
          const { data: newWallet, error: createError } = await walletService.createWallet(userId);
          if (!createError) {
            set({ wallet: newWallet as Wallet, isLoading: false });
            return;
          }
        }
        set({ isLoading: false, error: error.message });
        return;
      }

      set({ wallet: data as Wallet, isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch wallet';
      set({ isLoading: false, error: message });
    }
  },

  fetchTransactions: async (userId) => {
    try {
      const { data, error } = await walletService.getTransactions(userId);
      
      if (error) {
        console.error('Failed to fetch transactions:', error);
        return;
      }

      set({ transactions: data as WalletTransaction[] });
    } catch (err) {
      console.error('Failed to fetch transactions:', err);
    }
  },

  fetchWithdrawalRequests: async (userId) => {
    try {
      const { data, error } = await withdrawalService.getUserRequests(userId);
      
      if (error) {
        console.error('Failed to fetch withdrawal requests:', error);
        return;
      }

      set({ withdrawalRequests: data as WithdrawalRequest[] });
    } catch (err) {
      console.error('Failed to fetch withdrawal requests:', err);
    }
  },

  fetchPendingWithdrawals: async () => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await withdrawalService.getPendingRequests();
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return;
      }

      set({ pendingWithdrawals: data as WithdrawalRequest[], isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch pending withdrawals';
      set({ isLoading: false, error: message });
    }
  },

  createWithdrawalRequest: async (requestData) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await withdrawalService.createRequest(requestData);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return { success: false, error: error.message };
      }

      set((state) => ({ 
        withdrawalRequests: [data as WithdrawalRequest, ...state.withdrawalRequests],
        isLoading: false 
      }));
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to create withdrawal request';
      set({ isLoading: false, error: message });
      return { success: false, error: message };
    }
  },

  approveWithdrawal: async (requestId, adminId) => {
    set({ isLoading: true, error: null });
    try {
      const { error } = await withdrawalService.markAsPaid(requestId, adminId);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return { success: false, error: error.message };
      }

      set((state) => ({
        pendingWithdrawals: state.pendingWithdrawals.filter((r) => r.id !== requestId),
        isLoading: false
      }));
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to approve withdrawal';
      set({ isLoading: false, error: message });
      return { success: false, error: message };
    }
  },

  creditWallet: async (userId, amount, description, reference) => {
    set({ isLoading: true, error: null });
    try {
      const { error } = await walletService.creditWallet(userId, amount, description, reference);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return { success: false, error: error.message };
      }

      // Refresh wallet
      await get().fetchWallet(userId);
      
      set((state) => ({
        transactions: [...state.transactions],
        isLoading: false
      }));
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to credit wallet';
      set({ isLoading: false, error: message });
      return { success: false, error: message };
    }
  },

  clearError: () => set({ error: null }),
  reset: () => set({ wallet: null, transactions: [], withdrawalRequests: [], pendingWithdrawals: [], error: null }),
}));

export default useWalletStore;
