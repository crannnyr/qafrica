import { create } from 'zustand';
import { orderService } from '@/services/supabase';
import type { Order } from '@/types';

interface OrderState {
  orders: Order[];
  currentOrder: Order | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  fetchStoreOrders: (storeId: string) => Promise<void>;
  fetchUserOrders: (userId: string) => Promise<void>;
  fetchAllOrders: () => Promise<void>;
  getOrder: (orderId: string) => Promise<void>;
  createOrder: (orderData: Partial<Order>) => Promise<{ success: boolean; data?: Order; error?: string }>;
  updateOrderStatus: (orderId: string, status: Order['status']) => Promise<{ success: boolean; error?: string }>;
  confirmDelivery: (orderId: string) => Promise<{ success: boolean; error?: string }>;
  clearError: () => void;
  reset: () => void;
}

export const useOrderStore = create<OrderState>((set) => ({
  orders: [],
  currentOrder: null,
  isLoading: false,
  error: null,

  fetchStoreOrders: async (storeId) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await orderService.getStoreOrders(storeId);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return;
      }

      set({ orders: data as Order[], isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch orders';
      set({ isLoading: false, error: message });
    }
  },

  fetchUserOrders: async (userId) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await orderService.getUserOrders(userId);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return;
      }

      set({ orders: data as Order[], isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch orders';
      set({ isLoading: false, error: message });
    }
  },

  fetchAllOrders: async () => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await orderService.getAllOrders();
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return;
      }

      set({ orders: data as Order[], isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch orders';
      set({ isLoading: false, error: message });
    }
  },

  getOrder: async (orderId) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await orderService.getOrder(orderId);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return;
      }

      set({ currentOrder: data as Order, isLoading: false });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch order';
      set({ isLoading: false, error: message });
    }
  },

  createOrder: async (orderData) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await orderService.createOrder(orderData);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return { success: false, error: error.message };
      }

      set((state) => ({ 
        orders: [data as Order, ...state.orders],
        currentOrder: data as Order,
        isLoading: false 
      }));
      return { success: true, data: data as Order };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to create order';
      set({ isLoading: false, error: message });
      return { success: false, error: message };
    }
  },

  updateOrderStatus: async (orderId, status) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await orderService.updateOrderStatus(orderId, status);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return { success: false, error: error.message };
      }

      set((state) => ({
        orders: state.orders.map((o) => 
          o.id === orderId ? { ...o, ...data } as Order : o
        ),
        currentOrder: state.currentOrder?.id === orderId 
          ? { ...state.currentOrder, ...data } as Order 
          : state.currentOrder,
        isLoading: false
      }));
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update order status';
      set({ isLoading: false, error: message });
      return { success: false, error: message };
    }
  },

  confirmDelivery: async (orderId) => {
    set({ isLoading: true, error: null });
    try {
      const { data, error } = await orderService.confirmDelivery(orderId);
      
      if (error) {
        set({ isLoading: false, error: error.message });
        return { success: false, error: error.message };
      }

      set((state) => ({
        orders: state.orders.map((o) => 
          o.id === orderId ? { ...o, ...data } as Order : o
        ),
        currentOrder: state.currentOrder?.id === orderId 
          ? { ...state.currentOrder, ...data } as Order 
          : state.currentOrder,
        isLoading: false
      }));
      return { success: true };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to confirm delivery';
      set({ isLoading: false, error: message });
      return { success: false, error: message };
    }
  },

  clearError: () => set({ error: null }),
  reset: () => set({ orders: [], currentOrder: null, error: null }),
}));

export default useOrderStore;
