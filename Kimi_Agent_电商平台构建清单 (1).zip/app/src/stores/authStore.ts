import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authService, userService } from '@/services/supabase';
import type { User, StoreOwner } from '@/types';

interface AuthState {
  user: StoreOwner | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  setUser: (user: StoreOwner | null) => void;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (email: string, password: string, userData: Partial<User>) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  fetchProfile: () => Promise<void>;
  updateProfile: (updates: Partial<StoreOwner>) => Promise<{ success: boolean; error?: string }>;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      setUser: (user) => set({ user, isAuthenticated: !!user }),

      login: async (email, password) => {
        set({ isLoading: true, error: null });
        try {
          const { data, error } = await authService.signIn(email, password);
          
          if (error) {
            set({ isLoading: false, error: error.message });
            return { success: false, error: error.message };
          }

          if (data.user) {
            const { data: profile, error: profileError } = await userService.getProfile(data.user.id);
            
            if (profileError) {
              set({ isLoading: false, error: profileError.message });
              return { success: false, error: profileError.message };
            }

            set({ 
              user: profile as StoreOwner, 
              isAuthenticated: true, 
              isLoading: false 
            });
            return { success: true };
          }

          set({ isLoading: false });
          return { success: false, error: 'Login failed' };
        } catch (err) {
          const message = err instanceof Error ? err.message : 'Login failed';
          set({ isLoading: false, error: message });
          return { success: false, error: message };
        }
      },

      signup: async (email, password, userData) => {
        set({ isLoading: true, error: null });
        try {
          const { error } = await authService.signUp(email, password, userData);
          
          if (error) {
            set({ isLoading: false, error: error.message });
            return { success: false, error: error.message };
          }

          set({ isLoading: false });
          return { success: true };
        } catch (err) {
          const message = err instanceof Error ? err.message : 'Signup failed';
          set({ isLoading: false, error: message });
          return { success: false, error: message };
        }
      },

      logout: async () => {
        await authService.signOut();
        set({ user: null, isAuthenticated: false, error: null });
      },

      fetchProfile: async () => {
        const { user } = get();
        if (!user) return;

        try {
          const { data, error } = await userService.getProfile(user.id);
          if (data && !error) {
            set({ user: data as StoreOwner });
          }
        } catch (err) {
          console.error('Failed to fetch profile:', err);
        }
      },

      updateProfile: async (updates) => {
        const { user } = get();
        if (!user) return { success: false, error: 'Not authenticated' };

        try {
          const { data, error } = await userService.updateProfile(user.id, updates);
          
          if (error) {
            return { success: false, error: error.message };
          }

          set({ user: data as StoreOwner });
          return { success: true };
        } catch (err) {
          const message = err instanceof Error ? err.message : 'Update failed';
          return { success: false, error: message };
        }
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: 'qafrica-auth',
      partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);

export default useAuthStore;
