import { supabase } from './supabase';

// Email templates
export const emailTemplates = {
  welcome: (name: string) => ({
    subject: 'Welcome to QAFRICA!',
    body: `
      <h1>Welcome to QAFRICA, ${name}!</h1>
      <p>Thank you for joining Nigeria's premier e-commerce platform builder.</p>
      <p>With QAFRICA, you can:</p>
      <ul>
        <li>Create your own online store in minutes</li>
        <li>Sell products to customers across Nigeria</li>
        <li>Accept payments securely via Paystack</li>
        <li>Manage orders, inventory, and deliveries</li>
      </ul>
      <p>Get started by setting up your store today!</p>
      <a href="${window.location.origin}/dashboard" style="display: inline-block; padding: 12px 24px; background: #F97316; color: white; text-decoration: none; border-radius: 8px;">Go to Dashboard</a>
    `,
  }),

  orderConfirmation: (orderDetails: {
    orderId: string;
    customerName: string;
    storeName: string;
    items: Array<{ name: string; quantity: number; price: number }>;
    total: number;
    deliveryAddress: string;
  }) => ({
    subject: `Order Confirmation - #${orderDetails.orderId}`,
    body: `
      <h1>Thank you for your order, ${orderDetails.customerName}!</h1>
      <p>Your order from <strong>${orderDetails.storeName}</strong> has been received.</p>
      
      <h2>Order Details</h2>
      <p><strong>Order ID:</strong> #${orderDetails.orderId}</p>
      
      <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
        <thead>
          <tr style="background: #f5f5f5;">
            <th style="padding: 12px; text-align: left; border: 1px solid #ddd;">Item</th>
            <th style="padding: 12px; text-align: center; border: 1px solid #ddd;">Qty</th>
            <th style="padding: 12px; text-align: right; border: 1px solid #ddd;">Price</th>
          </tr>
        </thead>
        <tbody>
          ${orderDetails.items.map(item => `
            <tr>
              <td style="padding: 12px; border: 1px solid #ddd;">${item.name}</td>
              <td style="padding: 12px; text-align: center; border: 1px solid #ddd;">${item.quantity}</td>
              <td style="padding: 12px; text-align: right; border: 1px solid #ddd;">₦${item.price.toLocaleString()}</td>
            </tr>
          `).join('')}
        </tbody>
        <tfoot>
          <tr style="background: #f5f5f5; font-weight: bold;">
            <td colspan="2" style="padding: 12px; border: 1px solid #ddd;">Total</td>
            <td style="padding: 12px; text-align: right; border: 1px solid #ddd;">₦${orderDetails.total.toLocaleString()}</td>
          </tr>
        </tfoot>
      </table>
      
      <p><strong>Delivery Address:</strong><br>${orderDetails.deliveryAddress}</p>
      
      <p>We'll notify you when your order is shipped.</p>
    `,
  }),

  orderShipped: (orderDetails: {
    orderId: string;
    customerName: string;
    storeName: string;
    trackingNumber?: string;
  }) => ({
    subject: `Your Order Has Been Shipped - #${orderDetails.orderId}`,
    body: `
      <h1>Good news, ${orderDetails.customerName}!</h1>
      <p>Your order from <strong>${orderDetails.storeName}</strong> has been shipped.</p>
      
      <p><strong>Order ID:</strong> #${orderDetails.orderId}</p>
      ${orderDetails.trackingNumber ? `<p><strong>Tracking Number:</strong> ${orderDetails.trackingNumber}</p>` : ''}
      
      <p>You can expect delivery within 3-7 business days.</p>
      
      <p>Thank you for shopping with us!</p>
    `,
  }),

  orderDelivered: (orderDetails: {
    orderId: string;
    customerName: string;
    storeName: string;
  }) => ({
    subject: `Order Delivered - #${orderDetails.orderId}`,
    body: `
      <h1>Your order has been delivered!</h1>
      <p>Hi ${orderDetails.customerName},</p>
      <p>Your order from <strong>${orderDetails.storeName}</strong> (Order #${orderDetails.orderId}) has been delivered.</p>
      
      <p>We hope you love your purchase! If you have any issues, please contact the seller directly.</p>
      
      <p>Enjoy your items!</p>
    `,
  }),

  newOrder: (orderDetails: {
    orderId: string;
    storeName: string;
    customerName: string;
    items: Array<{ name: string; quantity: number; price: number }>;
    total: number;
  }) => ({
    subject: `New Order Received - #${orderDetails.orderId}`,
    body: `
      <h1>New Order Alert!</h1>
      <p>You've received a new order for your store <strong>${orderDetails.storeName}</strong>.</p>
      
      <p><strong>Order ID:</strong> #${orderDetails.orderId}</p>
      <p><strong>Customer:</strong> ${orderDetails.customerName}</p>
      
      <h2>Items Ordered</h2>
      <ul>
        ${orderDetails.items.map(item => `
          <li>${item.name} x ${item.quantity} - ₦${item.price.toLocaleString()}</li>
        `).join('')}
      </ul>
      
      <p><strong>Total:</strong> ₦${orderDetails.total.toLocaleString()}</p>
      
      <a href="${window.location.origin}/dashboard/orders" style="display: inline-block; padding: 12px 24px; background: #F97316; color: white; text-decoration: none; border-radius: 8px;">View Order</a>
    `,
  }),

  lowStock: (productDetails: {
    productName: string;
    currentStock: number;
    threshold: number;
    storeName: string;
  }) => ({
    subject: `Low Stock Alert - ${productDetails.productName}`,
    body: `
      <h1>Low Stock Alert</h1>
      <p>The following product is running low on stock:</p>
      
      <p><strong>Product:</strong> ${productDetails.productName}</p>
      <p><strong>Store:</strong> ${productDetails.storeName}</p>
      <p><strong>Current Stock:</strong> ${productDetails.currentStock}</p>
      <p><strong>Threshold:</strong> ${productDetails.threshold}</p>
      
      <a href="${window.location.origin}/dashboard/products" style="display: inline-block; padding: 12px 24px; background: #F97316; color: white; text-decoration: none; border-radius: 8px;">Restock Now</a>
    `,
  }),

  passwordReset: (resetUrl: string) => ({
    subject: 'Password Reset Request',
    body: `
      <h1>Password Reset</h1>
      <p>You requested a password reset for your QAFRICA account.</p>
      <p>Click the button below to reset your password:</p>
      
      <a href="${resetUrl}" style="display: inline-block; padding: 12px 24px; background: #F97316; color: white; text-decoration: none; border-radius: 8px;">Reset Password</a>
      
      <p style="margin-top: 20px; color: #666;">If you didn't request this, you can safely ignore this email.</p>
      <p style="color: #666;">This link will expire in 1 hour.</p>
    `,
  }),

  subscriptionExpiring: (details: {
    storeName: string;
    expiryDate: string;
  }) => ({
    subject: 'Your Subscription is Expiring Soon',
    body: `
      <h1>Subscription Expiring Soon</h1>
      <p>Your store <strong>${details.storeName}</strong> subscription will expire on <strong>${details.expiryDate}</strong>.</p>
      
      <p>Renew now to keep your store active and avoid any interruption to your business.</p>
      
      <a href="${window.location.origin}/dashboard/subscription" style="display: inline-block; padding: 12px 24px; background: #F97316; color: white; text-decoration: none; border-radius: 8px;">Renew Subscription</a>
    `,
  }),
};

// Send email using Supabase Edge Function (when implemented)
// For now, we'll use a mock implementation
export const sendEmail = async ({
  to,
  subject,
  html,
}: {
  to: string;
  subject: string;
  html: string;
}): Promise<{ success: boolean; error?: string }> => {
  try {
    // In production, this would call a Supabase Edge Function
    // that uses a service like SendGrid, Mailgun, or AWS SES
    
    // For now, log the email (in development)
    if (import.meta.env.DEV) {
      console.log('Email would be sent:', { to, subject, html });
    }
    
    // Call Supabase Edge Function when available
    const { error } = await supabase.functions.invoke('send-email', {
      body: { to, subject, html },
    });
    
    if (error) {
      console.error('Email send error:', error);
      // Don't fail the operation if email fails
      return { success: true };
    }
    
    return { success: true };
  } catch (err) {
    console.error('Email send error:', err);
    // Don't fail the operation if email fails
    return { success: true };
  }
};

// Send welcome email
export const sendWelcomeEmail = async (email: string, name: string) => {
  const template = emailTemplates.welcome(name);
  return sendEmail({ to: email, subject: template.subject, html: template.body });
};

// Send order confirmation to customer
export const sendOrderConfirmationEmail = async (email: string, orderDetails: Parameters<typeof emailTemplates.orderConfirmation>[0]) => {
  const template = emailTemplates.orderConfirmation(orderDetails);
  return sendEmail({ to: email, subject: template.subject, html: template.body });
};

// Send order shipped notification
export const sendOrderShippedEmail = async (email: string, orderDetails: Parameters<typeof emailTemplates.orderShipped>[0]) => {
  const template = emailTemplates.orderShipped(orderDetails);
  return sendEmail({ to: email, subject: template.subject, html: template.body });
};

// Send order delivered notification
export const sendOrderDeliveredEmail = async (email: string, orderDetails: Parameters<typeof emailTemplates.orderDelivered>[0]) => {
  const template = emailTemplates.orderDelivered(orderDetails);
  return sendEmail({ to: email, subject: template.subject, html: template.body });
};

// Send new order notification to seller
export const sendNewOrderEmail = async (email: string, orderDetails: Parameters<typeof emailTemplates.newOrder>[0]) => {
  const template = emailTemplates.newOrder(orderDetails);
  return sendEmail({ to: email, subject: template.subject, html: template.body });
};

// Send low stock alert
export const sendLowStockEmail = async (email: string, productDetails: Parameters<typeof emailTemplates.lowStock>[0]) => {
  const template = emailTemplates.lowStock(productDetails);
  return sendEmail({ to: email, subject: template.subject, html: template.body });
};

// Send password reset email
export const sendPasswordResetEmail = async (email: string, resetUrl: string) => {
  const template = emailTemplates.passwordReset(resetUrl);
  return sendEmail({ to: email, subject: template.subject, html: template.body });
};

// Send subscription expiring notification
export const sendSubscriptionExpiringEmail = async (email: string, details: Parameters<typeof emailTemplates.subscriptionExpiring>[0]) => {
  const template = emailTemplates.subscriptionExpiring(details);
  return sendEmail({ to: email, subject: template.subject, html: template.body });
};
