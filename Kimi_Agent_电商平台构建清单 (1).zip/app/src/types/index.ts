// QAFRICA TypeScript Types

// User Types
export interface User {
  id: string;
  email: string;
  full_name: string;
  phone: string;
  avatar_url?: string;
  role: 'user' | 'admin';
  email_verified: boolean;
  created_at: string;
  updated_at: string;
  last_sign_in?: string;
}

export interface StoreOwner extends User {
  store_id?: string;
  subscription_tier: 'single' | 'three' | 'unlimited' | null;
  subscription_expires_at?: string;
  selected_niches: string[];
  wallet_balance: number;
  total_earnings: number;
  is_store_active: boolean;
  is_store_blocked: boolean;
  block_reason?: string;
}

// Store Types
export interface Store {
  id: string;
  owner_id: string;
  name: string;
  slug: string;
  description: string;
  logo_url?: string;
  banner_url?: string;
  primary_color: string;
  secondary_color: string;
  niches: string[];
  theme: string;
  is_active: boolean;
  is_verified: boolean;
  is_blocked?: boolean;
  block_reason?: string;
  custom_domain?: string;
  domain_status?: 'none' | 'pending' | 'processing' | 'connected' | 'failed';
  domain_paid_amount?: number;
  created_at: string;
  updated_at: string;
  social_links: {
    instagram?: string;
    facebook?: string;
    twitter?: string;
    tiktok?: string;
    whatsapp?: string;
  };
  analytics: StoreAnalytics;
}

export interface StoreAnalytics {
  total_visits: number;
  total_orders: number;
  total_revenue: number;
  conversion_rate: number;
  best_selling_products: string[];
  traffic_sources: {
    direct: number;
    social: number;
    search: number;
    ads: number;
  };
  monthly_growth: number;
}

// Product Types
export interface Product {
  id: string;
  store_id: string;
  owner_id: string;
  name: string;
  description: string;
  images: string[];
  category: string;
  niche: string;
  subcategory?: string;
  
  // Pricing
  cost_price: number;
  selling_price: number;
  dropship_price: number;
  wholesale_price: number;
  
  // Inventory
  stock_quantity: number;
  low_stock_threshold: number;
  sku?: string;
  barcode?: string;
  is_out_of_stock: boolean;
  
  // Variants
  has_variants: boolean;
  variants?: ProductVariant[];
  
  // Shipping
  weight?: number;
  dimensions?: {
    length: number;
    width: number;
    height: number;
  };
  
  // Status
  is_active: boolean;
  is_importable: boolean;
  import_count: number;
  
  // SEO
  seo_title?: string;
  seo_description?: string;
  tags: string[];
  
  // Analytics
  views: number;
  sales_count: number;
  
  created_at: string;
  updated_at: string;
}

export interface ProductVariant {
  id: string;
  name: string;
  options: string[];
  price_adjustment: number;
  stock_quantity: number;
  sku?: string;
}

// Import Catalog Types
export interface ImportCatalogItem {
  id: string;
  original_product_id: string;
  original_store_id: string;
  original_owner_id: string;
  importer_store_id: string;
  importer_owner_id: string;
  
  // Imported product details (copied from original)
  name: string;
  description: string;
  images: string[];
  category: string;
  niche: string;
  selling_price: number;
  dropship_price: number;
  
  // Custom pricing for importer
  custom_selling_price?: number;
  
  // Status
  is_active: boolean;
  total_sales: number;
  
  created_at: string;
}

// Order Types
export interface Order {
  id: string;
  order_number: string;
  store_id: string;
  customer_id?: string;
  
  // Customer Info
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  
  // Items
  items: OrderItem[];
  
  // Pricing
  subtotal: number;
  delivery_fee: number;
  platform_fee: number;
  total: number;
  
  // Delivery
  delivery_address: DeliveryAddress;
  delivery_state: string;
  
  // Payment
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  payment_method: 'paystack' | 'wallet';
  payment_reference?: string;
  paid_at?: string;
  
  // Order Status
  status: OrderStatus;
  
  // Escrow
  escrow_release_at?: string;
  is_escrow_released: boolean;
  
  // Tracking
  tracking_number?: string;
  
  // Timestamps
  created_at: string;
  updated_at: string;
  delivered_at?: string;
}

export type OrderStatus = 
  | 'pending' 
  | 'confirmed' 
  | 'processing' 
  | 'shipped' 
  | 'delivered' 
  | 'cancelled' 
  | 'returned';

export interface OrderItem {
  id: string;
  product_id: string;
  product_name: string;
  product_image: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  
  // For imported products
  is_imported: boolean;
  original_product_id?: string;
  original_store_id?: string;
  dropship_price?: number;
}

export interface DeliveryAddress {
  street: string;
  city: string;
  state: string;
  country: string;
  postal_code?: string;
}

// Wallet Types
export interface Wallet {
  id: string;
  user_id: string;
  balance: number;
  total_earned: number;
  total_withdrawn: number;
  pending_balance: number;
  created_at: string;
  updated_at: string;
}

export interface WalletTransaction {
  id: string;
  wallet_id: string;
  user_id: string;
  type: 'credit' | 'debit';
  amount: number;
  balance_after: number;
  description: string;
  reference?: string;
  status: 'pending' | 'completed' | 'failed';
  metadata?: Record<string, any>;
  created_at: string;
}

export interface WithdrawalRequest {
  id: string;
  user_id: string;
  wallet_id: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected' | 'paid';
  bank_name: string;
  account_number: string;
  account_name: string;
  admin_note?: string;
  paid_at?: string;
  paid_by?: string;
  created_at: string;
}

// Subscription Types
export interface Subscription {
  id: string;
  user_id: string;
  store_id?: string;
  tier: 'single' | 'three' | 'unlimited';
  niches: string[];
  duration_months: number;
  amount_paid: number;
  is_trial?: boolean;
  starts_at: string;
  expires_at: string;
  is_active: boolean;
  auto_renew?: boolean;
  payment_reference: string;
  created_at: string;
}

// Delivery Types
export interface DeliveryZone {
  id: string;
  store_id: string;
  state: string;
  price: number;
  is_active: boolean;
  created_at: string;
}

// Ad Campaign Types
export interface AdCampaign {
  id: string;
  store_id: string;
  product_id?: string;
  platform: 'google' | 'facebook' | 'instagram' | 'tiktok';
  campaign_name: string;
  budget: number;
  spent: number;
  clicks: number;
  impressions: number;
  conversions: number;
  status: 'active' | 'paused' | 'ended';
  start_date: string;
  end_date?: string;
  external_campaign_id?: string;
  created_at: string;
}

// Notification Types
export interface Notification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, any>;
  is_read: boolean;
  created_at: string;
}

export type NotificationType = 
  | 'order_placed'
  | 'order_confirmed'
  | 'order_shipped'
  | 'order_delivered'
  | 'payment_received'
  | 'wallet_credited'
  | 'withdrawal_approved'
  | 'product_imported'
  | 'subscription_expiring'
  | 'store_blocked'
  | 'escrow_released'
  | 'low_stock'
  | 'out_of_stock';

// Product Earnings Types
export interface ProductEarning {
  id: string;
  product_id: string;
  store_id: string;
  owner_id: string;
  order_id?: string;
  quantity_sold: number;
  unit_cost: number;
  unit_price: number;
  total_revenue: number;
  total_cost: number;
  profit: number;
  platform_fee: number;
  net_profit: number;
  earned_at: string;
  created_at: string;
}

export interface ProductEarningsSummary {
  product_id: string;
  product_name: string;
  total_quantity_sold: number;
  total_revenue: number;
  total_cost: number;
  total_profit: number;
  total_net_profit: number;
}

// Stock Alert Types
export interface StockAlert {
  id: string;
  product_id: string;
  store_id: string;
  owner_id: string;
  alert_type: 'low_stock' | 'out_of_stock' | 'restocked';
  previous_stock: number;
  current_stock: number;
  threshold: number;
  is_read: boolean;
  read_at?: string;
  created_at: string;
  product?: Product; // Joined data
}

// Email Types
export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  html_content: string;
  variables: string[];
}

// Admin Types
export interface AdminDashboardStats {
  total_users: number;
  total_stores: number;
  total_products: number;
  total_orders: number;
  total_revenue: number;
  pending_withdrawals: number;
  pending_verifications: number;
  blocked_stores: number;
}

export interface AdminAction {
  id: string;
  admin_id: string;
  action_type: string;
  target_type: 'user' | 'store' | 'product' | 'order';
  target_id: string;
  details: string;
  created_at: string;
}

// Tax Types
export interface TaxSettings {
  id: string;
  store_id: string;
  owner_id: string;
  tax_rate: number;
  tax_name: string;
  tax_id_number?: string;
  country: string;
  state?: string;
  is_tax_enabled: boolean;
  created_at: string;
  updated_at: string;
}

export interface BusinessExpense {
  id: string;
  store_id: string;
  owner_id: string;
  expense_name: string;
  expense_category: string;
  amount: number;
  expense_date: string;
  description?: string;
  receipt_url?: string;
  is_recurring: boolean;
  recurring_frequency?: 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  created_at: string;
  updated_at: string;
}

export interface TaxReport {
  id: string;
  store_id: string;
  owner_id: string;
  report_name: string;
  report_period_start: string;
  report_period_end: string;
  total_revenue: number;
  total_expenses: number;
  taxable_income: number;
  tax_rate: number;
  tax_amount: number;
  deductions: number;
  net_tax_payable: number;
  report_data: Record<string, any>;
  file_url?: string;
  file_format?: 'pdf' | 'csv' | 'excel';
  created_at: string;
}

export interface TaxCalculation {
  total_revenue: number;
  total_expenses: number;
  taxable_income: number;
  tax_rate: number;
  tax_amount: number;
  net_after_tax: number;
}

export interface ExpenseCategorySummary {
  category: string;
  total_amount: number;
  expense_count: number;
}

// Expense categories
export const EXPENSE_CATEGORIES = [
  'Advertising & Marketing',
  'Office Supplies',
  'Rent',
  'Utilities',
  'Transportation',
  'Professional Services',
  'Equipment',
  'Software & Subscriptions',
  'Shipping & Delivery',
  'Employee Salaries',
  'Insurance',
  'Maintenance & Repairs',
  'Travel',
  'Meals & Entertainment',
  'Other',
] as const;

// Theme Types
export interface Theme {
  id: string;
  name: string;
  description: string;
  preview_image: string;
  is_premium: boolean;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
  };
  fonts: {
    heading: string;
    body: string;
  };
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Form Types
export interface SignupFormData {
  full_name: string;
  email: string;
  phone: string;
  password: string;
  confirm_password: string;
  selected_niche: string;
}

export interface ProductFormData {
  name: string;
  description: string;
  category: string;
  cost_price: number;
  selling_price: number;
  dropship_price: number;
  wholesale_price: number;
  stock_quantity: number;
  images: File[];
  has_variants: boolean;
  variants?: ProductVariant[];
  is_importable: boolean;
}

export interface StoreSetupFormData {
  name: string;
  description: string;
  slug: string;
  theme: string;
  primary_color: string;
  secondary_color: string;
}

// Review Types
export interface Review {
  id: string;
  product_id: string;
  store_id: string;
  customer_id?: string;
  customer_name: string;
  customer_email?: string;
  rating: number;
  title?: string;
  content: string;
  images?: string[];
  is_verified_purchase: boolean;
  is_approved: boolean;
  helpful_count: number;
  unhelpful_count: number;
  admin_response?: string;
  admin_responded_at?: string;
  created_at: string;
  updated_at: string;
  // Joined data
  product?: {
    name: string;
    images: string[];
  };
}

export interface ReviewSummary {
  product_id: string;
  average_rating: number;
  total_reviews: number;
  five_star: number;
  four_star: number;
  three_star: number;
  two_star: number;
  one_star: number;
}

// Coupon Types
export interface Coupon {
  id: string;
  store_id: string;
  code: string;
  description?: string;
  discount_type: 'percentage' | 'fixed';
  discount_value: number;
  min_order_amount?: number;
  max_discount_amount?: number;
  usage_limit?: number;
  usage_count: number;
  start_date?: string;
  end_date?: string;
  is_active: boolean;
  applies_to: 'all' | 'products' | 'categories';
  product_ids?: string[];
  category_ids?: string[];
  created_at: string;
  updated_at: string;
}

// ============================================
// CUSTOMER TYPES (For Shoppers)
// ============================================

export interface Customer {
  id: string;
  email: string;
  full_name: string;
  phone?: string;
  avatar_url?: string;
  is_verified: boolean;
  created_at: string;
  updated_at: string;
  last_sign_in?: string;
}

export interface CustomerAddress {
  id: string;
  customer_id: string;
  label: string; // e.g., "Home", "Office"
  street: string;
  city: string;
  state: string;
  country: string;
  postal_code?: string;
  is_default: boolean;
  created_at: string;
}

// Universal Cart Item - works across all stores
export interface CartItem {
  id: string; // unique cart item id
  product_id: string;
  store_id: string;
  store_name: string;
  store_slug: string;
  product_name: string;
  product_image?: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  added_at: string;
}

// Customer Order (aggregates orders from multiple stores)
export interface CustomerOrder {
  id: string;
  customer_id: string;
  order_group_id: string; // groups orders from same checkout
  store_id: string;
  store_name: string;
  order_number: string;
  
  // Items
  items: CustomerOrderItem[];
  
  // Pricing
  subtotal: number;
  delivery_fee: number;
  platform_fee: number;
  total: number;
  
  // Delivery
  delivery_address: CustomerAddress;
  
  // Payment
  payment_status: 'pending' | 'paid' | 'failed' | 'refunded';
  payment_method: 'paystack' | 'wallet';
  paid_at?: string;
  
  // Status
  status: OrderStatus;
  
  // Tracking
  tracking_number?: string;
  
  // Timestamps
  created_at: string;
  updated_at: string;
  delivered_at?: string;
}

export interface CustomerOrderItem {
  id: string;
  product_id: string;
  product_name: string;
  product_image?: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

// Customer Wishlist (universal across stores)
export interface WishlistItem {
  id: string;
  customer_id: string;
  product_id: string;
  store_id: string;
  store_name: string;
  store_slug: string;
  product_name: string;
  product_image?: string;
  price: number;
  added_at: string;
}

// Recently Viewed Product
export interface RecentlyViewed {
  id: string;
  customer_id: string;
  product_id: string;
  store_id: string;
  store_name: string;
  store_slug: string;
  product_name: string;
  product_image?: string;
  price: number;
  viewed_at: string;
}
