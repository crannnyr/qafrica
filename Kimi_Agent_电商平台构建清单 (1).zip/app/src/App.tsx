import { Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';
import { Toaster } from '@/components/ui/sonner';
import { useAuthStore } from '@/stores';

// Pages
import LandingPage from '@/pages/landing/LandingPage';
import LoginPage from '@/pages/auth/LoginPage';
import SignupPage from '@/pages/auth/SignupPage';
import VerifyEmailPage from '@/pages/auth/VerifyEmailPage';
import ForgotPasswordPage from '@/pages/auth/ForgotPasswordPage';
import ResetPasswordPage from '@/pages/auth/ResetPasswordPage';
import NicheSelectionPage from '@/pages/auth/NicheSelectionPage';
import PricingPage from '@/pages/auth/PricingPage';
import PaymentCallbackPage from '@/pages/auth/PaymentCallbackPage';

// Dashboard Pages
import DashboardLayout from '@/pages/dashboard/DashboardLayout';
import DashboardHome from '@/pages/dashboard/DashboardHome';
import StoreSetup from '@/pages/dashboard/StoreSetup';
import ProductsPage from '@/pages/dashboard/ProductsPage';
import AddProductPage from '@/pages/dashboard/AddProductPage';
import ImportCatalogPage from '@/pages/dashboard/ImportCatalogPage';
import OrdersPage from '@/pages/dashboard/OrdersPage';
import OrderManagementPage from '@/pages/dashboard/OrderManagementPage';
import WalletPage from '@/pages/dashboard/WalletPage';
import DeliveryZonesPage from '@/pages/dashboard/DeliveryZonesPage';
import DomainPage from '@/pages/dashboard/DomainPage';
import AnalyticsPage from '@/pages/dashboard/AnalyticsPage';
import TaxExpensesPage from '@/pages/dashboard/TaxExpensesPage';
import StoreSettingsPage from '@/pages/dashboard/StoreSettingsPage';
import SubscriptionPage from '@/pages/dashboard/SubscriptionPage';
import HowToUsePage from '@/pages/dashboard/HowToUsePage';
import ReviewsPage from '@/pages/dashboard/ReviewsPage';
import BulkImportPage from '@/pages/dashboard/BulkImportPage';
import CouponsPage from '@/pages/dashboard/CouponsPage';
import StoreTemplatesPage from '@/pages/dashboard/StoreTemplatesPage';
import NicheCustomizationPage from '@/pages/dashboard/NicheCustomizationPage';

// Store Pages
import StorePage from '@/pages/store/StorePage';
import ProductDetailPage from '@/pages/store/ProductDetailPage';
import CheckoutPage from '@/pages/store/CheckoutPage';
import StoreClosedPage from '@/pages/store/StoreClosedPage';
import StoreNotFoundPage from '@/pages/store/StoreNotFoundPage';

// Customer Pages
import CustomerLoginPage from '@/pages/customer/CustomerLoginPage';
import CustomerSignupPage from '@/pages/customer/CustomerSignupPage';
import CustomerDashboard from '@/pages/customer/CustomerDashboard';
import StoreDiscoveryPage from '@/pages/customer/StoreDiscoveryPage';
import UniversalCartPage from '@/pages/customer/UniversalCartPage';

// Admin Pages
import AdminLayout from '@/pages/admin/AdminLayout';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminUsers from '@/pages/admin/AdminUsers';
import AdminStores from '@/pages/admin/AdminStores';
import AdminProducts from '@/pages/admin/AdminProducts';
import AdminOrders from '@/pages/admin/AdminOrders';
import AdminWithdrawals from '@/pages/admin/AdminWithdrawals';
import AdminSubscriptions from '@/pages/admin/AdminSubscriptions';

// Protected Route Component
const ProtectedRoute = ({ children, requireAdmin = false }: { children: React.ReactNode; requireAdmin?: boolean }) => {
  const { isAuthenticated, user } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  if (requireAdmin && user?.role !== 'admin') {
    return <Navigate to="/dashboard" replace />;
  }
  
  return <>{children}</>;
};

// Public Route Component (redirects to dashboard if authenticated)
const PublicRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, user } = useAuthStore();
  
  if (isAuthenticated) {
    if (user?.role === 'admin') {
      return <Navigate to="/admin" replace />;
    }
    return <Navigate to="/dashboard" replace />;
  }
  
  return <>{children}</>;
};

function App() {
  const { fetchProfile } = useAuthStore();

  useEffect(() => {
    // Check for existing session on app load
    fetchProfile();
  }, [fetchProfile]);

  return (
    <>
      <Toaster 
        position="top-right" 
        richColors 
        closeButton
        toastOptions={{
          style: {
            fontFamily: 'Inter, system-ui, sans-serif',
          },
        }}
      />
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
        <Route path="/signup" element={<PublicRoute><SignupPage /></PublicRoute>} />
        <Route path="/verify-email" element={<PublicRoute><VerifyEmailPage /></PublicRoute>} />
        <Route path="/forgot-password" element={<PublicRoute><ForgotPasswordPage /></PublicRoute>} />
        <Route path="/reset-password" element={<PublicRoute><ResetPasswordPage /></PublicRoute>} />
        <Route path="/select-niche" element={<PublicRoute><NicheSelectionPage /></PublicRoute>} />
        <Route path="/pricing" element={<PublicRoute><PricingPage /></PublicRoute>} />
        <Route path="/payment/callback" element={<PaymentCallbackPage />} />

        {/* Customer Routes */}
        <Route path="/customer/login" element={<CustomerLoginPage />} />
        <Route path="/customer/signup" element={<CustomerSignupPage />} />
        <Route path="/customer/dashboard" element={<CustomerDashboard />} />
        <Route path="/stores" element={<StoreDiscoveryPage />} />
        <Route path="/cart" element={<UniversalCartPage />} />

        {/* Dashboard Routes */}
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }>
          <Route index element={<DashboardHome />} />
          <Route path="store-setup" element={<StoreSetup />} />
          <Route path="products" element={<ProductsPage />} />
          <Route path="products/add" element={<AddProductPage />} />
          <Route path="products/bulk-import" element={<BulkImportPage />} />
          <Route path="import-catalog" element={<ImportCatalogPage />} />
          <Route path="orders" element={<OrdersPage />} />
          <Route path="order-management" element={<OrderManagementPage />} />
          <Route path="reviews" element={<ReviewsPage />} />
          <Route path="coupons" element={<CouponsPage />} />
          <Route path="wallet" element={<WalletPage />} />
          <Route path="delivery-zones" element={<DeliveryZonesPage />} />
          <Route path="domain" element={<DomainPage />} />
          <Route path="analytics" element={<AnalyticsPage />} />
          <Route path="tax-expenses" element={<TaxExpensesPage />} />
          <Route path="settings" element={<StoreSettingsPage />} />
          <Route path="templates" element={<StoreTemplatesPage />} />
          <Route path="subscription" element={<SubscriptionPage />} />
          <Route path="niches" element={<NicheCustomizationPage />} />
          <Route path="how-to-use" element={<HowToUsePage />} />
        </Route>

        {/* Admin Routes */}
        <Route path="/admin" element={
          <ProtectedRoute requireAdmin={true}>
            <AdminLayout />
          </ProtectedRoute>
        }>
          <Route index element={<AdminDashboard />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="stores" element={<AdminStores />} />
          <Route path="products" element={<AdminProducts />} />
          <Route path="orders" element={<AdminOrders />} />
          <Route path="withdrawals" element={<AdminWithdrawals />} />
          <Route path="subscriptions" element={<AdminSubscriptions />} />
        </Route>

        {/* Store Routes - Public store pages */}
        <Route path="/my-site/:slug" element={<StorePage />} />
        <Route path="/my-site/:slug/product/:productId" element={<ProductDetailPage />} />
        <Route path="/my-site/:slug/checkout" element={<CheckoutPage />} />
        
        {/* Store Status Pages */}
        <Route path="/store-closed" element={<StoreClosedPage />} />
        <Route path="/store-not-found" element={<StoreNotFoundPage />} />

        {/* Catch all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}

export default App;
