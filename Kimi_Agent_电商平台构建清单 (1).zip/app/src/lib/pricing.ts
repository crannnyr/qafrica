// QuickSell Africa - Subscription Pricing Configuration

export interface PricingTier {
  id: string;
  name: string;
  description: string;
  basePrice: number; // Monthly price in Naira
  nichesAllowed: number | typeof Infinity;
  features: string[];
  notIncluded: string[];
  popular?: boolean;
}

export interface DurationPlan {
  months: number;
  discount: number; // Percentage discount
  label: string;
}

export interface SubscriptionPlan {
  tier: PricingTier;
  duration: DurationPlan;
  totalPrice: number;
  discountedPrice: number;
  savings: number;
}

// Base pricing tiers
export const PRICING_TIERS: PricingTier[] = [
  {
    id: 'single',
    name: 'Single Store',
    description: 'Perfect for beginners starting with one niche',
    basePrice: 5000,
    nichesAllowed: 1,
    features: [
      '1 niche selection',
      'Unlimited products',
      'Basic analytics',
      'Standard support',
      'Custom store URL',
      'Mobile-friendly store'
    ],
    notIncluded: [
      'Multiple niches',
      'Priority support',
      'Advanced analytics'
    ]
  },
  {
    id: 'three',
    name: 'Three Stores',
    description: 'Ideal for growing businesses with multiple niches',
    basePrice: 10000,
    nichesAllowed: 3,
    features: [
      '3 niche selections',
      'Unlimited products',
      'Advanced analytics',
      'Priority support',
      'Custom store URL',
      'Mobile-friendly store',
      'Product import feature',
      'Coupon system'
    ],
    notIncluded: [
      'Unlimited niches'
    ],
    popular: true
  },
  {
    id: 'unlimited',
    name: 'Unlimited Stores',
    description: 'For established sellers who want it all',
    basePrice: 100000,
    nichesAllowed: Infinity,
    features: [
      'Unlimited niches',
      'Unlimited products',
      'Premium analytics',
      'VIP support',
      'Custom store URL',
      'Mobile-friendly store',
      'Product import feature',
      'Coupon system',
      'Priority withdrawals',
      'Dedicated account manager'
    ],
    notIncluded: []
  }
];

// Duration plans with discounts
export const DURATION_PLANS: DurationPlan[] = [
  { months: 1, discount: 0, label: '1 Month' },
  { months: 3, discount: 0, label: '3 Months' },
  { months: 6, discount: 5, label: '6 Months (5% off)' },
  { months: 12, discount: 10, label: '1 Year (10% off)' }
];

// Lifetime pricing (one-time payment)
export const LIFETIME_PRICING: Record<string, number> = {
  'single': 2000000,    // ₦2,000,000
  'three': 3800000,     // ₦3,800,000
  'unlimited': 8000000  // ₦8,000,000
};

// Calculate subscription price
export const calculateSubscriptionPrice = (
  tierId: string,
  durationMonths: number
): { originalPrice: number; discountedPrice: number; savings: number; discountPercent: number } => {
  const tier = PRICING_TIERS.find(t => t.id === tierId);
  if (!tier) {
    return { originalPrice: 0, discountedPrice: 0, savings: 0, discountPercent: 0 };
  }

  const durationPlan = DURATION_PLANS.find(d => d.months === durationMonths);
  const discountPercent = durationPlan?.discount || 0;

  const originalPrice = tier.basePrice * durationMonths;
  const discountAmount = (originalPrice * discountPercent) / 100;
  const discountedPrice = originalPrice - discountAmount;
  const savings = discountAmount;

  return {
    originalPrice,
    discountedPrice,
    savings,
    discountPercent
  };
};

// Get lifetime price for a tier
export const getLifetimePrice = (tierId: string): number => {
  return LIFETIME_PRICING[tierId] || 0;
};

// Format price for display
export const formatPrice = (price: number): string => {
  return `₦${price.toLocaleString()}`;
};

// Get tier by ID
export const getTierById = (tierId: string): PricingTier | null => {
  return PRICING_TIERS.find(t => t.id === tierId) || null;
};

// Check if tier upgrade is allowed
export const canUpgradeTier = (currentTierId: string, newTierId: string): boolean => {
  const tierOrder = ['single', 'three', 'unlimited'];
  const currentIndex = tierOrder.indexOf(currentTierId);
  const newIndex = tierOrder.indexOf(newTierId);
  
  return newIndex > currentIndex;
};

// Check if tier downgrade is allowed
export const canDowngradeTier = (currentTierId: string, newTierId: string): boolean => {
  const tierOrder = ['single', 'three', 'unlimited'];
  const currentIndex = tierOrder.indexOf(currentTierId);
  const newIndex = tierOrder.indexOf(newTierId);
  
  return newIndex < currentIndex;
};

// Get upgrade/downgrade info
export const getTierChangeInfo = (
  currentTierId: string,
  newTierId: string
): { 
  type: 'upgrade' | 'downgrade' | 'same';
  allowed: boolean;
  message: string;
  nichesToRemove?: number;
} => {
  if (currentTierId === newTierId) {
    return { type: 'same', allowed: false, message: 'You are already on this plan' };
  }

  const currentTier = getTierById(currentTierId);
  const newTier = getTierById(newTierId);

  if (!currentTier || !newTier) {
    return { type: 'same', allowed: false, message: 'Invalid tier selection' };
  }

  if (canUpgradeTier(currentTierId, newTierId)) {
    return {
      type: 'upgrade',
      allowed: true,
      message: `Upgrade to ${newTier.name} and get more features!`
    };
  }

  // Downgrade - check if niches need to be removed
  const nichesToRemove = Math.max(0, currentTier.nichesAllowed - newTier.nichesAllowed);
  
  return {
    type: 'downgrade',
    allowed: true,
    message: nichesToRemove > 0 
      ? `Downgrade to ${newTier.name}. You will need to remove ${nichesToRemove} niche(s).`
      : `Downgrade to ${newTier.name}.`,
    nichesToRemove
  };
};

// Get all available plans with pricing
export const getAllPlans = (): SubscriptionPlan[] => {
  const plans: SubscriptionPlan[] = [];

  PRICING_TIERS.forEach(tier => {
    DURATION_PLANS.forEach(duration => {
      const { originalPrice, discountedPrice, savings } = calculateSubscriptionPrice(
        tier.id,
        duration.months
      );

      plans.push({
        tier,
        duration,
        totalPrice: originalPrice,
        discountedPrice,
        savings
      });
    });
  });

  return plans;
};

// Get recommended plan (3 months on Three Stores)
export const getRecommendedPlan = (): SubscriptionPlan => {
  const tier = PRICING_TIERS.find(t => t.id === 'three')!;
  const duration = DURATION_PLANS.find(d => d.months === 3)!;
  const { originalPrice, discountedPrice, savings } = calculateSubscriptionPrice('three', 3);

  return {
    tier,
    duration,
    totalPrice: originalPrice,
    discountedPrice,
    savings
  };
};
