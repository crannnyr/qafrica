import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, X, Loader2, Image as ImageIcon } from 'lucide-react';
import { storageService } from '@/services/supabase';
import { toast } from 'sonner';

interface ImageUploadProps {
  bucket: string;
  folder?: string;
  value?: string | string[];
  onChange: (urls: string | string[]) => void;
  multiple?: boolean;
  maxFiles?: number;
  maxSizeMB?: number;
  className?: string;
  aspectRatio?: 'square' | 'landscape' | 'portrait' | 'auto';
}

export default function ImageUpload({
  bucket,
  folder = '',
  value,
  onChange,
  multiple = false,
  maxFiles = 5,
  maxSizeMB = 5,
  className = '',
  aspectRatio = 'auto',
}: ImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentImages = multiple 
    ? (value as string[] || []) 
    : (value ? [value as string] : []);

  const aspectRatioClass = {
    square: 'aspect-square',
    landscape: 'aspect-video',
    portrait: 'aspect-[3/4]',
    auto: 'aspect-auto',
  }[aspectRatio];

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    // Validate file count
    if (multiple && currentImages.length + files.length > maxFiles) {
      toast.error(`Maximum ${maxFiles} images allowed`);
      return;
    }

    // Validate file size
    const oversizedFiles = Array.from(files).filter(f => f.size > maxSizeMB * 1024 * 1024);
    if (oversizedFiles.length > 0) {
      toast.error(`Some files exceed ${maxSizeMB}MB limit`);
      return;
    }

    // Validate file type
    const invalidFiles = Array.from(files).filter(f => !f.type.startsWith('image/'));
    if (invalidFiles.length > 0) {
      toast.error('Only image files are allowed');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const filesToUpload = Array.from(files);
      const uploadedUrls: string[] = [];

      for (let i = 0; i < filesToUpload.length; i++) {
        const file = filesToUpload[i];
        const { url, error } = await storageService.uploadImage(bucket, file, folder);
        
        if (error) {
          toast.error(`Failed to upload ${file.name}`);
          continue;
        }
        
        if (url) {
          uploadedUrls.push(url);
        }
        
        setUploadProgress(((i + 1) / filesToUpload.length) * 100);
      }

      if (uploadedUrls.length > 0) {
        if (multiple) {
          onChange([...currentImages, ...uploadedUrls]);
        } else {
          onChange(uploadedUrls[0]);
        }
        toast.success(`${uploadedUrls.length} image(s) uploaded successfully`);
      }
    } catch (err) {
      toast.error('Upload failed. Please try again.');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleRemove = async (urlToRemove: string, index: number) => {
    try {
      // Extract path from URL
      const urlParts = urlToRemove.split('/');
      const path = urlParts.slice(urlParts.indexOf(bucket) + 1).join('/');
      
      if (path) {
        await storageService.deleteFile(bucket, path);
      }
      
      const newImages = currentImages.filter((_, i) => i !== index);
      onChange(multiple ? newImages : newImages[0] || '');
      toast.success('Image removed');
    } catch (err) {
      // Even if delete fails, remove from UI
      const newImages = currentImages.filter((_, i) => i !== index);
      onChange(multiple ? newImages : newImages[0] || '');
    }
  };

  const canAddMore = multiple ? currentImages.length < maxFiles : currentImages.length === 0;

  return (
    <div className={className}>
      {/* Image Grid */}
      <div className={`grid gap-4 ${multiple ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4' : 'grid-cols-1 max-w-sm'}`}>
        <AnimatePresence>
          {currentImages.map((url, index) => (
            <motion.div
              key={url}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className={`relative group ${aspectRatioClass} bg-gray-100 dark:bg-gray-800 rounded-xl overflow-hidden`}
            >
              <img
                src={url}
                alt={`Uploaded ${index + 1}`}
                className="w-full h-full object-cover"
              />
              
              {/* Remove Button */}
              <button
                onClick={() => handleRemove(url, index)}
                disabled={isUploading}
                className="absolute top-2 right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Overlay on hover */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Upload Button */}
        {canAddMore && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className={`${aspectRatioClass} border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl flex flex-col items-center justify-center gap-2 hover:border-orange-500 dark:hover:border-orange-400 hover:bg-orange-50 dark:hover:bg-orange-900/20 transition-colors disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {isUploading ? (
              <>
                <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {Math.round(uploadProgress)}%
                </span>
              </>
            ) : (
              <>
                <Upload className="w-8 h-8 text-gray-400" />
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {multiple ? 'Add Image' : 'Upload Image'}
                </span>
              </>
            )}
          </motion.button>
        )}
      </div>

      {/* Hidden File Input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple={multiple}
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Helper Text */}
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
        {multiple 
          ? `Upload up to ${maxFiles} images. Max ${maxSizeMB}MB each.` 
          : `Max file size: ${maxSizeMB}MB. Supported: JPG, PNG, WebP.`}
      </p>
    </div>
  );
}

// Simple single image upload variant
export function SingleImageUpload({
  bucket,
  folder = '',
  value,
  onChange,
  className = '',
  placeholder = 'Upload Image',
}: Omit<ImageUploadProps, 'multiple' | 'maxFiles'> & { placeholder?: string }) {
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size must be less than 5MB');
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast.error('Only image files are allowed');
      return;
    }

    setIsUploading(true);

    try {
      const { url, error } = await storageService.uploadImage(bucket, file, folder);
      
      if (error) {
        toast.error('Upload failed');
      } else if (url) {
        onChange(url);
        toast.success('Image uploaded successfully');
      }
    } catch (err) {
      toast.error('Upload failed. Please try again.');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleRemove = async () => {
    if (value) {
      try {
        const urlParts = (value as string).split('/');
        const path = urlParts.slice(urlParts.indexOf(bucket) + 1).join('/');
        if (path) {
          await storageService.deleteFile(bucket, path);
        }
      } catch (err) {
        // Ignore delete errors
      }
    }
    onChange('');
  };

  return (
    <div className={className}>
      {value ? (
        <div className="relative group w-32 h-32">
          <img
            src={value as string}
            alt="Uploaded"
            className="w-full h-full object-cover rounded-xl"
          />
          <button
            onClick={handleRemove}
            className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-lg"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      ) : (
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="w-32 h-32 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl flex flex-col items-center justify-center gap-2 hover:border-orange-500 dark:hover:border-orange-400 hover:bg-orange-50 dark:hover:bg-orange-900/20 transition-colors disabled:opacity-50"
        >
          {isUploading ? (
            <Loader2 className="w-6 h-6 text-orange-500 animate-spin" />
          ) : (
            <>
              <ImageIcon className="w-6 h-6 text-gray-400" />
              <span className="text-xs text-gray-500 dark:text-gray-400 text-center px-2">
                {placeholder}
              </span>
            </>
          )}
        </button>
      )}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileSelect}
        className="hidden"
      />
    </div>
  );
}
