# QuickSell Africa - Complete Supabase Setup Guide

## 📋 OVERVIEW

This document contains ALL the SQL migrations, Supabase buckets, and manual setup steps required to set up the QuickSell Africa platform.

---

## 🗄️ SQL MIGRATIONS

### 1. PROFILES TABLE (User Profiles)

```sql
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT,
  avatar_url TEXT,
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  email_verified BOOLEAN DEFAULT FALSE,
  subscription_tier TEXT CHECK (subscription_tier IN ('single', 'three', 'unlimited')),
  subscription_expires_at TIMESTAMP WITH TIME ZONE,
  selected_niches TEXT[] DEFAULT '{}',
  wallet_balance DECIMAL(12,2) DEFAULT 0,
  total_earnings DECIMAL(12,2) DEFAULT 0,
  is_store_active BOOLEAN DEFAULT FALSE,
  is_store_blocked BOOLEAN DEFAULT FALSE,
  block_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_sign_in TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own profile" 
  ON profiles FOR SELECT 
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" 
  ON profiles FOR UPDATE 
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles" 
  ON profiles FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 2. STORES TABLE

```sql
CREATE TABLE stores (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_id UUID REFERENCES profiles(id) NOT NULL,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  logo_url TEXT,
  banner_url TEXT,
  primary_color TEXT DEFAULT '#F97316',
  secondary_color TEXT DEFAULT '#FED7AA',
  niches TEXT[] DEFAULT '{}',
  theme TEXT DEFAULT 'modern',
  is_active BOOLEAN DEFAULT TRUE,
  is_verified BOOLEAN DEFAULT FALSE,
  is_blocked BOOLEAN DEFAULT FALSE,
  block_reason TEXT,
  custom_domain TEXT,
  domain_status TEXT DEFAULT 'none' CHECK (domain_status IN ('none', 'pending', 'processing', 'connected', 'failed')),
  domain_paid_amount DECIMAL(10,2),
  social_links JSONB DEFAULT '{}',
  analytics JSONB DEFAULT '{
    "total_visits": 0,
    "total_orders": 0,
    "total_revenue": 0,
    "conversion_rate": 0,
    "best_selling_products": [],
    "traffic_sources": {"direct": 0, "social": 0, "search": 0, "ads": 0},
    "monthly_growth": 0
  }',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Stores are viewable by everyone" 
  ON stores FOR SELECT 
  TO PUBLIC
  USING (is_active = TRUE AND is_blocked = FALSE);

CREATE POLICY "Users can create own store" 
  ON stores FOR INSERT 
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Owners can update own store" 
  ON stores FOR UPDATE 
  USING (auth.uid() = owner_id);

CREATE POLICY "Admins can manage all stores" 
  ON stores FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Trigger
CREATE TRIGGER update_stores_updated_at
  BEFORE UPDATE ON stores
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Index for slug lookups
CREATE INDEX idx_stores_slug ON stores(slug);
CREATE INDEX idx_stores_owner ON stores(owner_id);
```

---

### 3. PRODUCTS TABLE

```sql
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID REFERENCES stores(id) ON DELETE CASCADE NOT NULL,
  owner_id UUID REFERENCES profiles(id) NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  images TEXT[] DEFAULT '{}',
  category TEXT,
  niche TEXT,
  
  -- Pricing
  cost_price DECIMAL(12,2) DEFAULT 0,
  selling_price DECIMAL(12,2) NOT NULL,
  dropship_price DECIMAL(12,2),
  wholesale_price DECIMAL(12,2),
  
  -- Inventory
  stock_quantity INTEGER DEFAULT 0,
  low_stock_threshold INTEGER DEFAULT 10,
  sku TEXT,
  barcode TEXT,
  is_out_of_stock BOOLEAN DEFAULT FALSE,
  
  -- Variants
  has_variants BOOLEAN DEFAULT FALSE,
  variants JSONB DEFAULT '[]',
  
  -- Shipping
  weight DECIMAL(8,2),
  dimensions JSONB,
  
  -- Status
  is_active BOOLEAN DEFAULT TRUE,
  is_importable BOOLEAN DEFAULT FALSE,
  import_count INTEGER DEFAULT 0,
  
  -- SEO
  seo_title TEXT,
  seo_description TEXT,
  tags TEXT[] DEFAULT '{}',
  
  -- Analytics
  views INTEGER DEFAULT 0,
  sales_count INTEGER DEFAULT 0,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Products are viewable by everyone" 
  ON products FOR SELECT 
  TO PUBLIC
  USING (is_active = TRUE);

CREATE POLICY "Store owners can manage own products" 
  ON products FOR ALL 
  USING (auth.uid() = owner_id);

-- Indexes
CREATE INDEX idx_products_store ON products(store_id);
CREATE INDEX idx_products_niche ON products(niche);
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_products_importable ON products(is_importable) WHERE is_importable = TRUE;

-- Trigger
CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 4. ORDERS TABLE

```sql
CREATE TABLE orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_number TEXT UNIQUE NOT NULL,
  store_id UUID REFERENCES stores(id) NOT NULL,
  customer_id UUID REFERENCES profiles(id),
  
  -- Customer Info
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT,
  
  -- Pricing
  subtotal DECIMAL(12,2) NOT NULL,
  delivery_fee DECIMAL(12,2) DEFAULT 0,
  platform_fee DECIMAL(12,2) DEFAULT 0,
  total DECIMAL(12,2) NOT NULL,
  
  -- Delivery
  delivery_address JSONB NOT NULL,
  delivery_state TEXT,
  
  -- Payment
  payment_status TEXT DEFAULT 'pending' CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  payment_method TEXT CHECK (payment_method IN ('paystack', 'wallet')),
  payment_reference TEXT,
  paid_at TIMESTAMP WITH TIME ZONE,
  
  -- Order Status
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'returned')),
  
  -- Escrow
  escrow_release_at TIMESTAMP WITH TIME ZONE,
  is_escrow_released BOOLEAN DEFAULT FALSE,
  
  -- Tracking
  tracking_number TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  delivered_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Store owners can view own orders" 
  ON orders FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM stores WHERE id = orders.store_id AND owner_id = auth.uid()
  ));

CREATE POLICY "Customers can view own orders" 
  ON orders FOR SELECT 
  USING (customer_id = auth.uid());

CREATE POLICY "Store owners can update own orders" 
  ON orders FOR UPDATE 
  USING (EXISTS (
    SELECT 1 FROM stores WHERE id = orders.store_id AND owner_id = auth.uid()
  ));

-- Indexes
CREATE INDEX idx_orders_store ON orders(store_id);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at);

-- Trigger
CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 5. ORDER ITEMS TABLE

```sql
CREATE TABLE order_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE NOT NULL,
  product_id UUID REFERENCES products(id),
  product_name TEXT NOT NULL,
  product_image TEXT,
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  total_price DECIMAL(12,2) NOT NULL,
  is_imported BOOLEAN DEFAULT FALSE,
  original_product_id UUID,
  original_store_id UUID,
  dropship_price DECIMAL(12,2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Order items viewable by order owner" 
  ON order_items FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM orders WHERE id = order_items.order_id AND (
      customer_id = auth.uid() OR
      EXISTS (SELECT 1 FROM stores WHERE id = orders.store_id AND owner_id = auth.uid())
    )
  ));

-- Index
CREATE INDEX idx_order_items_order ON order_items(order_id);
```

---

### 6. WALLETS TABLE

```sql
CREATE TABLE wallets (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) UNIQUE NOT NULL,
  balance DECIMAL(12,2) DEFAULT 0,
  total_earned DECIMAL(12,2) DEFAULT 0,
  total_withdrawn DECIMAL(12,2) DEFAULT 0,
  pending_balance DECIMAL(12,2) DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own wallet" 
  ON wallets FOR SELECT 
  USING (user_id = auth.uid());

CREATE POLICY "Admins can view all wallets" 
  ON wallets FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Trigger
CREATE TRIGGER update_wallets_updated_at
  BEFORE UPDATE ON wallets
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 7. WALLET TRANSACTIONS TABLE

```sql
CREATE TABLE wallet_transactions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  wallet_id UUID REFERENCES wallets(id) NOT NULL,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('credit', 'debit')),
  amount DECIMAL(12,2) NOT NULL,
  balance_after DECIMAL(12,2) NOT NULL,
  description TEXT,
  reference TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed')),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own transactions" 
  ON wallet_transactions FOR SELECT 
  USING (user_id = auth.uid());

-- Indexes
CREATE INDEX idx_wallet_transactions_user ON wallet_transactions(user_id);
CREATE INDEX idx_wallet_transactions_wallet ON wallet_transactions(wallet_id);
CREATE INDEX idx_wallet_transactions_created ON wallet_transactions(created_at);
```

---

### 8. WITHDRAWAL REQUESTS TABLE

```sql
CREATE TABLE withdrawal_requests (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  wallet_id UUID REFERENCES wallets(id) NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'paid')),
  bank_name TEXT NOT NULL,
  account_number TEXT NOT NULL,
  account_name TEXT NOT NULL,
  admin_note TEXT,
  paid_at TIMESTAMP WITH TIME ZONE,
  paid_by UUID REFERENCES profiles(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE withdrawal_requests ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own requests" 
  ON withdrawal_requests FOR SELECT 
  USING (user_id = auth.uid());

CREATE POLICY "Users can create own requests" 
  ON withdrawal_requests FOR INSERT 
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can manage all requests" 
  ON withdrawal_requests FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Indexes
CREATE INDEX idx_withdrawals_user ON withdrawal_requests(user_id);
CREATE INDEX idx_withdrawals_status ON withdrawal_requests(status);
```

---

### 9. SUBSCRIPTIONS TABLE

```sql
CREATE TABLE subscriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  store_id UUID REFERENCES stores(id),
  tier TEXT NOT NULL CHECK (tier IN ('single', 'three', 'unlimited')),
  niches TEXT[] DEFAULT '{}',
  duration_months INTEGER NOT NULL,
  amount_paid DECIMAL(12,2) NOT NULL,
  is_trial BOOLEAN DEFAULT FALSE,
  starts_at TIMESTAMP WITH TIME ZONE NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  auto_renew BOOLEAN DEFAULT FALSE,
  payment_reference TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own subscriptions" 
  ON subscriptions FOR SELECT 
  USING (user_id = auth.uid());

CREATE POLICY "Admins can manage all subscriptions" 
  ON subscriptions FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Indexes
CREATE INDEX idx_subscriptions_user ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_active ON subscriptions(is_active) WHERE is_active = TRUE;
```

---

### 10. DELIVERY ZONES TABLE

```sql
CREATE TABLE delivery_zones (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID REFERENCES stores(id) ON DELETE CASCADE NOT NULL,
  state TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE delivery_zones ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Delivery zones are viewable by everyone" 
  ON delivery_zones FOR SELECT 
  TO PUBLIC
  USING (is_active = TRUE);

CREATE POLICY "Store owners can manage own zones" 
  ON delivery_zones FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM stores WHERE id = delivery_zones.store_id AND owner_id = auth.uid()
  ));

-- Index
CREATE INDEX idx_delivery_zones_store ON delivery_zones(store_id);
```

---

### 11. NOTIFICATIONS TABLE

```sql
CREATE TABLE notifications (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  data JSONB DEFAULT '{}',
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view own notifications" 
  ON notifications FOR SELECT 
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own notifications" 
  ON notifications FOR UPDATE 
  USING (user_id = auth.uid());

-- Indexes
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_unread ON notifications(user_id, is_read) WHERE is_read = FALSE;
```

---

### 12. IMPORT CATALOG TABLE

```sql
CREATE TABLE import_catalog (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  original_product_id UUID REFERENCES products(id) NOT NULL,
  original_store_id UUID REFERENCES stores(id) NOT NULL,
  original_owner_id UUID REFERENCES profiles(id) NOT NULL,
  importer_store_id UUID REFERENCES stores(id) NOT NULL,
  importer_owner_id UUID REFERENCES profiles(id) NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  images TEXT[] DEFAULT '{}',
  category TEXT,
  niche TEXT,
  selling_price DECIMAL(12,2) NOT NULL,
  dropship_price DECIMAL(12,2),
  custom_selling_price DECIMAL(12,2),
  is_active BOOLEAN DEFAULT TRUE,
  total_sales INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE import_catalog ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Importers can view own imports" 
  ON import_catalog FOR SELECT 
  USING (importer_owner_id = auth.uid());

CREATE POLICY "Original owners can view their imported products" 
  ON import_catalog FOR SELECT 
  USING (original_owner_id = auth.uid());

-- Indexes
CREATE INDEX idx_import_catalog_importer ON import_catalog(importer_store_id);
CREATE INDEX idx_import_catalog_original ON import_catalog(original_product_id);
```

---

### 13. TAX SETTINGS TABLE

```sql
CREATE TABLE tax_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID REFERENCES stores(id) ON DELETE CASCADE NOT NULL,
  owner_id UUID REFERENCES profiles(id) NOT NULL,
  tax_rate DECIMAL(5,2) DEFAULT 0,
  tax_name TEXT DEFAULT 'VAT',
  tax_id_number TEXT,
  country TEXT DEFAULT 'Nigeria',
  state TEXT,
  is_tax_enabled BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE tax_settings ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Store owners can manage own tax settings" 
  ON tax_settings FOR ALL 
  USING (owner_id = auth.uid());

-- Trigger
CREATE TRIGGER update_tax_settings_updated_at
  BEFORE UPDATE ON tax_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 14. BUSINESS EXPENSES TABLE

```sql
CREATE TABLE business_expenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID REFERENCES stores(id) ON DELETE CASCADE NOT NULL,
  owner_id UUID REFERENCES profiles(id) NOT NULL,
  expense_name TEXT NOT NULL,
  expense_category TEXT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  expense_date DATE NOT NULL,
  description TEXT,
  receipt_url TEXT,
  is_recurring BOOLEAN DEFAULT FALSE,
  recurring_frequency TEXT CHECK (recurring_frequency IN ('weekly', 'monthly', 'quarterly', 'yearly')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE business_expenses ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Store owners can manage own expenses" 
  ON business_expenses FOR ALL 
  USING (owner_id = auth.uid());

-- Indexes
CREATE INDEX idx_expenses_store ON business_expenses(store_id);
CREATE INDEX idx_expenses_date ON business_expenses(expense_date);

-- Trigger
CREATE TRIGGER update_expenses_updated_at
  BEFORE UPDATE ON business_expenses
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 15. TAX REPORTS TABLE

```sql
CREATE TABLE tax_reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID REFERENCES stores(id) ON DELETE CASCADE NOT NULL,
  owner_id UUID REFERENCES profiles(id) NOT NULL,
  report_name TEXT NOT NULL,
  report_period_start DATE NOT NULL,
  report_period_end DATE NOT NULL,
  total_revenue DECIMAL(12,2) NOT NULL,
  total_expenses DECIMAL(12,2) NOT NULL,
  taxable_income DECIMAL(12,2) NOT NULL,
  tax_rate DECIMAL(5,2) NOT NULL,
  tax_amount DECIMAL(12,2) NOT NULL,
  deductions DECIMAL(12,2) NOT NULL,
  net_tax_payable DECIMAL(12,2) NOT NULL,
  report_data JSONB NOT NULL,
  file_url TEXT,
  file_format TEXT CHECK (file_format IN ('pdf', 'csv', 'excel')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE tax_reports ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Store owners can manage own reports" 
  ON tax_reports FOR ALL 
  USING (owner_id = auth.uid());

-- Index
CREATE INDEX idx_tax_reports_store ON tax_reports(store_id);
```

---

### 16. REVIEWS TABLE

```sql
CREATE TABLE reviews (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  store_id UUID REFERENCES stores(id) NOT NULL,
  customer_id UUID REFERENCES profiles(id),
  customer_name TEXT NOT NULL,
  customer_email TEXT,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title TEXT,
  content TEXT NOT NULL,
  images TEXT[] DEFAULT '{}',
  is_verified_purchase BOOLEAN DEFAULT FALSE,
  is_approved BOOLEAN DEFAULT FALSE,
  helpful_count INTEGER DEFAULT 0,
  unhelpful_count INTEGER DEFAULT 0,
  admin_response TEXT,
  admin_responded_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Approved reviews are viewable by everyone" 
  ON reviews FOR SELECT 
  TO PUBLIC
  USING (is_approved = TRUE);

CREATE POLICY "Store owners can manage own reviews" 
  ON reviews FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM stores WHERE id = reviews.store_id AND owner_id = auth.uid()
  ));

-- Indexes
CREATE INDEX idx_reviews_product ON reviews(product_id);
CREATE INDEX idx_reviews_store ON reviews(store_id);
CREATE INDEX idx_reviews_approved ON reviews(is_approved) WHERE is_approved = TRUE;

-- Trigger
CREATE TRIGGER update_reviews_updated_at
  BEFORE UPDATE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 17. COUPONS TABLE

```sql
CREATE TABLE coupons (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID REFERENCES stores(id) ON DELETE CASCADE NOT NULL,
  code TEXT NOT NULL,
  description TEXT,
  discount_type TEXT NOT NULL CHECK (discount_type IN ('percentage', 'fixed')),
  discount_value DECIMAL(12,2) NOT NULL,
  min_order_amount DECIMAL(12,2),
  max_discount_amount DECIMAL(12,2),
  usage_limit INTEGER,
  usage_count INTEGER DEFAULT 0,
  start_date TIMESTAMP WITH TIME ZONE,
  end_date TIMESTAMP WITH TIME ZONE,
  is_active BOOLEAN DEFAULT TRUE,
  applies_to TEXT DEFAULT 'all' CHECK (applies_to IN ('all', 'products', 'categories')),
  product_ids UUID[] DEFAULT '{}',
  category_ids TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Active coupons are viewable by everyone" 
  ON coupons FOR SELECT 
  TO PUBLIC
  USING (is_active = TRUE);

CREATE POLICY "Store owners can manage own coupons" 
  ON coupons FOR ALL 
  USING (EXISTS (
    SELECT 1 FROM stores WHERE id = coupons.store_id AND owner_id = auth.uid()
  ));

-- Index
CREATE INDEX idx_coupons_store ON coupons(store_id);

-- Trigger
CREATE TRIGGER update_coupons_updated_at
  BEFORE UPDATE ON coupons
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 18. CUSTOMERS TABLE (For Shopper Accounts)

```sql
CREATE TABLE customers (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT NOT NULL,
  phone TEXT,
  avatar_url TEXT,
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  last_sign_in TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Customers can view own profile" 
  ON customers FOR SELECT 
  USING (auth.uid() = id);

CREATE POLICY "Customers can update own profile" 
  ON customers FOR UPDATE 
  USING (auth.uid() = id);

-- Trigger
CREATE TRIGGER update_customers_updated_at
  BEFORE UPDATE ON customers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
```

---

### 19. CUSTOMER ADDRESSES TABLE

```sql
CREATE TABLE customer_addresses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
  label TEXT NOT NULL,
  street TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  country TEXT DEFAULT 'Nigeria',
  postal_code TEXT,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE customer_addresses ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Customers can manage own addresses" 
  ON customer_addresses FOR ALL 
  USING (customer_id = auth.uid());

-- Index
CREATE INDEX idx_customer_addresses_customer ON customer_addresses(customer_id);
```

---

### 20. CUSTOMER CARTS TABLE (For Universal Cart)

```sql
CREATE TABLE customer_carts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID REFERENCES customers(id) ON DELETE CASCADE NOT NULL,
  items JSONB DEFAULT '[]',
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(customer_id)
);

-- Enable RLS
ALTER TABLE customer_carts ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Customers can manage own cart" 
  ON customer_carts FOR ALL 
  USING (customer_id = auth.uid());
```

---

### 21. STORE VISITS TABLE (Analytics)

```sql
CREATE TABLE store_visits (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  store_id UUID REFERENCES stores(id) ON DELETE CASCADE NOT NULL,
  ip TEXT,
  user_agent TEXT,
  referrer TEXT,
  source TEXT DEFAULT 'direct',
  visited_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE store_visits ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Store owners can view own visits" 
  ON store_visits FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM stores WHERE id = store_visits.store_id AND owner_id = auth.uid()
  ));

-- Indexes
CREATE INDEX idx_store_visits_store ON store_visits(store_id);
CREATE INDEX idx_store_visits_visited ON store_visits(visited_at);
```

---

### 22. STOCK ALERTS TABLE

```sql
CREATE TABLE stock_alerts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES products(id) ON DELETE CASCADE NOT NULL,
  store_id UUID REFERENCES stores(id) NOT NULL,
  owner_id UUID REFERENCES profiles(id) NOT NULL,
  alert_type TEXT NOT NULL CHECK (alert_type IN ('low_stock', 'out_of_stock', 'restocked')),
  previous_stock INTEGER NOT NULL,
  current_stock INTEGER NOT NULL,
  threshold INTEGER NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  read_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE stock_alerts ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Store owners can manage own alerts" 
  ON stock_alerts FOR ALL 
  USING (owner_id = auth.uid());

-- Indexes
CREATE INDEX idx_stock_alerts_owner ON stock_alerts(owner_id);
CREATE INDEX idx_stock_alerts_unread ON stock_alerts(owner_id, is_read) WHERE is_read = FALSE;
```

---

### 23. PRODUCT EARNINGS TABLE

```sql
CREATE TABLE product_earnings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES products(id) NOT NULL,
  store_id UUID REFERENCES stores(id) NOT NULL,
  owner_id UUID REFERENCES profiles(id) NOT NULL,
  order_id UUID REFERENCES orders(id),
  quantity_sold INTEGER NOT NULL,
  unit_cost DECIMAL(12,2) NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  total_revenue DECIMAL(12,2) NOT NULL,
  total_cost DECIMAL(12,2) NOT NULL,
  profit DECIMAL(12,2) NOT NULL,
  platform_fee DECIMAL(12,2) DEFAULT 0,
  net_profit DECIMAL(12,2) NOT NULL,
  earned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE product_earnings ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Store owners can view own earnings" 
  ON product_earnings FOR SELECT 
  USING (owner_id = auth.uid());

-- Indexes
CREATE INDEX idx_product_earnings_store ON product_earnings(store_id);
CREATE INDEX idx_product_earnings_product ON product_earnings(product_id);
CREATE INDEX idx_product_earnings_earned ON product_earnings(earned_at);
```

---

### 24. ADMIN ACTIONS TABLE

```sql
CREATE TABLE admin_actions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  admin_id UUID REFERENCES profiles(id) NOT NULL,
  action_type TEXT NOT NULL,
  target_type TEXT NOT NULL CHECK (target_type IN ('user', 'store', 'product', 'order')),
  target_id UUID NOT NULL,
  details TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE admin_actions ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Admins can view all actions" 
  ON admin_actions FOR SELECT 
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Admins can create actions" 
  ON admin_actions FOR INSERT 
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Index
CREATE INDEX idx_admin_actions_admin ON admin_actions(admin_id);
CREATE INDEX idx_admin_actions_created ON admin_actions(created_at);
```

---

## 🔧 DATABASE FUNCTIONS

### 1. Calculate Tax for Period

```sql
CREATE OR REPLACE FUNCTION calculate_tax_for_period(
  p_store_id UUID,
  p_start_date DATE,
  p_end_date DATE
)
RETURNS JSONB AS $$
DECLARE
  v_total_revenue DECIMAL(12,2);
  v_total_expenses DECIMAL(12,2);
  v_taxable_income DECIMAL(12,2);
  v_tax_rate DECIMAL(5,2);
  v_tax_amount DECIMAL(12,2);
  v_net_after_tax DECIMAL(12,2);
BEGIN
  -- Get total revenue from orders
  SELECT COALESCE(SUM(total), 0)
  INTO v_total_revenue
  FROM orders
  WHERE store_id = p_store_id
    AND payment_status = 'paid'
    AND created_at >= p_start_date
    AND created_at <= p_end_date;

  -- Get total expenses
  SELECT COALESCE(SUM(amount), 0)
  INTO v_total_expenses
  FROM business_expenses
  WHERE store_id = p_store_id
    AND expense_date >= p_start_date
    AND expense_date <= p_end_date;

  -- Get tax rate
  SELECT COALESCE(tax_rate, 0)
  INTO v_tax_rate
  FROM tax_settings
  WHERE store_id = p_store_id;

  -- Calculate taxable income and tax
  v_taxable_income := v_total_revenue - v_total_expenses;
  IF v_taxable_income < 0 THEN
    v_taxable_income := 0;
  END IF;
  
  v_tax_amount := (v_taxable_income * v_tax_rate) / 100;
  v_net_after_tax := v_total_revenue - v_total_expenses - v_tax_amount;

  RETURN jsonb_build_object(
    'total_revenue', v_total_revenue,
    'total_expenses', v_total_expenses,
    'taxable_income', v_taxable_income,
    'tax_rate', v_tax_rate,
    'tax_amount', v_tax_amount,
    'net_after_tax', v_net_after_tax
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

---

### 2. Get Expense Categories Summary

```sql
CREATE OR REPLACE FUNCTION get_expense_categories_summary(
  p_store_id UUID,
  p_start_date DATE DEFAULT NULL,
  p_end_date DATE DEFAULT NULL
)
RETURNS TABLE (
  category TEXT,
  total_amount DECIMAL,
  expense_count BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    be.expense_category,
    COALESCE(SUM(be.amount), 0)::DECIMAL,
    COUNT(*)::BIGINT
  FROM business_expenses be
  WHERE be.store_id = p_store_id
    AND (p_start_date IS NULL OR be.expense_date >= p_start_date)
    AND (p_end_date IS NULL OR be.expense_date <= p_end_date)
  GROUP BY be.expense_category
  ORDER BY SUM(be.amount) DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

---

### 3. Get Admin Dashboard Stats

```sql
CREATE OR REPLACE FUNCTION get_admin_dashboard_stats()
RETURNS JSONB AS $$
DECLARE
  v_total_users INTEGER;
  v_total_stores INTEGER;
  v_total_products INTEGER;
  v_total_orders INTEGER;
  v_total_revenue DECIMAL;
  v_pending_withdrawals INTEGER;
  v_pending_verifications INTEGER;
  v_blocked_stores INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_total_users FROM profiles;
  SELECT COUNT(*) INTO v_total_stores FROM stores;
  SELECT COUNT(*) INTO v_total_products FROM products;
  SELECT COUNT(*) INTO v_total_orders FROM orders;
  SELECT COALESCE(SUM(total), 0) INTO v_total_revenue FROM orders WHERE payment_status = 'paid';
  SELECT COUNT(*) INTO v_pending_withdrawals FROM withdrawal_requests WHERE status = 'pending';
  SELECT COUNT(*) INTO v_pending_verifications FROM stores WHERE is_verified = FALSE;
  SELECT COUNT(*) INTO v_blocked_stores FROM stores WHERE is_blocked = TRUE;

  RETURN jsonb_build_object(
    'total_users', v_total_users,
    'total_stores', v_total_stores,
    'total_products', v_total_products,
    'total_orders', v_total_orders,
    'total_revenue', v_total_revenue,
    'pending_withdrawals', v_pending_withdrawals,
    'pending_verifications', v_pending_verifications,
    'blocked_stores', v_blocked_stores
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

---

### 4. Get Product Earnings Summary

```sql
CREATE OR REPLACE FUNCTION get_product_earnings_summary(
  p_store_id UUID,
  p_start_date DATE DEFAULT NULL,
  p_end_date DATE DEFAULT NULL
)
RETURNS TABLE (
  product_id UUID,
  product_name TEXT,
  total_quantity_sold BIGINT,
  total_revenue DECIMAL,
  total_cost DECIMAL,
  total_profit DECIMAL,
  total_net_profit DECIMAL
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pe.product_id,
    MAX(p.name) as product_name,
    SUM(pe.quantity_sold)::BIGINT,
    COALESCE(SUM(pe.total_revenue), 0)::DECIMAL,
    COALESCE(SUM(pe.total_cost), 0)::DECIMAL,
    COALESCE(SUM(pe.profit), 0)::DECIMAL,
    COALESCE(SUM(pe.net_profit), 0)::DECIMAL
  FROM product_earnings pe
  JOIN products p ON p.id = pe.product_id
  WHERE pe.store_id = p_store_id
    AND (p_start_date IS NULL OR pe.earned_at >= p_start_date)
    AND (p_end_date IS NULL OR pe.earned_at <= p_end_date)
  GROUP BY pe.product_id
  ORDER BY SUM(pe.net_profit) DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

---

### 5. Get Stock Alerts

```sql
CREATE OR REPLACE FUNCTION get_stock_alerts(p_owner_id UUID)
RETURNS TABLE (
  id UUID,
  product_id UUID,
  store_id UUID,
  owner_id UUID,
  alert_type TEXT,
  previous_stock INTEGER,
  current_stock INTEGER,
  threshold INTEGER,
  is_read BOOLEAN,
  read_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE,
  product JSONB
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    sa.id,
    sa.product_id,
    sa.store_id,
    sa.owner_id,
    sa.alert_type,
    sa.previous_stock,
    sa.current_stock,
    sa.threshold,
    sa.is_read,
    sa.read_at,
    sa.created_at,
    jsonb_build_object(
      'name', p.name,
      'images', p.images
    ) as product
  FROM stock_alerts sa
  JOIN products p ON p.id = sa.product_id
  WHERE sa.owner_id = p_owner_id
  ORDER BY sa.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

---

## 🪣 SUPABASE STORAGE BUCKETS

Create these buckets in your Supabase Dashboard (Storage section):

### 1. **products** - For product images
- **Public**: ✅ Yes
- **Allowed MIME types**: `image/*`
- **Max file size**: 5MB

### 2. **store-logos** - For store logos
- **Public**: ✅ Yes
- **Allowed MIME types**: `image/*`
- **Max file size**: 2MB

### 3. **store-banners** - For store banners
- **Public**: ✅ Yes
- **Allowed MIME types**: `image/*`
- **Max file size**: 5MB

### 4. **receipts** - For expense receipts
- **Public**: ❌ No (private)
- **Allowed MIME types**: `image/*`, `application/pdf`
- **Max file size**: 5MB

### 5. **tax-reports** - For generated tax reports
- **Public**: ❌ No (private)
- **Allowed MIME types**: `application/pdf`, `text/csv`, `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`
- **Max file size**: 10MB

### 6. **avatars** - For user profile pictures
- **Public**: ✅ Yes
- **Allowed MIME types**: `image/*`
- **Max file size**: 2MB

### 7. **review-images** - For review photos
- **Public**: ✅ Yes
- **Allowed MIME types**: `image/*`
- **Max file size**: 3MB

---

## ⚙️ SUPABASE AUTH CONFIGURATION

### Email Templates (Go to Authentication > Email Templates)

**Confirmation Email Template:**
```html
<h2>Confirm your signup</h2>
<p>Hello {{ .Data.full_name }},</p>
<p>Your verification code is:</p>
<h1 style="font-size: 48px; letter-spacing: 8px; text-align: center; padding: 20px; background: #f5f5f5; border-radius: 8px;">{{ .Token }}</h1>
<p>Enter this code in the app to verify your email address.</p>
<p>This code will expire in 1 hour.</p>
<p>If you didn't request this, please ignore this email.</p>
```

**Reset Password Email Template:**
```html
<h2>Reset Your Password</h2>
<p>Hello,</p>
<p>You requested to reset your password. Click the link below:</p>
<p><a href="{{ .ConfirmationURL }}">Reset Password</a></p>
<p>If you didn't request this, please ignore this email.</p>
<p>This link will expire in 1 hour.</p>
```

### Auth Settings (Authentication > Settings)

**Site URL**: `https://your-domain.com`

**Redirect URLs**:
- `https://your-domain.com/reset-password`
- `https://your-domain.com/verify-email`
- `http://localhost:5173/reset-password` (for development)
- `http://localhost:5173/verify-email` (for development)

**Email Confirmations**: ✅ Enabled

**Secure Email Change**: ✅ Enabled

**External OAuth Providers**: Configure as needed (Google, etc.)

---

## 🔑 ENVIRONMENT VARIABLES

Create a `.env` file in your project root:

```env
# Supabase
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# Paystack
VITE_PAYSTACK_PUBLIC_KEY=your_paystack_public_key

# App Config
VITE_APP_NAME=QAFRICA
VITE_APP_URL=https://your-domain.com
```

---

## 📱 MANUAL SETUP STEPS

### 1. Create Admin User

After signing up your first user, manually update their role to admin in the database:

```sql
UPDATE profiles 
SET role = 'admin' 
WHERE email = 'your-admin-email@example.com';
```

### 2. Configure Paystack

1. Create a Paystack account at https://paystack.com
2. Get your public and secret keys
3. Add the public key to your `.env` file
4. Set up webhooks for payment notifications (optional)

### 3. Set Up Email SMTP (Optional but Recommended)

For production, configure a custom SMTP provider:

1. Go to Authentication > Providers > Email
2. Enable "Custom SMTP"
3. Enter your SMTP credentials (SendGrid, Mailgun, etc.)

### 4. Configure CORS (If Needed)

Go to API > Settings > CORS:
- Add your production domain
- Add `http://localhost:5173` for development

### 5. Enable Realtime (For Live Notifications)

Go to Database > Replication:
- Enable realtime for tables: `notifications`, `orders`, `stock_alerts`

---

## 🎨 THEMES AVAILABLE (13 Total)

| Theme ID | Name | Primary Color | Best For |
|----------|------|---------------|----------|
| modern | Modern | Orange (#F97316) | General |
| elegant | Elegant | Purple (#7C3AED) | Luxury |
| bold | Bold | Pink (#EC4899) | Fashion |
| classic | Classic | Green (#059669) | Traditional |
| minimal | Minimal | Dark Gray (#1F2937) | Clean |
| tech | Tech | Blue (#0EA5E9) | Electronics |
| warm | Warm | Amber (#D97706) | Home |
| luxury | Luxury | Gold (#B45309) | Premium |
| professional | Professional | Navy (#1E40AF) | B2B |
| creative | Creative | Violet (#8B5CF6) | Art |
| soft | Soft | Teal (#14B8A6) | Baby/Wellness |
| clean | Clean | Cyan (#06B6D4) | Health |
| fresh | Fresh | Green (#22C55E) | Food/Organic |

---

## ✅ VERIFICATION CHECKLIST

After setup, verify:

- [ ] All 24 tables created
- [ ] All 7 storage buckets created
- [ ] RLS policies applied
- [ ] Database functions created
- [ ] Email templates configured
- [ ] Auth settings configured
- [ ] Environment variables set
- [ ] Admin user promoted
- [ ] Paystack keys configured

---

## 🆘 TROUBLESHOOTING

### Issue: "Failed to fetch" errors
**Solution**: Check CORS settings and ensure your domain is allowed.

### Issue: Images not uploading
**Solution**: Verify storage buckets exist and RLS policies allow uploads.

### Issue: Emails not sending
**Solution**: Check email templates and SMTP configuration.

### Issue: Auth not working
**Solution**: Verify Supabase URL and anon key in environment variables.

---

**Last Updated**: 2024
**Version**: 1.0.0
